using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DisputeReversalRequest
    {
        /// <summary>
        /// Identificador único do pedido de desistência da disputa. Gerado pelo emissor.
        /// </summary>
        public string IssuerDisputeReversalId { get; set; }

        /// <summary>
        /// Mensagem de texto justificando o motivo da desistência da disputa (opcional).
        /// </summary>
        public string TextMessage { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
