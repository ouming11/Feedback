using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UpdateFunctionBlockingResultFunctionality
    {
        /// <summary>
        /// Gets or Sets CardId
        /// </summary>
        public string CardId { get; set; }

        /// <summary>
        /// Todas as funcionalidade relacionadas ao emissor.
        /// </summary>
        public List<FunctionalitiesInformation> FuncionalityList { get; set; }
    }
}
