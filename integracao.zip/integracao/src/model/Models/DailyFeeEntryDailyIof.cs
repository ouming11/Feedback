using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DailyFeeEntryDailyIof
    {
        /// <summary>
        /// Porcentagem de IOF diário
        /// </summary>
        public string IOFDay { get; set; }

        /// <summary>
        /// Valor representado sem a virgula (Considerar 2 digitos decimais)
        /// </summary>
        public string IOFCharged { get; set; }
    }
}
