using System.Runtime.Serialization;
using System.Text;
using model.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class VirtualCardDescriptorGet
    {
        /// <summary>
        /// Identificador único do cartão virtual gerado pela integracao
        /// </summary>
        public string VCardId { get; set; }

        /// <summary>
        /// Data de expiração do cartão virtual
        /// </summary>
        public DataExpiracaoCartao VDateExp { get; set; }
    }
}
