using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Credit
    {
        /// <summary>
        /// Identificador da carga de créditos.
        /// </summary>
        [Required]
        public string CreditId { get; set; }

        /// <summary>
        /// Data de início de validade/disponibilização de crédito nos cartões.
        /// </summary>
        [Required]
        public DateTime InclusionDate { get; set; }

        /// <summary>
        /// Valor do crédito a ser adicionado na conta.
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// tipo de caga de crédito realizada (normal, emergencial, etc).
        /// </summary>
        [Required]
        public int CreditType { get; set; }
    }
}
