using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DisputeRequest
    {
        /// <summary>
        /// Identificador único da disputa. Gerado pelo emissor.
        /// </summary>
        public string IssuerDisputeId { get; set; }

        /// <summary>
        /// Identificador único da conta atribuído pela integracao.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Identificador da transação em disputa.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// Código da disputa que indica o motivo de abertura.
        /// </summary>
        [Required]
        public string DisputeCode { get; set; }

        /// <summary>
        /// Mensagem de texto justificando a disputa. Conteúdo esperado depende do código do motivo da disputa.
        /// </summary>
        [Required]
        public string DisputeTextMessage { get; set; }

        /// <summary>
        /// Tipo da fraude. Deve ser enviado quando o motivo de disputa for algum tipo de fraude.
        /// </summary>
        public string FraudType { get; set; }

        /// <summary>
        /// Indica se está sendo disputada uma parte ou o valor total da transação. Se for verdadeiro é necessário informar amount_disputed.
        /// </summary>
        public bool? Partial { get; set; }

        /// <summary>
        /// Valor sendo disputado. Só deve estar presente se a partial for true.
        /// </summary>
        public DescritorValor AmountDisputed { get; set; }

        /// <summary>
        /// Indica se documentos apoiando a disputa vão ser anexados no Portal ELO posteriormente. Campo opcional, por padrão vai ser falso.
        /// </summary>
        public bool? WillAddDocuments { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
