using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class VirtualCardInfo
    {
        /// <summary>
        /// Status do cartão virtual
        /// </summary>
        public string StatusCode { get; set; }

        /// <summary>
        /// Identificador do cartão real associado ao cartão virtual
        /// </summary>
        public string CardId { get; set; }

        /// <summary>
        /// Descrição do status do cartão virtual
        /// </summary>
        public string StatusDescription { get; set; }
    }
}
