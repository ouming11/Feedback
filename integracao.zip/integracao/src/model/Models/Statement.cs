using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Statement
    {
        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        public string AccountId { get; set; }

        /// <summary>
        /// Data de vencimento da fatura
        /// </summary>
        public DateOnly Vencimento { get; set; }

        /// <summary>
        /// Data de vencimento da fatura, levando em conta fins de semana e feriados.
        /// </summary>
        public DateOnly VencimentoEfetivo { get; set; }

        /// <summary>
        /// Data de fechamento da fatura.
        /// </summary>
        public DateTime Fechamento { get; set; }

        /// <summary>
        /// Saldo total da fatura
        /// </summary>
        public DescritorValor Balance { get; set; }

        /// <summary>
        /// Valor mínimo a ser pago para está fatura até o vencimento.
        /// </summary>
        public DescritorValor MinimumPaymentDue { get; set; }

        /// <summary>
        /// Lista de lançamentos nessa fatura
        /// </summary>
        public List<StatementEntry> TransactionsList { get; set; }

        /// <summary>
        /// Transações criadas no processamento da Fatura e já somadas no saldo da fatura fechada. Existem 3 tipos possíveis: Encargos, Multas e Ressarcimento
        /// </summary>
        public List<StatementEntry> AdditionalTransactionsList { get; set; }

        /// <summary>
        /// Transações fora do período da fatura que foram inseridas quando a fatura ainda estava aberta.
        /// </summary>
        public List<StatementEntry> OutOfStatementPeriodTransactions { get; set; }

        /// <summary>
        /// Data e hora da última transação inserida na fatura.
        /// </summary>
        public DateTime? FirstTransactionInserted { get; set; }

        /// <summary>
        /// Data e hora da primeira transação inserida na fatura.
        /// </summary>
        public DateTime? LastTransactionInserted { get; set; }

        /// <summary>
        /// Data e hora de abertura da Fatura.
        /// </summary>
        public DateTime? OpeningDateTime { get; set; }

        /// <summary>
        /// Data e hora do fechamento da fatura.
        /// </summary>
        public DateTime? StatementClosingDateTime { get; set; }

        /// <summary>
        /// No caso de ser pago apenas o valor mínimo até a data de vencimento valor a ser pago na próxima fatura (juros mais impostos).
        /// </summary>
        public DescritorValor ChargesInNextStatementForMinimumPayment { get; set; }

        /// <summary>
        /// id da fatura no formato yyyy-mm
        /// </summary>
        public string StatementId { get; set; }

        /// <summary>
        /// id da fatura anterior no formato yyyy-mm
        /// </summary>
        public string LastStatementId { get; set; }

        /// <summary>
        /// Lista de cobranças de taxas e multas divida por dias
        /// </summary>
        public List<DailyFeeEntry> InterestCalculationMemory { get; set; }

        /// <summary>
        /// identificador uuid de ultima atualização
        /// </summary>
        public string LastUpdated { get; set; }

        /// <summary>
        /// Pagamentos e créditos nessa fatura
        /// </summary>
        public DescritorValor PaymentsAndCredits { get; set; }

        /// <summary>
        /// Compras e débitos nessa fatura
        /// </summary>
        public DescritorValor PurchasesAndDebits { get; set; }

        /// <summary>
        /// Custo Efetivo Total (CET), para o próximo período, das operações de crédito passíveis de contratação.
        /// </summary>
        public TaxasECet Cet { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}

