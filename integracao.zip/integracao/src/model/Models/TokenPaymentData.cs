using System;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Informações dos Dados Transacionais - Conjunto de dados de Pagamento via Token. 
    /// </summary>
    [DataContract]
    public class TokenPaymentData
    {
        /// <summary>
        /// 4 últimos dígitos do número primário da conta (FPAN) 
        /// </summary>
        public string FPan { get; set; }

        /// <summary>
        /// Este tag contém o ID do requisitante do Token
        /// </summary>
        public string RequesterIdToken { get; set; }

        /// <summary>
        /// Contém os dados do PAN (DPAN) de contas com token. Este tag pode não estar presente para todos os ECs e Credenciadores. 
        /// </summary>
        public string Pan { get; set; }

        /// <summary>
        /// Token PAN Sequence Number. 
        /// </summary>
        public string TokenPanSequenceNumber { get; set; }

        /// <summary>
        /// Data de expiração do token. 
        /// </summary>
        public DateTime TokenExpirationDate { get; set; }

        /// <summary>
        /// Token Status
        /// Valores válidos:
        /// * 0100 – Token encontrado
        /// * 0101 – Token não encontrado
        /// * 0102 – Token suspenso
        /// * 0103 – Token encerrado
        /// * 0104 – Token inativo
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ??? o código do erro 
        /// </summary>
        public string TokenStatus { get; set; }

        /// <summary>
        /// Token Cryptogram Verification Results
        /// Valores válidos:
        /// * 0200 – Criptografia OK (todas as verificações de criptograma estão OK)
        /// * 0201 – Criptografia falhou (pelo menos uma verificação de criptograma falhou)
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ??? o código do erro 
        /// </summary>
        public string TokenCryptogramVerificationResults { get; set; }

        /// <summary>
        /// EMV Token Cryptogram Verification Results
        /// Valores válidos:
        /// * 0200 – Criptograma OK
        /// * 0201 – Criptograma inválido
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ??? o código do erro 
        /// </summary>
        public string EMVTokenCryptogramVerificationResults { get; set; }

        /// <summary>
        /// Token Constraints Verification Status
        /// Valores válidos:
        /// * 0300 – Restrições OK
        /// * 0301 – Restrições falharam (pelo menos uma restrição falhou)
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ??? o código do erro 
        /// </summary>
        public string TokenConstraintsVerificationStatus { get; set; }

        /// <summary>
        /// Transaction DateTime Constraint
        /// Valores válidos:
        /// * OK – Verificação OK
        /// * NC – not constrained (Não verificado)
        /// * EFF – Token ainda não é efetivo
        /// * EXP – Token expirado
        /// * NA – not allowed (verificação foi realizada e falhou) 
        /// </summary>
        public string TransactionDateTimeConstraint { get; set; }

        /// <summary>
        /// Transaction Amount Constraint
        /// Valores válidos:
        /// * OK – verificação OK
        /// * NC – not constrained (não verificado)
        /// * AMT – Valor acima do permitido
        /// * CUR – Moeda não permitida 
        /// </summary>
        public string TransactionAmountConstraint { get; set; }

        /// <summary>
        /// Usage Constraint
        /// Valores válidos:
        /// * OK – verificação OK
        /// * NC – not constrained (não verificado)
        /// * DP – Token depleted (número de usos maior que o permitido)
        /// * UN – Token is not usable. (Tentativas para usar o token foram marcadas como não utilizáveis. Foi declarado que o número máximo de tentativas é zero) 
        /// </summary>
        public string UsageConstraint { get; set; }

        /// <summary>
        /// Token ATC Verification Results
        /// Valores válidos:
        /// * 0500 – ATC OK
        /// * 05XX Sendo que XX é definido como bitmap
        /// * b8-b1 (com o b8 sendo o bit mais significativo):
        /// * b8 – RFU
        /// * b7 – ATC validado anteriormente (transação repetida)
        /// * b6 – RFU
        /// * b5 – RFU
        /// * b4 – RFU
        /// * b3 – Salto "para trás"/negativo do ATC é maior que o permitido
        /// * b2 – Salto "para frente"/positivo do ATC é maior que o permitido
        /// * b1 – ATC é maior que o máximo permitido
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ?? o código do erro 
        /// </summary>
        public string TokenATCVerificationResults { get; set; }

        /// <summary>
        /// CVE2 Token Cryptogram Verification Status
        /// Valores válidos:
        /// * 0200 – Criptograma OK
        /// * 0201 – Criptograma inválido
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ??? o código do erro 
        /// </summary>
        public string CVE2TokenCryptogramVerificationStatus { get; set; }

        /// <summary>
        /// Merchant Verification
        /// Valores válidos:
        /// * OK – Merchant OK
        /// * NC – not constrained (não verificado)
        /// * NA – Merchant não permitido 
        /// </summary>
        public string MerchantVerification { get; set; }

        /// <summary>
        /// Magstripe Token Cryptogram Verification Results
        /// Valores válidos:
        /// * 0200 – Criptograma OK
        /// * 0201 – Criptograma inválido
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ??? o código do erro 
        /// </summary>
        public string MagstripeTokenCryptogramVerificationResults { get; set; }

        /// <summary>
        /// CVE2 Output Token Cryptogram Verification Results
        /// Valores válidos:
        /// * 0200 – Criptograma OK
        /// * 0201 – Criptograma inválido
        /// * E001 – Processamento ignorado
        /// * E002 – Processamento desabilitado
        /// * F??? – Erro interno de processamento, sendo ??? o código do erro 
        /// </summary>
        public string CVE2OutputTokenCryptogramVerificationResults { get; set; }
    }
}
