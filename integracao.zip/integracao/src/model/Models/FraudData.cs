using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// A presença deste campo indica que um Score de Fraude é entregue ao Emissor juntamente com dados adicionais de fraude. O Credenciador pode enviar seu Score de Fraude para a Bandeira e Emissor utilizando este campo.
    /// </summary>
    [DataContract]
    public class FraudData
    {
        /// <summary>
        /// Score de Fraude Credenciador.
        /// </summary>
        public int? CreditorFraudScore { get; set; }

        /// <summary>
        /// Score de Fraude Bandeira Elo.
        /// </summary>
        public int? EloBrandFraudScore { get; set; }

        /// <summary>
        /// Motivo primário do score de fraude.
        /// </summary>
        public int? FraudScorePrimaryReason { get; set; }

        /// <summary>
        /// Motivo secundário do score de fraude.
        /// </summary>
        public int? FraudScoreSecondaryReason { get; set; }

        /// <summary>
        /// Motivo terciário do score de fraude.
        /// </summary>
        public int? FraudScoreTertiaryReason { get; set; }

        /// <summary>
        /// Recomendação de decisão por fraude.
        /// </summary>
        public string FraudDecisionRecommendation { get; set; }

        /// <summary>
        /// Indicador de Origem do Score.  * &#x27;1&#x27; - O &#x27;Score de Fraude Bandeira Elo&#x27; corresponde ao Score da transação corrente; * &#x27;2&#x27; - O &#x27;Score de Fraude Bandeira Elo&#x27; corresponde ao Score da transação anterior por motivo de indisponibilidade do sistema
        /// </summary>
        public int? ScoreOriginIndicator { get; set; }
    }
}
