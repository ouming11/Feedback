using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Resposta do autorizador para a transação
    /// </summary>
    [DataContract]
    public class TransactionAuthorizationResponse
    {
        /// <summary>
        /// Indica se a transação foi aprovada pelo autorizador.
        /// </summary>
        public bool? Approved { get; set; }

        /// <summary>
        /// Razão da negação. Só presente se a approved for false.
        /// </summary>
        public TransactionDenialReason DenialReason { get; set; }
    }
}
