using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Custo Efetivo Total (CET)
    /// </summary>
    [DataContract]
    public class CustoEfetivoTotal
    {
        /// <summary>
        /// Juros mensais.
        /// </summary>
        [Required]
        public decimal MonthlyInterest { get; set; }

        /// <summary>
        /// Juros anuais.
        /// </summary>
        [Required]
        public decimal YearlyInterest { get; set; }

        /// <summary>
        /// IOF.
        /// </summary>
        [Required]
        public decimal IOF { get; set; }

        /// <summary>
        /// IOF diário.
        /// </summary>
        public decimal DailyIOF { get; set; }

        /// <summary>
        /// Custo Efetivo Total, ao ano.
        /// </summary>
        [Required]
        public decimal CetAoAno { get; set; }
    }
}

