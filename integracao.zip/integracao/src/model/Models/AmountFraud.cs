using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class AmountFraud
    {
        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// Tipo da transação. * Débito: retirando fundos da conta * Crédito: adicionando fundos na conta
        /// </summary>
        public string DebitOrCredit { get; set; }
    }
}
