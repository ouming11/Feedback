using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DailyFeeEntryDailyInterest
    {
        /// <summary>
        /// Porcentagem de Juros rotativo diário
        /// </summary>
        public string InterestDay { get; set; }

        /// <summary>
        /// Valor representado sem a virgula (Considerar 2 digitos decimais)
        /// </summary>
        public int? InterestCharged { get; set; }
    }
}
