using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class FraudNotification
    {
        /// <summary>
        /// Gets or Sets CardHolderData
        /// </summary>
        public FraudNotificationCardholderData CardHolderData { get; set; }

        /// <summary>
        /// Data e hora da notificação no formato definido pela RFC 3339, seção 5.6.
        /// </summary>
        public DateTime? NotificationDate { get; set; }

        /// <summary>
        /// Tipo da fraude.
        /// </summary>
        public string FraudType { get; set; }

        /// <summary>
        /// Gets or Sets FraudNotificationStatus
        /// </summary>
        public SituacaoFraude FraudNotificationStatus { get; set; }

        /// <summary>
        /// Identificador único da conta atribuído pela integracao.
        /// </summary>
        public string AccountId { get; set; }

        /// <summary>
        /// Identificador da transação fraudada.
        /// </summary>
        public string TransactionId { get; set; }

        /// <summary>
        /// Gets or Sets Transaction
        /// </summary>
        public TransactionFraud Transaction { get; set; }

        /// <summary>
        /// Histórico de eventos nessa disputa.
        /// </summary>
        public List<SourceAudit> AuditHistory { get; set; }
    }
}
