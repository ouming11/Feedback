using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Informações de auditoria para registro de informações. São de extrema importância para que se possa rastrear e auditar transações realizadas por meio da API.
    /// </summary>
    [DataContract]
    public class SourceAudit
    {
        /// <summary>
        /// Identificação do operador solicitante. Esta informação é fornecida pelo emissor.
        /// </summary>
        public string OperatorId { get; set; }

        /// <summary>
        /// Identificação do processo solicitante. Esta informação é fornecida pelo emissor.
        /// </summary>
        public string ProcessId { get; set; }
    }
}
