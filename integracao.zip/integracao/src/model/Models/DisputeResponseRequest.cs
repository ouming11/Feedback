using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DisputeResponseRequest
    {
        /// <summary>
        /// Identificador único da resposta disputa. Gerado pelo emissor.
        /// </summary>
        public string IssuerDisputeResponseId { get; set; }

        /// <summary>
        /// Identifica a resposta do credenciador/bandeira deve ser aceita. Se não for aceita o processo de disputa vai para a próxima etapa.
        /// </summary>
        [Required]
        public bool? Accept { get; set; }

        /// <summary>
        /// Mensagem de texto justificando o motivo da continuação da disputa. Só precisa estar presente se accept for falso.
        /// </summary>
        [Required]
        public string DisputeResponseTextMessage { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
