using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class TransactionTransactionAuthorizationResponseProcessadora
    {
        /// <summary>
        /// Gets or Sets Approved
        /// </summary>
        public bool? Approved { get; set; }
    }
}
