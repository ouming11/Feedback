using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using model.Models.Entidades;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class AssociateAnonymousCardRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse
        /// identificador é ecoado na resposta. Nenhuma verificação dele é
        /// feita por parte da integracao, o emissor é livre para escolher o
        /// valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Número do cartão - Primary Account Number (PAN).
        /// </summary>
        [Required]
        public string Pan { get; set; }

        /// <summary>
        /// Código de segurança do cartão.
        /// </summary>
        [Required]
        public string Cvv { get; set; }

        /// <summary>
        /// Data de expiração do cartão.
        /// </summary>
        [Required]
        public DataExpiracaoCartao DataExpiracaoCartao { get; set; }

        /// <summary>
        /// Informações relacionadas ao portador do cartão. Vão ser usadas para associar o cartão anônimo a uma pessoa.
        /// </summary>
        [Required]
        public Portador Cardholder { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}

