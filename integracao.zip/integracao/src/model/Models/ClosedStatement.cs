using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class ClosedStatement
    {
        /// <summary>
        /// id da fatura no formato yyyy-mm ou yyyy-mm-dd para faturas mais recentes.
        /// </summary>
        public string StatementId { get; set; }

        /// <summary>
        /// id do emissor
        /// </summary>
        public string IdIssuer { get; set; }

        /// <summary>
        /// Data de vencimento da fatura
        /// </summary>
        public DateOnly Vencimento { get; set; }

        /// <summary>
        /// Data de vencimento da fatura, levando em conta fins de semana e feriados.
        /// </summary>
        public DateOnly VencimentoEfetivo { get; set; }

        /// <summary>
        /// Gets or Sets MinimumPaymentDue
        /// </summary>
        public DateTime MinimumPaymentDue { get; set; }

        /// <summary>
        /// Transações criadas no processamento da Fatura e já somadas no saldo da fatura fechada. Existem 3 tipos possíveis: Encargos, Multas e Ressarcimento
        /// </summary>
        public List<Transaction> AdditionalTransactionsList { get; set; }

        /// <summary>
        /// Transações fora do período da fatura que foram inseridas quando a fatura ainda estava aberta.
        /// </summary>
        public List<Transaction> OutOfStatementPeriodTransactions { get; set; }

        /// <summary>
        /// Data e hora da última transação inserida na fatura.
        /// </summary>
        public DateTime? FirstTransactionInserted { get; set; }

        /// <summary>
        /// Data e hora da primeira transação inserida na fatura.
        /// </summary>
        public DateTime? LastTransactionInserted { get; set; }

        /// <summary>
        /// Data e hora de abertura da Fatura.
        /// </summary>
        public DateTime? OpeningDateTime { get; set; }

        /// <summary>
        /// Data e hora de fechamento da Fatura.
        /// </summary>
        public DateTime? ClosingDateTime { get; set; }

        /// <summary>
        /// Gets or Sets ChargesInNextStatementForMinimumPayment
        /// </summary>
        public DescritorValor ChargesInNextStatementForMinimumPayment { get; set; }

        /// <summary>
        /// id da fatura anterior no formato yyyy-mm ou yyyy-mm-dd para faturas mais recentes
        /// </summary>
        public string LastStatementId { get; set; }

        /// <summary>
        /// identificador uuid de ultima atualização
        /// </summary>
        public string LastUpdated { get; set; }

        /// <summary>
        /// Custo Efetivo Total.
        /// </summary>
        public DescritorValor CET { get; set; }
    }
}

