using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DetalheDocumento
    {
        /// <summary>
        /// Identificador do documento.
        /// </summary>
        [Required]
        public string IdentificadorDocumento { get; set; }

        /// <summary>
        /// Estado.
        /// </summary>
        [Required]
        public string UF { get; set; }

        /// <summary>
        /// Orgão emissor.
        /// </summary>
        [Required]
        public string Emissor { get; set; }
    }
}
