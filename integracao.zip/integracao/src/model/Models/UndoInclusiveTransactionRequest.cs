using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UndoInclusiveTransactionRequest
    {
        /// <summary>
        /// Gets or Sets InclusiveTransactionId
        /// </summary>
        [Required]
        public string InclusiveTransactionId { get; set; }
    }
}
