using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DisputeDocumentRequest
    {
        /// <summary>
        /// Identificador único do pedido de desistência da disputa. Gerado pelo emissor.
        /// </summary>
        public string IssuerDisputeDocumentId { get; set; }

        /// <summary>
        /// Gets or Sets Document
        /// </summary>
        [Required]
        public DisputeDocument Document { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
