using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using model.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class BindCardRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse identificador é ecoado na resposta. Nenhuma verificação dele é feita por parte da integracao, o emissor é livre para escolher o valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Identificador do cartão que se deseja associar à conta.
        /// </summary>
        [Required]
        public string CardId { get; set; }

        /// <summary>
        /// Número do cartão.
        /// </summary>
        [Required]
        public string Pan { get; set; }

        /// <summary>
        /// Código de segurança do cartão.
        /// </summary>
        [Required]
        public string Cvv { get; set; }

        /// <summary>
        /// Data de expiração do cartão.
        /// </summary>
        [Required]
        public DataExpiracaoCartao DataExpiracaoCartao { get; set; }
    }
}
