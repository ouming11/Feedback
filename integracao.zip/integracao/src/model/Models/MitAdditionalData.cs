using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Este conjunto de dados é utilizado para passar dados de identificação da transação original e do valor da transação original do Estabelecimento Comercial/Credenciador para o Emissor. Utilizado para Pagamentos Parcelados no âmbito internacional (cartões emitidos no Brasil e aceitos internacionalmente). Este modelo é conhecido como “Buy Now Pay Later” e serão oferecidos três tipos de parcelamentos e também o modelo de recorrência. - **Parcelado Emissor**: Identificado pelo domínio “V” no campo “Status de Transação no POS”, nesse formato o estabelecimento recebe o valor total no ato da compra e o Emissor é o responsável pela gestão das regras e cobranças ao portador. O Emissor deve receber, processar e responder a transação em Autorização e Liquidação. Neste modelo o pagamento ao estabelecimento é à vista.  - **Parcelado Loja**: Identificado pelo domínio “S” no campo “Status de Transação no POS”, nesse formato o estabelecimento assume o risco e a responsabilidade pelo recebimento dos valores, onde deve enviar uma solicitação de autorização e uma transação de liquidação para cada parcela no intervalo de tempo acordado com o portador. O Emissor deve estar preparado para receber, processar e responder a todas as transações em autorização e liquidação.  - **Parcelado Participante Terceiro**: Identificado pelo domínio “T” no campo “Status de Transação no POS”, esse formato tem as mesmas regras e responsabilidades do Parcelado Loja, porém a transação é feita por um Estabelecimento provedor de parcelamento para um terceiro Estabelecimento. O Emissor deve receber, processar e responder a todas as transações em Autorização e Liquidação.  - **Transação Recorrente**: Identificado pelo domínio “R” no campo “Status de Transação no POS”, esse formato permite ao Estabelecimento oferecer um produto ou serviço com cobranças recorrentes, sendo de responsabilidade do Estabelecimento enviar no período e frequência acordados com o portador as solicitações de autorização e as transações de liquidação. O Emissor deve receber, processar e responder a todas as transações em Autorização e Liquidação.
    /// </summary>
    [DataContract]
    public class MitAdditionalData
    {
        /// <summary>
        /// Quantidade total de parcelamento.  Indica o número de Pagamentos ou Prestações Recorrentes de acordo com o Contrato do Portador do Cartão com o Estabelecimento.  Valores válidos: - 02 a 99 - ND - Não Definido - UC – Até o Cancelamento
        /// </summary>
        public string InstallmentTotalNbr { get; set; }

        /// <summary>
        /// Indica se um Pagamento Recorrente ou Prestação é um valor fixo ou variável.
        /// </summary>
        public TipoPagamento TipoPagamento { get; set; }

        /// <summary>
        /// Tipo de Transação iniciada pelo Estabelecimento(MIT).
        /// Os valores são usados para processar a primeira transação de
        /// pagamento e as subsequentes.
        /// </summary>
        public TipoTransacaoPagamento? TipoTransacaoPagamento { get; set; }

        /// <summary>
        /// Valor da transação iniciada pelo estabelecimento(MIT). Indica o valor do Parcelamento ou Pagamento Recorrente, e está na mesma moeda do BIT 49 - Código da Moeda, desta Transação. Os valores são usados para processar a primeira e as transações de pagamento subsequentes para esses tipos de pagamento específicos. Este valor pode ser diferente do BIT 04 - Valor da Transação. Esta tag tem regra de alinhamento com zeros à esquerda e duas casas decimais (R$ 50 como 000000005000).
        /// </summary>
        public long? TransactionAmountMIT { get; set; }

        /// <summary>
        /// ID Único. Usado para identificar de forma única cada Pagamento Recorrente ou Parcelado (fornecido automaticamente).  Este ID é usado para fazer referência a autorizações e avisos de autorizações.  Os valores são usados para processar a primeira e as subsequentes Transações com Cartão de uma transação de pagamento.
        /// </summary>
        public string UniqueTransactionID { get; set; }

        /// <summary>
        /// Frequência da transação iniciada pelo estabelecimento(MIT). Indica a frequência de um pagamento ou parcelamento recorrente.   Valores válidos: - daily - Diário - weekly - Semanal - biweekly - Quinzenal - monthly - Mensal - quarterly - Trimestral - semiannual - Semestral - yearly - Anual - unscheduled - Não programado (tipo de transação iniciada pelo estabelecimento - MIT).
        /// </summary>
        public Frequencia? TransactionFrequency { get; set; }

        /// <summary>
        /// Indicador de validação.
        /// O adquirente verifica a transação do cartão com a fonte de validação
        /// e preenche o sinalizador.
        /// </summary>
        public Validacao? ValidationIndicator { get; set; }

        /// <summary>
        /// Referência de validação. Um criptograma gerado pela fonte de validação para cada conta do titular do cartão, para um emissor validar uma transação com cartão. O valor é usado apenas para processar pagamentos recorrentes ou parcelamentos subsequentes.
        /// </summary>
        public string ValidationReference { get; set; }

        /// <summary>
        /// Indicador de sequência. Usado para identificar a sequência das transações quando vários pagamentos parcelados serão enviados. O indicador de sequência é preenchido em ordem crescente.
        /// </summary>
        public int? SequenceIndicator { get; set; }
    }
}
