using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class InternationalData
    {
        /// <summary>
        /// Gets or Sets DollarAmount
        /// </summary>
        public DescritorValor DollarAmount { get; set; }

        /// <summary>
        /// Gets or Sets OriginalAmount
        /// </summary>
        public DescritorValor OriginalAmount { get; set; }

        /// <summary>
        /// Cotação para conversão de câmbio Dólar -&gt; Real
        /// </summary>
        public string DollarRealRate { get; set; }

        /// <summary>
        /// Spread (ou markup) aplicado em transações internacionais
        /// </summary>
        public string Spread { get; set; }
    }
}
