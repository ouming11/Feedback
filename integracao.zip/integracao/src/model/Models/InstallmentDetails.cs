using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class InstallmentDetails
    {
        /// <summary>
        /// Identifica o tipo do financiamento. - interestFree - Sem juros (parcelado lojista) - withInterest - Com juros (parcelado emissor) - cdc - CDC (crédito direto ao cliente)
        /// </summary>
        [Required]
        public TipoFinanciamento FinType { get; set; }

        /// <summary>
        /// Gets or Sets FareAmount
        /// </summary>
        public DescritorValor FareAmount { get; set; }

        /// <summary>
        /// Gets or Sets InsuranceAmount
        /// </summary>
        public DescritorValor InsuranceAmount { get; set; }

        /// <summary>
        /// Gets or Sets ThirdPartiesPaymntAmount
        /// </summary>
        public DescritorValor ThirdPartiesPaymntAmount { get; set; }

        /// <summary>
        /// Gets or Sets RecordsPaymentsAmount
        /// </summary>
        public DescritorValor RecordsPaymentsAmount { get; set; }

        /// <summary>
        /// Gets or Sets IssuerTotalCalculatedAmount
        /// </summary>
        public DescritorValor IssuerTotalCalculatedAmount { get; set; }

        /// <summary>
        /// Identifica a data de pagamento da primeira parcela. Formato - AAMMDD.
        /// </summary>
        public DateOnly DataPrimeiraParcela { get; set; }

        /// <summary>
        /// Quantidade de parcelas (2 inteiros)
        /// </summary>
        [Required]
        [Range(2, 99)]
        public int InstalmntNbr { get; set; }

        /// <summary>
        /// Identifica a taxa de juros mensal. Deve ser informado valor considerando duas casas decimais. Por exemplo, a taxa de 1,23% deve ser enviada como 123.
        /// </summary>
        [Range(1, 99999)]
        public int? MonthlyInterestRate { get; set; }

        /// <summary>
        /// Identifica o custo efetivo total (CET). Deve ser informado valor considerando duas casas decimais. Por exemplo, o custo efetivo total de 20,20% deve ser enviada como 2020.
        /// </summary>
        [Range(1, 9999999)]
        public int? TotalEffectiveCostRateCet { get; set; }

        /// <summary>
        /// Gets or Sets InstalmntAmount
        /// </summary>
        [Required]
        public DescritorValor InstalmntAmount { get; set; }

        /// <summary>
        /// Identifica Taxa Anual de Juros. Deve ser informado valor considerando duas casas decimais. Por exemplo, a taxa anual de juros de 23,41% deve ser enviada como 2341.
        /// </summary>
        [Range(1, 9999999)]
        public int? AnnualInterestRate { get; set; }

        /// <summary>
        /// Gets or Sets InputValue
        /// </summary>
        public DescritorValor InputValue { get; set; }
    }
}
