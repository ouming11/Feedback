using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class PublicKey
    {
        /// <summary>
        /// Gets or Sets KeyData
        /// </summary>
        public string KeyData { get; set; }

        /// <summary>
        /// Gets or Sets KeyId
        /// </summary>
        public string KeyId { get; set; }

        /// <summary>
        /// Gets or Sets KeyExpiration
        /// </summary>
        public long? KeyExpiration { get; set; }
    }
}
