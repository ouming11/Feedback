using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class AddressWithRecipient
    {
        /// <summary>
        /// Nome do destinatário que deve receber os cartoes
        /// </summary>
        public string Recipient { get; set; }

        /// <summary>
        /// Endereço. Nome da rua.
        /// </summary>
        [Required]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Endereço. Número da rua.
        /// </summary>
        [Required]
        [StringLength(5, MinimumLength = 1)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Endereço. Complemento.
        /// </summary>
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Referência próxima para auxílio na localização.
        /// </summary>
        public string Reference { get; set; }

        /// <summary>
        /// Bairro.
        /// </summary>
        [Required]
        public string Neighborhood { get; set; }

        /// <summary>
        /// Cidade.
        /// </summary>
        [Required]
        public string City { get; set; }

        /// <summary>
        /// Estado.
        /// </summary>
        [Required]
        public string State { get; set; }

        /// <summary>
        /// CEP.
        /// </summary>
        [Required]
        public string Zipcode { get; set; }

        /// <summary>
        /// País.
        /// </summary>
        public string Country { get; set; }
    }
}
