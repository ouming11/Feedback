using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CardUnblockRequest
    {
        /// <summary>
        /// Identificador único da requisição de desbloqueio. Gerado pelo emissor.
        /// </summary>
        public string IssuerCardUnblockId { get; set; }

        /// <summary>
        /// Código identificando o tipo de desbloqueio.
        /// </summary>
        [Required]
        public int UnblockCode { get; set; }

        /// <summary>
        /// Motivo do desbloqueio.
        /// </summary>
        public string Reason { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}

