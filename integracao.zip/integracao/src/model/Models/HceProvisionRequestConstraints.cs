﻿using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Restrições de Requisição de Provisionamento de Host-based Card Emulation (HCE)
    /// </summary>
    [DataContract]
    public class HceProvisionRequestConstraints
    {
        /// <summary>
        /// Define o máximo de validações de OTP possíveis para este dispositivo.
        /// </summary>
        public int? MaxOtpCount { get; set; }

        /// <summary>
        /// Define o máximo de tentativas com erro de validação em sequência antes do dispositivo ser bloqueado.
        /// </summary>
        public int? OtpTryLimit { get; set; }
    }
}
