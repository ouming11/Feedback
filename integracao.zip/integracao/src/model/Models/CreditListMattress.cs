using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CreditListMattress
    {
        /// <summary>
        /// Lista de aportes.
        /// </summary>
        public List<CreditMattress> Credits { get; set; }

        /// <summary>
        /// Indica se todos os aportes do período informado foram retornados nessa resposta, ou se ainda existem mais aportes. Caso haja mais aportes é preciso fazer uma nova consulta mudando a data de início para a primeira data que não apareceu na lista retornada.
        /// </summary>
        public bool? HasMoreCredits { get; set; }
    }
}
