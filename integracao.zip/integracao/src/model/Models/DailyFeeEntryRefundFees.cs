using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Encargos restituídos devido a cobrança prevista
    /// </summary>
    [DataContract]
    public class DailyFeeEntryRefundFees
    {
        /// <summary>
        /// Saldo fianciado da base anterior dos calculos previstos
        /// </summary>
        public int? OutdatedFinanced { get; set; }

        /// <summary>
        /// Restituição de encargo de IOF sobre valor previsto
        /// </summary>
        public int? IOFRefund { get; set; }

        /// <summary>
        /// Restituição de encargo de Rotativo sobre valor previsto
        /// </summary>
        public int? InterestRefund { get; set; }
    }
}
