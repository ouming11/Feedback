using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;
using PrbCartao.Integracao.Operacoes;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Transaction : Transacao
    {
        /// <summary>
        /// Identificador da transação atribuído pela integracao.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Data e hora da transação.
        /// </summary>
        [Required]
        public DateTime DataHoraTransacao { get; set; }

        /// <summary>
        /// Data e hora do recebimento na liquidação/
        /// </summary>
        public DateTime? DataHoraLiquidacao { get; set; }

        /// <summary>
        /// Gets or Sets TransactionAuthorizationResponse
        /// </summary>
        public TransactionAuthorizationResponse TransactionAuthorizationResponse { get; set; }

        /// <summary>
        /// Código de identificação da rede de captura da transação.
        /// </summary>
        public string AcquirerId { get; set; }

        /// <summary>
        /// Identificador da transação na rede de captura.
        /// </summary>
        public string AcquirerTransactionId { get; set; }

        /// <summary>
        /// Identificação do estabelecimento informada na autorização.
        /// </summary>
        public string MerchantId { get; set; }

        /// <summary>
        /// Nome do estabelecimento.
        /// </summary>
        public string MerchantName { get; set; }

        /// <summary>
        /// CNPJ do estabelecimento.
        /// </summary>
        public string MerchantDocumentId { get; set; }

        /// <summary>
        /// Endereço do estabelecimento.
        /// </summary>
        public string MerchantAddress { get; set; }

        /// <summary>
        /// Cidade do estabelecimento.
        /// </summary>
        public string MerchantCity { get; set; }

        /// <summary>
        /// Uf do estabelecimento
        /// </summary>
        public string MerchantUf { get; set; }

        /// <summary>
        /// Código do país conforme ISO 3166-1.
        /// </summary>
        public string CountryCode { get; set; }

        /// <summary>
        /// MCC da transação
        /// </summary>
        public string Mcc { get; set; }

        /// <summary>
        /// Identificação do terminal informada na autorização.
        /// </summary>
        public string TerminalId { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// Tipo da transação. * Débito: retirando fundos da conta * Crédito: adicionando fundos na conta
        /// </summary>
        public string DebitOrCredit { get; set; }

        /// <summary>
        /// Gets or Sets RemainingAmount
        /// </summary>
        public DescritorValor RemainingAmount { get; set; }

        /// <summary>
        /// Gets or Sets RefundedAmount
        /// </summary>
        public DescritorValor RefundedAmount { get; set; }

        /// <summary>
        /// Gets or Sets EntryMode
        /// </summary>
        public ModoEntradaPan EntryMode { get; set; }

        /// <summary>
        /// Se transação foi realizada por meio de um cartão, os dados do cartão são representados por este campo.
        /// </summary>
        public CardQueryResult Card { get; set; }

        /// <summary>
        /// Identificador da transação que realizou o estorno dessa transação. Deprecado. Será substituído progressivamente pelo cancellingTransactionIds (lista de IDs de transações de cancelamento/estornos).
        /// </summary>
        public string CancellingTransactionId { get; set; }

        /// <summary>
        /// Lista contendo um ou mais identificadores de transações de estorno.
        /// </summary>
        public List<string> CancellingTransactionIds { get; set; }

        /// <summary>
        /// Indica se a transação for uma transação internacional. Falso se for uma transação doméstica.
        /// </summary>
        public bool? International { get; set; }

        /// <summary>
        /// Se transação for internacional, contêm dados referentes a esse tipo de transação.
        /// </summary>
        public InternationalData InternationalTransactionData { get; set; }

        /// <summary>
        /// Indica se esta transação é um aviso de autorização (true) ou é uma requisição que foi validada pelo emissor (false ou não informado).
        /// </summary>
        public bool? AuthorizationAdvice { get; set; }

        /// <summary>
        /// Gets or Sets MitAdditionalData
        /// </summary>
        public MitAdditionalData MitAdditionalData { get; set; }

        /// <summary>
        /// Gets or Sets AdditionalTerminalData
        /// </summary>
        public DadosAdicionaisTerminal AdditionalTerminalData { get; set; }

        /// <summary>
        /// Gets or Sets TokenPaymentData
        /// </summary>
        public TokenPaymentData TokenPaymentData { get; set; }

        /// <summary>
        /// Gets or Sets InstallmentDetails
        /// </summary>
        public InstallmentDetails InstallmentDetails { get; set; }

        /// <summary>
        /// Produto
        /// </summary>
        public Produto Produto { get; set; }

        /// <summary>
        /// Código postal do vendedor
        /// </summary>
        public string MerchantZipcode { get; set; }

        /// <summary>
        /// Gets or Sets TransactionSource
        /// </summary>
        public Origem TransactionSource { get; set; }

        /// <summary>
        /// Data da transação.
        /// </summary>
        public DateTime DataTransacao { get; set; }

        /// <summary>
        /// Incremento de pré-autorização
        /// </summary>
        public bool? Incremental { get; set; }

        /// <summary>
        /// Identificador único da disputa na integracao.
        /// </summary>
        public string DisputeId { get; set; }

        /// <summary>
        /// Gets or Sets DisputeStatus
        /// </summary>
        public SituacaoDisputa DisputeStatus { get; set; }

        /// <summary>
        /// Gets or Sets Fees
        /// </summary>
        public List<Tarifa> Tarifass { get; set; }

        /// <summary>
        /// Gets or Sets Installments
        /// </summary>
        public List<Installment> Installments { get; set; }

        /// <summary>
        /// Gets or Sets UndoData
        /// </summary>
        public UndoData UndoData { get; set; }

        /// <summary>
        /// Identificador da transação orignal atribuído pela integracao. Incluído em transações de estorno, autorizações que concluem pré-autorização, etc;
        /// </summary>
        public string OriginalTransaction { get; set; }

        /// <summary>
        /// Gets or Sets TransactionAuthorizationResponseProcessadora
        /// </summary>
        public TransactionTransactionAuthorizationResponseProcessadora TransactionAuthorizationResponseProcessadora { get; set; }

        /// <summary>
        /// Gets or Sets TransferData
        /// </summary>
        public TransferData TransferData { get; set; }

        /// <summary>
        /// Gets or Sets FraudData
        /// </summary>
        public FraudData FraudData { get; set; }

        /// <summary>
        /// Data do recebimento na liquidação.
        /// </summary>
        public DateTime? SettlementDate { get; set; }

        /// <summary>
        /// Motivo do cancelamento da transação. Presente somente em transações canceladas por expiração de prazo.
        /// </summary>
        public RazaoCancelamento? CancellationReason { get; set; }
    }
}
