using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using model.Models.Entidades;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class VirtualCardConstraints
    {
        /// <summary>
        /// Valor máximo permitido por transação, se o valor for zerro não há
        /// limite superior para o valor das transações.
        /// </summary>
        [Required]
        public DescritorValor ValorMaximo { get; set; }

        /// <summary>
        /// Data de expiração do cartão virtual
        /// </summary>
        [Required]
        public DataExpiracaoCartao ExpirationTimestamp { get; set; }
    }
}
