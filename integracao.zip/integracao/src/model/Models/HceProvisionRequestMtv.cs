using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Requisição de Provisionamento de Host-based Card Emulation (HCE) no Mobile Token Vault (MTV)
    /// </summary>
    [DataContract]
    public class HceProvisionRequestMtv
    {
        /// <summary>
        /// Dados protegidos gerados no Mobile Token Vault.
        /// </summary>
        [Required]
        public string ProvData { get; set; }

        /// <summary>
        /// Identificador único do dispositivo, fornecido pelo emissor.
        /// </summary>
        [Required]
        public string IssuerDeviceId { get; set; }
    }
}
