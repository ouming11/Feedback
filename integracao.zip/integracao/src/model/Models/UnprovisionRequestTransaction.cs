using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UnprovisionRequestTransaction
    {
        /// <summary>
        /// Código identificando o tipo de cancelamento.
        /// </summary>
        public string IssuerCancellationCode { get; set; }

        /// <summary>
        /// Motivo do cancelamento.
        /// </summary>
        public string IssuerCancellationReason { get; set; }
    }
}
