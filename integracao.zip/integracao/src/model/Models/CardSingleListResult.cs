using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CardSingleListResult
    {
        /// <summary>
        /// Lista de cartões.
        /// </summary>
        public List<Card> Cards { get; set; }
    }
}

