using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CardBlockRequest
    {
        /// <summary>
        /// Identificador único da requisição de bloqueio. Gerado pelo emissor.
        /// </summary>
        public string IssuerCardBlockId { get; set; }

        /// <summary>
        /// Código identificando o tipo de bloqueio.
        /// </summary>
        [Required]
        public int BlockCode { get; set; }

        /// <summary>
        /// Motivo do bloqueio.
        /// </summary>
        [MaxLength(100)]
        public string Reason { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
