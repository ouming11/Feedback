namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Origem da transação.
    /// </summary>
    public enum Origem
    {
        /// <summary>
        /// A origem é desconhecida ou não aplicável.
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// A origem da transação é no emissor Paraná Banco.
        /// </summary>
        Emissor = 1,

        /// <summary>
        /// A origem da transação é na processadora.
        /// </summary>
        Processadora = 2,
    }
}