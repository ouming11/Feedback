namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Motivo do cancelamento da transação.
    /// Presente somente em transações canceladas por expiração de prazo.
    /// </summary>
    public enum RazaoCancelamento
    {
        /// <summary>
        /// A transação expirou
        /// </summary>
        Expirada = 0
    }
}