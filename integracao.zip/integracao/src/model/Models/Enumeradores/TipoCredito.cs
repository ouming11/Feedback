namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de crédito realizado.
    /// </summary>
    public enum TipoCredito
    {
        /// <summary>
        /// Pagamento. Um pagamento de fatura, divida, parcela, etc.
        /// </summary>
        Pagamento = 0,

        /// <summary>
        /// Ajuste. Um ajuste contábil.
        /// </summary>
        Ajuste = 1
    }
}