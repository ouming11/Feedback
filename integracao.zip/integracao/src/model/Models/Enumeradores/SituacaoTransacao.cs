﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Situação da transação.
    /// </summary>
    public enum SituacaoTransacao
    {
        /// <summary>
        /// Desconhecido.
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// A transação está em fase de processamento.
        /// </summary>
        EmProcessamento = 1,

        /// <summary>
        /// A transação processou corretamente.
        /// </summary>
        Processada = 2,

        /// <summary>
        /// A transação foi cancelada.
        /// </summary>
        Cancelada = 3,

        /// <summary>
        /// A transação foi estornada.
        /// </summary>
        Estornada = 4,

        /// <summary>
        /// A transação está com problema de processamento.
        /// </summary>
        Falha = 5,

        /// <summary>
        /// Em disputa.
        /// </summary>
        EmDisputa = 6,

        /// <summary>
        /// Reembolsada
        /// </summary>
        Reembolsada = 7,

        /// <summary>
        /// Reembolsada parcialmente
        /// </summary>
        ReembolsadaParcialmente = 8
    }
}
