namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Indica qual o tipo da funcionalidade.
    /// </summary>
    public enum TipoFuncionalidade
    {
        /// <summary>
        /// Aproximação
        /// </summary>
        Aproximacao = 0,

        /// <summary>
        /// Tarja magnética
        /// </summary>
        TarjaMagnetica = 1,

        /// <summary>
        /// ECommerce
        /// </summary>
        ECommerce = 2,

        /// <summary>
        /// Saque
        /// </summary>
        Saque = 3
    }
}