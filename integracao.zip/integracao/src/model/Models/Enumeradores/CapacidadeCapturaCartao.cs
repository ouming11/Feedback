namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Capacidade de Captura de Cartão.
    /// </summary>
    public enum CapacidadeCapturaCartao
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Terminal (POS)/Operador tem capacidade de captura de cartão
        /// </summary>
        TerminalCapturaCartao = 1,

        /// <summary>
        /// Terminal (POS)/Operador não tem capacidade de captura de cartão
        /// </summary>
        TerminalSemCapturaCartao = 2
    }
}