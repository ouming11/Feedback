﻿using System;
namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de endereço.
    /// </summary>
    public enum TipoEndereco
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Residencial
        /// </summary>
        Residencial = 1,

        /// <summary>
        /// Comercial
        /// </summary>
        Comercial = 2,

        /// <summary>
        /// Correspondência
        /// </summary>
        Correspondencia = 3
    }
}

