namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Situação do cartão
    /// </summary>
    public enum SituacaoCartao
    {
        /// <summary>
        /// Desconhecido.
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Solicitado.
        /// </summary>
        Solicitado = 1,

        /// <summary>
        /// A emissão do cartão foi negada
        /// </summary>
        Negado = 2,

        /// <summary>
        /// Em processo de emissão.
        /// </summary>
        EmEmissao = 3,

        /// <summary>
        /// Enviado para o titular.
        /// </summary>
        EmTransito = 4,

        /// <summary>
        /// Bloqueado.
        /// </summary>
        Bloqueado = 5,

        /// <summary>
        /// Ativo.
        /// </summary>
        Ativo = 6,

        /// <summary>
        /// Cancelado.
        /// </summary>
        Cancelado = 7
    }
}