namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Modo usado para validar o portador.
    /// </summary>
    public enum ModoValidacaoDoPortador
    {
        /// <summary>
        /// Online
        /// </summary>
        Online = 0,

        /// <summary>
        /// Offline
        /// </summary>
        Offline = 1,

        /// <summary>
        /// Outro
        /// </summary>
        Outro = 2
    }
}