namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de portador
    /// </summary>
    public enum TipoPortador
    {
        /// <summary>
        /// Portador titular
        /// </summary>
        Titular = 0,

        /// <summary>
        /// Portador adicional
        /// </summary>
        Adicional = 1
    }
}