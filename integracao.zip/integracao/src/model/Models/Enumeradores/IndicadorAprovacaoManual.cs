namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Indicador de Aprovação Parcial.
    /// </summary>
    public enum IndicadorAprovacaoManual
    {
        /// <summary>
        /// Aprovação Parcial não suportada.
        /// </summary>
        NaoSuportada = 0,

        /// <summary>
        /// Compras podem ser aprovadas parcialmente.
        /// Saque pode ser aprovado parcialmente.
        /// </summary>
        CompraESaqueParcial = 1,

        /// <summary>
        /// Compras podem ser aprovadas parcialmente.
        /// Saque deve ser aprovado por completo ou declinado.
        /// </summary>
        CompraParcial = 2,

        /// <summary>
        /// Compras podem ser aprovadas por completo ou declinadas.
        /// Saque pode ser aprovado parcialmente.
        /// </summary>
        SaqueParcial = 3,

        /// <summary>
        /// Compras podem ser aprovadas por completo ou declinadas.
        /// Saque deve ser aprovado por completo ou declinado
        /// </summary>
        CompraESaqueCompleto = 4
    }
}