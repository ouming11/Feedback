namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Presença do Cartão.
    /// </summary>
    public enum PresencaDoCartao
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Cartão presente
        /// </summary>
        Presente = 1,

        /// <summary>
        /// Cartão não presente
        /// </summary>
        NaoPresente = 2
    }
}