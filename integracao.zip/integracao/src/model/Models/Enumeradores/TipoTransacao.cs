﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Identifica qual é o tipo da transação.
    /// </summary>
    public enum TipoTransacao
    {
        /// <summary>
        /// Desconhecida ou não informada
        /// </summary>
        Desconhecida = 0,

        /// <summary>
        /// Uso do cartão para compra de bens e serviços.
        /// </summary>
        CompraAVista = 1,

        /// <summary>
        /// Uso do cartão para compra parcelada de bens e serviços
        /// </summary>
        CompraParcelada = 2,

        /// <summary>
        /// Saque no caixa
        /// </summary>
        Saque = 3,

        /// <summary>
        /// Saque no estabelecimento, pode ser PB
        /// </summary>
        SaqueEstabelecimento = 4,

        /// <summary>
        /// Consulta e simulação de vendas e saques, com CET (Custo Efetivo Total)
        /// </summary>
        Simulacao = 5,

        /// <summary>
        /// Compra com cartão com retenção de dinheiro pelo portador
        /// </summary>
        CompraComSaque = 6,

        /// <summary>
        /// Obtenção de fundos de uma conta cartão com propósito de realizar uma transferência.
        /// </summary>
        Retirada = 7,

        /// <summary>
        /// Fornece o endereço para um faturamento recorrente.
        /// </summary>
        VerificacaoEndereco = 8,

        /// <summary>
        /// Cobrança recorrente (mensal, bimestral, etc)
        /// </summary>
        CobrancaRecorrente = 9,

        /// <summary>
        /// Pagamento de assinatura em uma base regular (anualmente, por exemplo)
        /// </summary>
        Assinatura = 10,

        /// <summary>
        /// Verificação do número da conta do cartão e opcionalmente validar a identidade do portador do cartão
        /// </summary>
        VerificacaoContaCartao = 11,

        /// <summary>
        /// Devolução de mercadorias
        /// </summary>
        DevolucaoMercadoria = 12,

        /// <summary>
        /// Carregamento de cartão pré-pago com valores monetários
        /// </summary>
        CarregamentoCartao = 13,

        /// <summary>
        /// Retorna o valor que pode ser obtido da fonte
        /// </summary>
        ConsultaFudosDisponiveis = 14,

        /// <summary>
        /// Consulta do saldo disponível na conta ou no cartão
        /// </summary>
        ConsultaSaldo = 15,

        /// <summary>
        /// Consulta de saldo para um produto específico
        /// </summary>
        ConsultaSaldoProdutoEspecifico = 16,

        /// <summary>
        /// Transferência (de uma conta para outra, por exemplo)
        /// </summary>
        Transferencia = 17,

        /// <summary>
        /// Transferência de fundos que são adicionados a uma conta de cartão ou à uma conta de depósito.
        /// </summary>
        TransferenciaFundos = 18,

        /// <summary>
        /// Mudança de PIN
        /// </summary>
        MudancaPIN = 19,

        /// <summary>
        /// Desbloqueio de PIN
        /// </summary>
        DesbloqueioPIN = 20,
    }
}
