﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de Parcelamento
    /// </summary>
	public enum TipoParcelamento
    {
        /// <summary>
        /// Desconhecido ou não informado.
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// O estabelecimento recebe o valor total no ato da
        /// compra e o Emissor é o responsável pela gestão das regras e
        /// cobranças ao portador. O Emissor deve receber, processar e responder
        /// a transação em Autorização e Liquidação. Neste modelo o pagamento ao
        /// estabelecimento é à vista.
        /// </summary>
        ParceladoEmissor = 1,

        /// <summary>
        /// O estabelecimento assume o risco e a responsabilidade pelo
        /// recebimento dos valores, onde deve enviar uma solicitação de
        /// autorização e uma transação de liquidação para cada parcela no
        /// intervalo de tempo acordado com o portador. O Emissor deve estar
        /// preparado para receber, processar e responder a todas as transações
        /// em autorização e liquidação.
        /// </summary>
        ParceladoLoja = 2,

        /// <summary>
        /// Tem as mesmas regras e responsabilidades do Parcelado Loja, porém a
        /// transação é feita por um Estabelecimento provedor de parcelamento
        /// para um terceiro Estabelecimento. O Emissor deve receber, processar
        /// e responder a todas as transações em Autorização e Liquidação.
        /// </summary>
        ParceladoParticipanteTerceiro = 3,

        /// <summary>
        /// Permite ao Estabelecimento oferecer um produto ou serviço com
        /// cobranças recorrentes, sendo de responsabilidade do Estabelecimento
        /// enviar no período e frequência acordados com o portador as
        /// solicitações de autorização e as transações de liquidação. O Emissor
        /// deve receber, processar e responder a todas as transações em
        /// Autorização e Liquidação.
        /// </summary>
        TransacaoRecorrente = 4
    }
}

