﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Frequência da transação iniciada pelo estabelecimento (MIT).
    /// Indica a frequência de um pagamento ou parcelamento recorrente.
    /// </summary>
    public enum Frequencia
    {
        /// <summary>
        /// Não programado (tipo de transação iniciada pelo estabelecimento - MIT).
        /// </summary>
        NaoProgramado = 0,

        /// <summary>
        /// Diário.
        /// </summary>
        Diario = 1,

        /// <summary>
        /// Semanal
        /// </summary>
        Semanal = 2,

        /// <summary>
        /// Quinzenal
        /// </summary>
        Quinzenal = 3,

        /// <summary>
        /// Mensal
        /// </summary>
        Mensal = 4,

        /// <summary>
        /// Trimestral
        /// </summary>
        Trimestral = 5,

        /// <summary>
        /// Semestral
        /// </summary>
        Semestral = 6,

        /// <summary>
        /// Anual
        /// </summary>
        Anual = 7
    }
}

