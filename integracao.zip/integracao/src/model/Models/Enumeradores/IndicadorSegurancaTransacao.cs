namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Indicador de Segurança da Transação.
    /// Este subcampo será preenchido pelo Estabelecimento para indicar se
    /// existe suspeita de fraude ou não.
    /// </summary>
    public enum IndicadorSegurancaTransacao
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// 
        /// </summary>
        SemSuspeita = 1,

        /// <summary>
        /// Existe suspeita por parte do estabelecimento comercial.
        /// </summary>
        ComSuspeita = 2,

        /// <summary>
        /// Foram verificados os documentos do portador
        /// </summary>
        DocumentosPortadorVerificados = 3
    }
}