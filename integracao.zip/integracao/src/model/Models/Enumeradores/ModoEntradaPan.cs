﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Modo usado para a entrada do Número do Cartão - Primary Account Number (PAN).
    /// </summary>    
    public enum ModoEntradaPan
    {
        /// <summary>
        /// Quando o modo de entrada é desconhecido ou nenhum outro campo é aplicável.
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Cartão passado via tarja (tecnologia MST também usa).Cartão passado via tarja (tecnologia MST também usa).
        /// </summary>
        TarjaMagnetica = 1,

        /// <summary>
        /// Tarja magnética quando usada como fallback do chip.
        /// </summary>
        Fallback = 2,

        /// <summary>
        /// Transação com chip via contato.
        /// </summary>
        Chip = 3,

        /// <summary>
        /// Transações pela internet usando browser em um computador.
        /// </summary>
        Ecommerce = 4,

        /// <summary>
        /// Transações pela internet usando dispositivo móvel (por aplicativos ou browser mobile)
        /// </summary>
        Mcommerce = 5,

        /// <summary>
        /// Transação digitada manualmente.
        /// </summary>
        Digitada = 6,

        /// <summary>
        /// Transações contactless, tanto com cartão quanto com dispositivos móveis.
        /// </summary>
        Aproximacao = 7,

        /// <summary>
        /// Transação com cartão não presente usando informações de cartão armazenadas.
        /// </summary>
        Armazenada = 8,

        /// <summary>
        /// Número de cartão lido por código e barras ou QR code.
        /// </summary>
        BarrasOuQrCode = 9,

        /// <summary>
        /// Entrada por URA.
        /// </summary>
        Ura = 10
    }
}