namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Sexo
    /// </summary>
    public enum Sexo
    {
        /// <summary>
        /// Outro ou não informado
        /// </summary>
        Outro = 0,

        /// <summary>
        /// Masculino
        /// </summary>
        Masculino = 1,

        /// <summary>
        /// Feminino
        /// </summary>
        Feminino = 2
    }
}