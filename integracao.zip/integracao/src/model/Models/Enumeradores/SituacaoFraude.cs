namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Estado atual da notificação de fraude.
    /// </summary>
    public enum SituacaoFraude
    {
        /// <summary>
        /// Notificada
        /// </summary>
        Notificada = 0,

        /// <summary>
        /// Desfeita
        /// </summary>
        Desfeita = 1
    }
}
