﻿using System;
namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de filiação.
    /// </summary>
    public enum TipoFiliacao
    {
        /// <summary>
        /// Mãe
        /// </summary>
        Mae = 0,

        /// <summary>
        /// Pai
        /// </summary>
        Pai = 1
    }
}

