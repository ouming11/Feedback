namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de débito realizado.
    /// </summary>
    public enum TipoDebito
    {
        /// <summary>
        /// Taxa de anuidade
        /// </summary>
        Anuidade = 0,

        /// <summary>
        /// Taxa de emissão
        /// </summary>
        Emissao = 1,

        /// <summary>
        /// Taxa de reemissão
        /// </summary>
        Reemissao = 2,

        /// <summary>
        /// Taxa de renovação
        /// </summary>
        Renovacao = 3,

        /// <summary>
        /// Ajuste
        /// </summary>
        Ajuste = 4
    }
}