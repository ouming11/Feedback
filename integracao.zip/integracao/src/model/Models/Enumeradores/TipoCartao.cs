namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo do Cartão.
    /// </summary>
    public enum TipoCartao
    {
        /// <summary>
        /// Crédito
        /// </summary>
        Credito = 0,

        /// <summary>
        /// Débito
        /// </summary>
        Debito = 1,

        /// <summary>
        /// Voucher
        /// </summary>
        Voucher = 2,

        /// <summary>
        /// Frota
        /// </summary>
        Frota = 3,

        /// <summary>
        /// Combo
        /// </summary>
        Combo = 4
    }
}