namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Situação atual da disputa.
    /// </summary>
    public enum SituacaoDisputa
    {
        /// <summary>
        /// Aguardando resposta do emissor.
        /// </summary>
        AguardandoRespostaEmissor = 0,

        /// <summary>
        /// Aguardando resposta do solicitante.
        /// </summary>
        AguardandoRespostaSolicitante = 1,

        /// <summary>
        /// Aguardando resposta da bandeira.
        /// </summary>
        AguardandoRespostaBandeira = 2,

        /// <summary>
        /// Aceita
        /// </summary>
        Aceita = 3,

        /// <summary>
        /// Negada
        /// </summary>
        Negada = 4,

        /// <summary>
        /// EmissorVenceu
        /// </summary>
        EmissorVenceu = 5,

        /// <summary>
        /// EmissorPerdeu
        /// </summary>
        EmissorPerdeu = 6,

        /// <summary>
        /// Cancelada
        /// </summary>
        Cancelada = 7
    }
}
