namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Formato do PINBlock
    /// </summary>
    public enum Iso
    {
        /// <summary>
        /// ISO-0
        /// </summary>
        Iso0 = 0,

        /// <summary>
        /// ISO-1
        /// </summary>
        Iso1 = 1
    }
}