namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo do Terminal (Dispositivo).
    /// </summary>
    public enum TipoTerminal
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Não especificado
        /// </summary>
        NaoEspecificado = 1,

        /// <summary>
        /// Point Of Sale
        /// </summary>
        Pos = 2,

        /// <summary>
        /// Mobile Point Of Sale (MPOS)
        /// </summary>
        MPos = 3,

        /// <summary>
        /// Automated Teller Machine (ATM)
        /// </summary>
        Atm = 4,

        /// <summary>
        /// Transferencia Eletrônica de Fundos (TEF)
        /// </summary>
        Tef = 5,

        /// <summary>
        /// Dispositivo Móvel (ex: smartphone)
        /// </summary>
        DispositivoMovel = 6
    }
}