namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Localização do Terminal.
    /// </summary>
    public enum LocalizacaoTerminal
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Local, no estabelecimento comercial
        /// </summary>
        Local = 1,

        /// <summary>
        /// Fora do estabelecimento comercial (terminal remoto)
        /// </summary>
        Remoto = 2,

        /// <summary>
        /// Junto ao portador (ex: e-Commerce)
        /// </summary>
        JuntoAoPortador = 3,

        /// <summary>
        /// Sem terminal (ex: URA)
        /// </summary>
        SemTerminal = 4
    }
}