namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Capacidade de Entrada do Terminal.
    /// </summary>
    public enum CapacidadeEntradaTerminal
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Sem Terminal (URA/Voz)
        /// </summary>
        SemTerminal = 1,

        /// <summary>
        /// Leitor de tarja magnética
        /// </summary>
        TarjaMagnetica = 2,

        /// <summary>
        /// Leitor de código de barras
        /// </summary>
        CodigoBarras = 3,

        /// <summary>
        /// Leitor OCR
        /// </summary>
        Ocr = 4,

        /// <summary>
        /// Leitor de CHIP
        /// </summary>
        Chip = 5,

        /// <summary>
        /// Digitado
        /// </summary>
        Digitado = 6,

        /// <summary>
        /// Leitor de tarja magnética e digitado
        /// </summary>
        LeitorTarjaEDigitado = 7,

        /// <summary>
        /// Radio Frequency Identification (RFID), CHIP e aproximação
        /// </summary>
        RfidChipAproximacao = 8,

        /// <summary>
        /// Híbrido – CHIP e Aproximação
        /// </summary>
        Hibrido = 9,

        /// <summary>
        /// Radio Frequency Identification (RFID) e Trilha Magnética
        /// </summary>
        RfidETarjaMargnetica = 10,

        /// <summary>
        /// Secure Eletronic Transaction (SET) com certificado
        /// </summary>
        SetComCertificado = 11,

        /// <summary>
        /// Secure Eletronic Transaction (SET) sem certificado
        /// </summary>
        SetSemCertificado = 12,

        /// <summary>
        /// Transação eletrônica vica canal criptografado (SSL)
        /// </summary>
        Ssl = 13,

        /// <summary>
        /// Transação eletrônica via canal inseguro 
        /// </summary>
        Insegura = 14
    }
}