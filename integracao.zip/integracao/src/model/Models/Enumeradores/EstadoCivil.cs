namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Estado civil.
    /// </summary>
    public enum EstadoCivil
    {
        /// <summary>
        /// Desconhecido, não informado ou outro.
        /// </summary>
        Outro = 0,

        /// <summary>
        /// Solteiro(a)
        /// </summary>
        Solteiro = 1,

        /// <summary>
        /// Casado(a)
        /// </summary>
        Casado = 2,

        /// <summary>
        /// Divorciado(a)
        /// </summary>
        Divorciado = 3,

        /// <summary>
        /// Viuvo(a)
        /// </summary>
        Viuvo = 4,

        /// <summary>
        /// Separado Judicialmente
        /// </summary>
        SeparadoJudicialmente = 5,

        /// <summary>
        /// União Estável
        /// </summary>
        UniaoEstavel = 6
    }
}