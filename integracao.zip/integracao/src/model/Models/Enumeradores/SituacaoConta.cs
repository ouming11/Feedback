namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Situação da conta.
    /// </summary>
    public enum SituacaoConta
    {
        /// <summary>
        /// Conta ativa
        /// </summary>
        Ativa = 0,

        /// <summary>
        /// Conta cancelada
        /// </summary>
        Cancelada = 1,

        /// <summary>
        /// Conta fechada
        /// </summary>
        Fechada = 2,

        /// <summary>
        /// Conta bloqueada
        /// </summary>
        Bloqueada = 3,

        /// <summary>
        /// Conta enquadrada
        /// </summary>
        Enquadrada = 4,

        /// <summary>
        /// Conta requisitada e em processo de criação
        /// </summary>
        Requisitada = 5,

        /// <summary>
        /// Requisição foi recebida mas posteriormente negada por algum motivo
        /// </summary>
        RequisicaoNegada = 6
    }
}
