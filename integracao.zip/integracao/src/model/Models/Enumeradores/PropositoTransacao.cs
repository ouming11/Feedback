namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Propósito da solicitação.
    /// </summary>
    public enum PropositoTransacao
    {
        /// <summary>
        /// Solicitação normal (apresentação original)
        /// </summary>
        Normal = 0,

        /// <summary>
        /// Solicitação de Pré-Autorização
        /// </summary>
        PreAutorizacao = 1,

        /// <summary>
        /// Re-autorização do valor total (Ex.: após expiração do prazo de Liquidação), Recuperação de Dívida
        /// </summary>
        ReAutorizacao = 2,

        /// <summary>
        /// Venda atrasada (Ex.: danos em hotel ou em aluguel de carro)
        /// </summary>
        VendaAtrasada = 3,

        /// <summary>
        /// Re-tentativa de autorização (Ex.: saldo insuficiente ou limite excedido)
        /// </summary>
        Retentativa = 4,

        /// <summary>
        /// Transação agregada (modelo concentrado) utilizada no sistema de transportes
        /// </summary>
        TransacaoAgregada = 5,

        /// <summary>
        /// Autorização Incremental
        /// </summary>
        Incremental = 6,

        /// <summary>
        /// Cobrança de não comparecimento (No-Show)
        /// </summary>
        NaoComparecimento = 7,

        /// <summary>
        /// Envio Dividido/Parcial (Ex.: Envio mediante disponibilidade)
        /// </summary>
        EnvioDividido = 8,

        /// <summary>
        /// Pagamento Recorrente
        /// </summary>
        Recorrente = 9,

        /// <summary>
        /// Pagamento Parcelado Loja/Estabelecimento
        /// </summary>
        ParceladoEstabelecimento = 10,

        /// <summary>
        /// Pagamento Parcelado por Participante Terceiro
        /// </summary>
        ParceladoTerceiro = 11,

        /// <summary>
        /// Pagamento não programado (Ex.: transação que não ocorre em uma data programada ou regularmente, por exemplo, a recarga automática de um celular pré-pago)
        /// </summary>
        NaoProgramado = 12,

        /// <summary>
        /// Pagamento Parcelado Emissor/Crediários
        /// </summary>
        ParceladoEmissor = 13,

        /// <summary>
        /// Compra de Criptomoeda
        /// </summary>
        CompraCriptomoeda = 14
    }
}