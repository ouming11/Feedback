﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo da tarifa
    /// </summary>
    public enum TipoTarifa
    {
        /// <summary>
        /// IOF
        /// </summary>
        Iof = 0,

        /// <summary>
        /// Emissão
        /// </summary>
        Emissao = 1,

        /// <summary>
        /// Saque
        /// </summary>
        Saque = 2,

        /// <summary>
        /// Juros
        /// </summary>
        Juros = 3,

        /// <summary>
        /// Outros
        /// </summary>
        Outros = 4
    }
}
