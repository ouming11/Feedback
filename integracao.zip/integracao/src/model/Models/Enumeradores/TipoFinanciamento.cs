﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Identifica o tipo do financiamento.
    /// </summary>
    public enum TipoFinanciamento
    {
        /// <summary>
        /// Sem juros (parcelado lojista)
        /// </summary>
        SemJuros = 0,

        /// <summary>
        /// Com juros (parcelado emissor)
        /// </summary>
        ComJuros = 1,

        /// <summary>
        /// CDC (crédito direto ao cliente)
        /// </summary>
        Cdc = 2
    }
}

