namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Presença do Portador.
    /// </summary>
    public enum PresencaDoPortador
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Portador presente.
        /// </summary>
        Presente = 1,

        /// <summary>
        /// Portador não presente (ex: pedido via correspondência)
        /// </summary>
        NaoPresente = 2,

        /// <summary>
        /// Digital (ex: e-Commerce)
        /// </summary>
        Digital = 3,
    }
}