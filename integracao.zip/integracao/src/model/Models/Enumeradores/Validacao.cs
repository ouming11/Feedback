﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Indicador de validação. O adquirente verifica a transação do cartão
    /// com a fonte de validação e preenche o sinalizador.
    /// </summary>
    public enum Validacao
    {
        /// <summary>
        /// Transação de cartão validada. O credenciador verificou a fonte
        /// de validação para uma transação com cartão.
        /// </summary>
        Validado = 0,

        /// <summary>
        /// Transação de cartão não foi validada. O credenciador não
        /// executou a validação. O valor é usado apenas para processar
        /// pagamentos recorrentes ou parcelamentos subsequentes.
        /// </summary>
        NaoValidado = 1
    }
}
