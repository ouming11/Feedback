namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Estágio atual do processo de disputa.
    /// </summary>
    public enum EstagioDaDisputa
    {
        /// <summary>
        /// Estado inicial
        /// </summary>
        Inicial = 0,

        /// <summary>
        /// Devolutiva negativa do credenciador, o emissor deve escolher se quer continuar com a disputa ou não.
        /// </summary>
        DevolutivaNegativa = 1,

        /// <summary>
        /// O processo que é feito entre emissor e credenciador, para assim caso aceito e seguido adiante começar o processo de arbitragem com a bandeira.
        /// </summary>
        PreArbitragem = 2,

        /// <summary>
        /// Fase em que a ELO faz a análise do pedido de arbitragem.
        /// </summary>
        Arbitragem = 3,

        /// <summary>
        /// Perdeu o processo de disputa.
        /// </summary>
        Perdida = 4,

        /// <summary>
        /// Desiste do chargeback.
        /// </summary>
        Desistencia = 5,

        /// <summary>
        /// Disputa aprovada
        /// </summary>
        Aprovada = 6,

        /// <summary>
        /// Estorno enviado.
        /// </summary>
        EstornoEnviado = 7
    }
}