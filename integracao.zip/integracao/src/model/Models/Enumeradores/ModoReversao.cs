﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Indica se a reversão é total ou parcial.
    /// </summary>
    public enum ModoReversao
    {
        /// <summary>
        /// Reversão total do valor.
        /// </summary>
        Total = 0,

        /// <summary>
        /// Reversão parcial do valor.
        /// </summary>
        Parcial = 1
    }
}
