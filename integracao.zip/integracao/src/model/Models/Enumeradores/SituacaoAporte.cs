namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Situação do aporte.
    /// </summary>
    public enum SituacaoAporte
    {
        /// <summary>
        /// Confirmado
        /// </summary>
        Confirmado = 0,

        /// <summary>
        /// Cancelado
        /// </summary>
        Cancelado = 1,

        /// <summary>
        /// Pendente
        /// </summary>
        Pendente = 2
    }
}