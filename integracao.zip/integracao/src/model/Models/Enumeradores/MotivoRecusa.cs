﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Motivos de recusa de uma transação, operação ou requisição.
    /// </summary>
    public enum MotivoRecusa
    {
        /// <summary>
        /// Desconhecido ou não informado.
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// O recurso associado está cancelado.
        /// </summary>
        Cancelado,

        /// <summary>
        /// O recurso associado está expirado.
        /// </summary>
        Expirado,

        /// <summary>
        /// A situação atual não permite que a requisição seja cumprida. Falha em alguma validação de negócio.
        /// </summary>
        NaoPermitido,

        /// <summary>
        /// O recurso associado está inativo.
        /// </summary>
        Inativo,

        /// <summary>
        /// O recurso associado está bloqueado.
        /// </summary>
        Bloqueado,

        /// <summary>
        /// A conta associada está fechada.
        /// </summary>
        ContaFechada,

        /// <summary>
        /// O recurso associado está em um estado inconsistente com relação aos dados informados.
        /// </summary>
        Inconsistencia
    }
}

