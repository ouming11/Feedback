﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de Transação iniciada pelo Estabelecimento(MIT).
    /// Os valores são usados para processar a primeira transação de
    /// pagamento e as subsequentes.
    /// </summary>
    public enum TipoTransacaoPagamento
    {
        /// <summary>
        /// Recorrente
        /// </summary>
        Recorrente = 0,

        /// <summary>
        /// Parcelamento
        /// </summary>
        Parcelamento = 1
    }
}

