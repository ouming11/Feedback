namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Aprovação Parcial.
    /// </summary>
    public enum AprovacaoParcial
    {
        /// <summary>
        /// Aprovação Parcial não suportado (este deve ser o valor enviado pelo Credenciador).
        /// </summary>
        NaoSuportada = 0,

        /// <summary>
        /// Suportada
        /// </summary>
        Suportada = 1,

        /// <summary>
        /// Apenas compras (saques são reprovados ou recusados)
        /// </summary>
        ApenasCompras = 2,

        /// <summary>
        /// Apenas saques (compras são reprovadas ou recusadas)
        /// </summary>
        ApenasSaque = 3
    }
}