using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de Pagamento.
    /// </summary>
    public enum TipoTransferencia
    {
        /// <summary>
        /// Conta para conta
        /// </summary>
        ContaParaConta = 0,

        /// <summary>
        /// Banco para Conta
        /// </summary>
        BancoParaConta = 1,

        /// <summary>
        /// Pessoa para Pessoa
        /// </summary>
        PessoaParaPessoa = 2,

        /// <summary>
        /// Cashback
        /// </summary>
        Cashback = 3
    }
}
