﻿using System;
namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de telefone.
    /// </summary>
    public enum TipoTelefone
    {
        /// <summary>
        /// Desconhecido, não informado ou outro tipo.
        /// </summary>
        Outro = 0,

        /// <summary>
        /// Telefone fixo.
        /// </summary>
        Fixo = 1,

        /// <summary>
        /// Telefone móvel.
        /// </summary>
        Movel = 2
    }
}

