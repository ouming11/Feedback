namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Define se a transação corresponde a um débito ou um crédito.
    /// </summary>
    public enum DebitoOuCredito
    {
        /// <summary>
        /// Débito.
        /// </summary>
        Debito = 0,

        /// <summary>
        /// Crédito.
        /// </summary>
        Credito = 1
    }
}