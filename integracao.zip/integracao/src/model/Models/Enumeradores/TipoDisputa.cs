namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de disputa.
    /// </summary>
    public enum TipoDisputa
    {
        /// <summary>
        /// Titular não reconhece a transação
        /// </summary>
        TitularNaoReconhece = 0,

        /// <summary>
        /// Valor incorreto
        /// </summary>
        ValorIncorreto = 1,

        /// <summary>
        /// Serviço não ofertado ou produto não entregue
        /// </summary>
        ServicoOuProduto = 2,

        /// <summary>
        /// Transação recorrente cancelada
        /// </summary>
        RecorrenciaCancelada = 3,

        /// <summary>
        /// Produto com defeito ou divergente da descrição
        /// </summary>
        DefeitoOuDivergencia = 4,

        /// <summary>
        /// Documento ilegível
        /// </summary>
        DocumentoIlegivel = 5,

        /// <summary>
        /// Não autorizado
        /// </summary>
        NaoAutorizado = 6,

        /// <summary>
        /// Cartão expirado
        /// </summary>
        CartaoExpirado = 7,

        /// <summary>
        /// Numero do cartão inexistente
        /// </summary>
        CartaoInexistente = 8,

        /// <summary>
        /// Fraude com cartão presente
        /// </summary>
        FraudeComPresencaCartao = 9,

        /// <summary>
        /// Fraude sem cartão presente
        /// </summary>
        FraudeSemPresencaCartao = 10,

        /// <summary>
        /// Múltiplas transações fraudulentas
        /// </summary>
        FraudesMultiplas = 11,

        /// <summary>
        /// Processamento duplicado
        /// </summary>
        ProcessamentoDuplicado = 12,

        /// <summary>
        /// Crédito não processado
        /// </summary>
        CreditoNaoProcessado = 13
    }
}
