namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de atendimento no Terminal.
    /// </summary>
    public enum TipoAtendimentoTerminal
    {
        /// <summary>
        /// Desconhecido
        /// </summary>
        Desconhecido = 0,

        /// <summary>
        /// Terminal com operador para atendimento.
        /// </summary>
        ComOperador = 1,

        /// <summary>
        /// Terminal autoatendimento, sem operador (ex: Vending Machines).
        /// </summary>
        AutoAtendimento = 2,

        /// <summary>
        /// Sem Terminal (ex: URA/Voz/e-Commerce).
        /// </summary>
        SemTerminal = 3,

        /// <summary>
        /// Dispositivo móvel (ex: smartphone).
        /// </summary>
        DispositivoMovel = 4
    }
}