﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Identifica qual é o tipo da conta
    /// </summary>
    public enum TipoConta
    {
        /// <summary>
        /// Não Aplicável
        /// </summary>
        NaoAplicavel = 0,

        /// <summary>
        /// Conta Poupança
        /// </summary>
        ContaPoupanca = 1,

        /// <summary>
        /// Conta Corrente
        /// </summary>
        ContaCorrente = 2,

        /// <summary>
        /// Conta Cartão
        /// </summary>
        ContaCartao = 3,

        /// <summary>
        /// Conta Investimento
        /// </summary>
        ContaInvestimento = 4
    }
}

