﻿namespace PrbCartao.Integracao.Models.Enumeradores
{
    /// <summary>
    /// Tipo de pagamento.
    /// Indica se um Pagamento Recorrente ou Prestação é um valor fixo ou
    /// variável.
    /// </summary>
    public enum TipoPagamento
    {
        /// <summary>
        /// Fixo
        /// </summary>
        Fixo = 0,

        /// <summary>
        /// Variável
        /// </summary>
        Variavel = 1
    }
}

