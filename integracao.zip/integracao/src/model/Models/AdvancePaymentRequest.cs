using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class AdvancePaymentRequest
    {
        /// <summary>
        /// Identificador único da transação cujas parcelas devem ser liquidadas antecipadamente.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// Número de parcelas que devem ser adiantadas
        /// </summary>
        [Required]
        public int InstallmentsToAdvance { get; set; }
    }
}
