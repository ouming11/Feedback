using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class InstallmentOptions
    {
        /// <summary>
        /// Gets or Sets _InstallmentOptions
        /// </summary>
        [Required]
        public List<InstallmentOption> _InstallmentOptions { get; set; }

        /// <summary>
        /// Gets or Sets OriginalAmount
        /// </summary>
        [Required]
        public DescritorValor OriginalAmount { get; set; }
    }
}

