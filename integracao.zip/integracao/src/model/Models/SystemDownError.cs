using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class SystemDownError
    {
        /// <summary>
        /// Gets or Sets Message
        /// </summary>
        [Required]
        public string Message { get; set; }

        /// <summary>
        /// Gets or Sets Code
        /// </summary>
        [Required]
        public int Code { get; set; }
    }
}
