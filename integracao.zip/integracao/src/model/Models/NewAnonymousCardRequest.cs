using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class NewAnonymousCardRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse identificador é ecoado na resposta. Nenhuma verificação dele é feita por parte da integracao, o emissor é livre para escolher o valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Identificador único para esse cartão no emissor.
        /// </summary>
        public string IssuerCardId { get; set; }

        /// <summary>
        /// Produto
        /// </summary>
        [Required]
        public Produto Produto { get; set; }

        /// <summary>
        /// Código numérico de até seis dígitos combinado entre emissor, integracao e gráfica, para determinar a arte do cartão.
        /// </summary>
        public decimal? DeliveryKitCode { get; set; }

        /// <summary>
        /// Campo livre que pode assumir o significado desejado pelo emissor, conforme combinação prévia com integracao e gráfica (exexmplo - código de barras, recebimento de lotes, etc.)
        /// </summary>
        public string ExtraData { get; set; }

        /// <summary>
        /// Flag indicando se o cartão deve ou não acatar transações feitas com o modo de entrada sem contato. Assumido como \&quot;true\&quot; se não enviado.
        /// </summary>
        public bool? AllowContactless { get; set; }

        /// <summary>
        /// Transportadora escolhida para entrega
        /// </summary>
        public string Transportadora { get; set; }

        /// <summary>
        /// Campo que contém o endereço de devolução do cartão em caso de insucesso na entrega.
        /// </summary>
        public string ReturnAddress { get; set; }

        /// <summary>
        /// Endereço para entrega do cartão.
        /// </summary>
        [Required]
        public AddressWithRecipient CardDeliveryAddress { get; set; }

        /// <summary>
        /// Nome do portador que deve ser gravado na personalização do cartão. Campo opcional.
        /// </summary>
        public string EmbossingName { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }

        /// <summary>
        /// Gráfica escolhida para emissão do Cartão
        /// </summary>
        public string Grafica { get; set; }
    }
}
