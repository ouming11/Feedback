using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DisputeDocument
    {
        /// <summary>
        /// Nome do documento auxiliar para a disputa.
        /// </summary>
        [Required]
        public string DocumentName { get; set; }

        /// <summary>
        /// Descrição do documento.
        /// </summary>
        public string DocumentDescription { get; set; }

        /// <summary>
        /// Documento codificado em base64.
        /// </summary>
        [Required]
        public string Document { get; set; }
    }
}
