using System.Runtime.Serialization;
using model.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class VirtualCardDescriptor
    {
        /// <summary>
        /// Identificador único do cartão virtual gerado pela integracao
        /// </summary>
        public string VCardId { get; set; }

        /// <summary>
        /// Número do Cartão Virtual - Primary Account Number (PAN)
        /// </summary>
        public string VPan { get; set; }

        /// <summary>
        /// Data de expiração do cartão virtual
        /// </summary>
        public DataExpiracaoCartao VDateExp { get; set; }

        /// <summary>
        /// CVV do cartão virtual
        /// </summary>
        public string VCvv { get; set; }

        /// <summary>
        /// Nome do portador do cartão, para ser informado nos portais de e-commerce
        /// </summary>
        public string VCardholder { get; set; }
    }
}
