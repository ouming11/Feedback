using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UpdateFunctionBlockingRequest
    {
        /// <summary>
        /// Todas as funcionalidade relacionadas ao emissor.
        /// </summary>
        [Required]
        public List<FunctionalitiesInformation> Functionalities { get; set; }
    }
}
