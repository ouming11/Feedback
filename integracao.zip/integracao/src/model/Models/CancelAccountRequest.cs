using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CancelAccountRequest
    {
        /// <summary>
        /// Código identificando o tipo de cancelamento.
        /// </summary>
        [Required]
        public int CancellationCode { get; set; }

        /// <summary>
        /// Motivo do cancelamento.
        /// </summary>
        public string Reason { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}

