using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models.Comandos
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CriarConta
    {
        /// <summary>
        /// Produto
        /// </summary>
        [Required]
        public Produto Produto { get; set; }

        /// <summary>
        /// Identificador externo.
        /// </summary>
        public string IdExterno { get; set; }

        /// <summary>
        /// Informações relacionadas ao titular da conta.
        /// </summary>
        [Required]
        public Titular Titular { get; set; }

        /// <summary>
        /// Gets or Sets CreditInfo
        /// </summary>
        public InformacoesCredito InformacoesCredito { get; set; }

        /// <summary>
        /// Endereço de cobrança da conta.
        /// </summary>
        [Required]
        public Endereco EnderecoCobranca { get; set; }

        /// <summary>
        /// Endereço para entrega do cartão.
        /// </summary>
        [Required]
        public Endereco EnderecoEntrega { get; set; }

        /// <summary>
        /// Informações da conta bancária associada a essa conta (opcional).
        /// </summary>
        public DadosBancarios BankAccount { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
