using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Comandos
{
    /// <summary>
    /// Cancelamento de Saque é uma transação iniciada via sistema.
    /// Ocorre quando uma das partes não conseguiu persistir corretamente a
    /// transação completa, como por exemplo, falha de sistema ou timeout.
    /// </summary>
    [DataContract]
    public sealed class CancelarSaque : ReversaoBase
    {
    }
}