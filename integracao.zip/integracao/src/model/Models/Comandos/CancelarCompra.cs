using System.ComponentModel.DataAnnotations;

namespace PrbCartao.Integracao.Comandos
{
    /// <summary>
    /// Cancelamento de Compra é uma transação iniciada via sistema.
    /// Ocorre quando uma das partes não conseguiu persistir corretamente a
    /// transação completa, como por exemplo, falha de sistema ou timeout.
    /// </summary>
    public sealed class CancelarCompra : ReversaoBase
    {
    }
}