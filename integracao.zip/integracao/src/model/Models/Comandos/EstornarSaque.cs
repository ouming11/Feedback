﻿using System;
namespace PrbCartao.Integracao.Comandos
{
    /// <summary>
    /// Estorno Saque é uma operação iniciada por uma pessoa.
    /// Pode ser o próprio cliente que solicitou ou, por exemplo, alguém da
    /// Contabilidade.
    /// </summary>
    public class EstornarSaque : ReversaoBase
    {
    }
}

