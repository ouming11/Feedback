﻿using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Comandos
{
    /// <summary>
    /// Dados base para transações de cancelmento ou estorno.
    /// </summary>
    public abstract class ReversaoBase
    {
        /// <summary>
        /// Identificador da transação original que deve ser desfeita.
        /// </summary>
        [Required]
        public Guid IdTransacaoOriginal { get; set; }

        /// <summary>
        /// Código de aceite retornado na transação original.
        /// </summary>
        [Required]
        public int TokenOriginal { get; set; }

        /// <summary>
        /// Valor Original da Transação
        /// </summary>
        [Required]
        public DescritorValor ValorOriginal { get; set; }

        /// <summary>
        /// Indica se a reversão é total ou parcial.
        /// </summary>
        public ModoReversao ModoReversao { get; set; }

        /// <summary>
        /// Motivo da reversão. Ex.: Solicitação pelo portador; Falha sistema.
        /// </summary>
        public string Motivo { get; set; }
    }
}