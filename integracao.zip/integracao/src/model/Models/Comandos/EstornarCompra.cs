﻿using System;
namespace PrbCartao.Integracao.Comandos
{
    /// <summary>
    /// Estorno Compra é uma tranação iniciada por uma pessoa.
    /// Pode ser o próprio cliente que solicitou ou, por exemplo, alguém da
    /// Contabilidade.
    /// </summary>
    public class EstornarCompra : ReversaoBase
    {
    }
}

