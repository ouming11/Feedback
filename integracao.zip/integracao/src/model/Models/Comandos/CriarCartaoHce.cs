using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models;

namespace PrbCartao.Integracao.Comandos
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CriarCartaoHce
    {
        /// <summary>
        /// Informações do produto.
        /// </summary>
        public ProdutoHce Produto { get; set; }

        /// <summary>
        /// Informações do produto criptografadas.
        /// </summary>
        public ProdutoHceCriptografado ProdutoCriptografado { get; set; }

        /// <summary>
        /// Identificador único do emissor da transação.
        /// </summary>
        public string IdEmissor { get; set; }
    }
}
