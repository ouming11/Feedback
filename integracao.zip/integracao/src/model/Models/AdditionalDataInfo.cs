using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class AdditionalDataInfo
    {
        /// <summary>
        /// ID da transação.
        /// </summary>
        [Required]
        public string ReferenceLabel { get; set; }

        /// <summary>
        /// Dados adicionais.
        /// </summary>
        public string PaymentSpecificTemplate { get; set; }
    }
}
