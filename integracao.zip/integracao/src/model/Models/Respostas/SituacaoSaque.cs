﻿using System;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Resposta para requisição de Situação do Saque.
    /// </summary>
    public sealed class SituacaoSaque
    {
        /// <summary>
        /// Situação do Saque.
        /// </summary>
        public SituacaoTransacao SituacaoTransacao { get; set; }
    }
}

