using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Saldo
    /// </summary>
    [DataContract]
    public class SaldoProvisionamento
    {
        /// <summary>
        /// Saldo
        /// </summary>
        public DescritorValor Saldo { get; set; }
    }
}
