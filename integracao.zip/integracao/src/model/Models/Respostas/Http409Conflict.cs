﻿using System;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Descreve o conflito que motivou a recusa da operação, transação ou
    /// requisição. Conflito significa que o estado atual não permite ou é
    /// incompatível com a operação requisitada. Normalmente por regra de
    /// negócio ou, ocasionalmente, por inconsitência de dados.
    /// O corpo da mensagem pode conter informações para que o cliente consiga
    /// resolver o cnflito antes de tentar novamente.
    /// </summary>
    public sealed class Http409Conflict : MensagemECodigo
    {
        /// <summary>
        /// Código do motivo da recusa.
        /// </summary>
        public MotivoRecusa? Motivo { get; set; }
    }
}
