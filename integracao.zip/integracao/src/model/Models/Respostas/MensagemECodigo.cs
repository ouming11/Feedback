﻿using System.ComponentModel.DataAnnotations;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Classe base com Mensagem e Código
    /// </summary>
    public abstract class MensagemECodigo
    {
        /// <summary>
        /// Mensagem explicativa.
        /// </summary>
        public string Mensagem { get; set; }

        /// <summary>
        /// Código referente à mensagem.
        /// </summary>
        public int Codigo { get; set; }
    }
}

