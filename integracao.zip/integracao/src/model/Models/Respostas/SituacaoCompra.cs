﻿using System;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Resposta para requisição de Situação da Compra
    /// </summary>
    public sealed class SituacaoCompra
    {
        /// <summary>
        /// Situação da Compra
        /// </summary>
        public SituacaoTransacao SituacaoTransacao { get; set; }
    }
}

