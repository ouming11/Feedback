﻿using System;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Indica que a requisição está incorreta e não pode ser aceita na forma
    /// atual. Ocorre normalmente por falha em validações de formatação,
    /// data/hora, casas decimais, tamanho máximos e mínimos, ausência de
    /// valores obrigatórios ou regra de negócio.
    /// O corpo da mensagem pode conter informações para que o cliente consiga
    /// corrigir o problema antes de tentar novamente.
    /// </summary>
    public sealed class Http400BadRequest : MensagemECodigo
    {
    }
}
