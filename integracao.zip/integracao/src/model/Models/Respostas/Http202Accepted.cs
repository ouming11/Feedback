using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Indica que a requisição foi recebida, mas o processamento ainda não
    /// completou. O resultado do processamento, que pode inclusive falhar,
    /// deve ser recuperado num segundo momento. Para localizar a situação final
    /// do processamento um Token é retornado, e opcionalmente uma previsão de
    /// horário para conclusão do processamento.
    /// </summary>
    [DataContract]
    public sealed class Http202Accepted
    {
        /// <summary>
        /// O Token é um código único que identifica uma transação/requisição
        /// que foi aceita para processamento assíncrono.
        /// </summary>
        [Required]
        public Guid Token { get; set; }

        /// <summary>
        /// Para operações assíncronas, este campo pode descrever o momento
        /// estimado em que a requisição terminará de ser processada.
        /// </summary>
        public DateTime? ETA { get; set; }
    }
}