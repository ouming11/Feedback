using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Respostas
{
    /// <summary>
    /// Status de sucesso.
    /// </summary>
    [DataContract]
    public sealed class Http200Ok : MensagemECodigo
    {
    }
}