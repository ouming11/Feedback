using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CardBlockInformation
    {
        /// <summary>
        /// Lista com os códigos de bloqueio que o código atual permite transitar.
        /// </summary>
        public List<string> BlockCodeTransitionsAsList { get; set; }

        /// <summary>
        /// Código identificando o tipo de bloqueio.
        /// </summary>
        [Required]
        public int BlockCode { get; set; }

        /// <summary>
        /// Indicação de onde (qual departamento ou papel) partiu o pedido de bloqueio.
        /// </summary>
        [Required]
        public string RequestedBy { get; set; }

        /// <summary>
        /// Descrição do motivo de bloqueio.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Data e hora do bloqueio no formato definido pela RFC 3339, seção 5.6.
        /// </summary>
        [Required]
        public DateTime BlockTime { get; set; }
    }
}
