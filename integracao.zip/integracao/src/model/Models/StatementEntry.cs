using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class StatementEntry
    {
        /// <summary>
        /// Identificador único da transação representada nesse lançamento.
        /// </summary>
        public string TransactionId { get; set; }

        /// <summary>
        /// Identificador único do cartão.
        /// </summary>
        public string CardId { get; set; }

        /// <summary>
        /// Últimos quatro dígitos do cartão.
        /// </summary>
        [Required]
        public string LastFourDigits { get; set; }

        /// <summary>
        /// Indica se a transação é internacional (True) ou não (False)
        /// </summary>
        [Required]
        public bool InternationalTransaction { get; set; }

        /// <summary>
        /// Data em que a transação ocorreu.
        /// </summary>
        [Required]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Descrição da transação, para ser mostrada na fatura.
        /// </summary>
        [Required]
        public string TransactionDescription { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// Gets or Sets AmountDollar
        /// </summary>
        public DescritorValor AmountDollar { get; set; }

        /// <summary>
        /// Define se a transação gerou um débito ou um crédito.
        /// </summary>
        public DebitoOuCredito? DebitOrCredit { get; set; }
    }
}
