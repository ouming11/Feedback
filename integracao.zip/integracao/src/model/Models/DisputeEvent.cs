using System;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DisputeEvent
    {
        /// <summary>
        /// Criador do evento.
        /// </summary>
        public Origem? Origem { get; set; }

        /// <summary>
        /// Data que o evento ocorreu.
        /// </summary>
        public DateTime DataCriacao { get; set; }

        /// <summary>
        /// Descrição do evento/resposta.
        /// </summary>
        public string Descricao { get; set; }
    }
}
