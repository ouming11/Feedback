using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CreateAccountVirtualCardRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse identificador é ecoado na resposta. Nenhuma verificação dele é feita por parte da integracao, o emissor é livre para escolher o valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Data de nascimento no formato dd/MM/yyyy
        /// </summary>
        [Required]
        public DateOnly Nascimento { get; set; }

        /// <summary>
        /// Restrições de operação do cartão virtual que está sendo criado
        /// </summary>
        public VirtualCardConstraints Constraints { get; set; }
    }
}
