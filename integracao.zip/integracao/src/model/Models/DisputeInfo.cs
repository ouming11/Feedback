using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DisputeInfo
    {
        /// <summary>
        /// Gets or Sets DisputeType
        /// </summary>
        [Required]
        public DisputeRequest DisputeType { get; set; }

        /// <summary>
        /// Gets or Sets DisputeReason
        /// </summary>
        [Required]
        public string DisputeReason { get; set; }

        /// <summary>
        /// Gets or Sets DisputeStatus
        /// </summary>
        [Required]
        public SituacaoDisputa DisputeStatus { get; set; }
    }
}

