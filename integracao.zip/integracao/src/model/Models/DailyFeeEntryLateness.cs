using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DailyFeeEntryLateness
    {
        /// <summary>
        /// Porcentagem de taxa de atraso
        /// </summary>
        public string LatenessFee { get; set; }

        /// <summary>
        /// Taxa de atraso cobrada
        /// </summary>
        public int? LatenessCharged { get; set; }
    }
}
