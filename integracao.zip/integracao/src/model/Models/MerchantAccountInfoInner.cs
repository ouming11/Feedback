using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class MerchantAccountInfoInner
    {
        /// <summary>
        /// Idenficador do arranjo.
        /// </summary>
        public string GlobalUniqueIdentifier { get; set; }

        /// <summary>
        /// Número do estabelecimento.
        /// </summary>
        public string MerchantAccountInformation { get; set; }

        /// <summary>
        /// Número lógico do terminal.
        /// </summary>
        public string LogicNumber { get; set; }

        /// <summary>
        /// Identificação do credenciador.
        /// </summary>
        public string AcquirerId { get; set; }

        /// <summary>
        /// Identificação do terminal do estabelecimento.
        /// </summary>
        public string TerminalId { get; set; }

        /// <summary>
        /// Tipo do device/ambinete exibindo o QR Code.
        /// </summary>
        public string TerminalDeviceType { get; set; }

        /// <summary>
        /// Número de identificação do Marketplace ou subcredenciador atribuído pela Elo.
        /// </summary>
        public string SubAcquirerId { get; set; }

        /// <summary>
        /// Número atribuído pelo Subcredenciador ou Marketplace ao seu respectivo Estabelecimento Comercial.
        /// </summary>
        public string SubAcquirerMerchantAccountInformation { get; set; }

        /// <summary>
        /// Dados adicionais.
        /// </summary>
        public string AdditionalInformation { get; set; }
    }
}
