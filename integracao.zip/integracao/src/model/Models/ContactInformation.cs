using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class ContactInformation
    {
        /// <summary>
        /// Telefone celular pessoal no formato +DDI DDD NNNNNNNNN
        /// </summary>
        [Required]
        public string PersonalPhoneNumber1 { get; set; }

        /// <summary>
        /// Telefone residencial (fixo) no formato +DDI DDD NNNNNNNNN
        /// </summary>
        public string PersonalPhoneNumber2 { get; set; }

        /// <summary>
        /// Telefone comercial no formato +DDI DDD NNNNNNNNN
        /// </summary>
        public string ComercialPhoneNumber1 { get; set; }

        /// <summary>
        /// Endereço de e-mail de contato.
        /// </summary>
        public string Email { get; set; }
    }
}
