using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CardStatus
    {
        /// <summary>
        /// Situação do cartão
        /// </summary>
        public SituacaoCartao? Status { get; set; }

        /// <summary>
        /// Descrição de detalhes da situação.
        /// </summary>
        public string StatusDetails { get; set; }
    }
}
