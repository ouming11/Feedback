using System;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DailyFeeEntry
    {
        /// <summary>
        /// Data referente aos dados desse processamento
        /// </summary>
        public DateTime? Data { get; set; }

        /// <summary>
        /// Saldo financiado utilizado para previsão de encargos
        /// </summary>
        public int? Financed { get; set; }

        /// <summary>
        /// Gets or Sets DailyIof
        /// </summary>
        public DailyFeeEntryDailyIof DailyIof { get; set; }

        /// <summary>
        /// Gets or Sets DailyInterest
        /// </summary>
        public DailyFeeEntryDailyInterest DailyInterest { get; set; }

        /// <summary>
        /// Gets or Sets ExpectedFees
        /// </summary>
        public DailyFeeEntryExpectedFees ExpectedFees { get; set; }

        /// <summary>
        /// Gets or Sets Lateness
        /// </summary>
        public DailyFeeEntryLateness Lateness { get; set; }

        /// <summary>
        /// Gets or Sets RefundFees
        /// </summary>
        public DailyFeeEntryRefundFees RefundFees { get; set; }
    }
}
