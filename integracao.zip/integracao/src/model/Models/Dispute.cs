using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Dispute
    {
        /// <summary>
        /// Identificador único da disputa na integracao.
        /// </summary>
        public string DisputeId { get; set; }

        /// <summary>
        /// Gets or Sets DisputeRequest
        /// </summary>
        [Required]
        public DisputeRequest DisputeRequest { get; set; }

        /// <summary>
        /// Data e hora da criação da disputa
        /// </summary>
        [Required]
        public DateTime DisputeDate { get; set; }

        /// <summary>
        /// Data máxima para uma resposta.
        /// </summary>
        public DateOnly DisputeMaxDateResponse { get; set; }

        /// <summary>
        /// Gets or Sets DisputeType
        /// </summary>
        [Required]
        public TipoDisputa DisputeType { get; set; }

        /// <summary>
        /// Gets or Sets DisputeStatus
        /// </summary>
        [Required]
        public SituacaoDisputa DisputeStatus { get; set; }

        /// <summary>
        /// Estágio atual do processo de disputa: &lt;/br&gt; &lt;ul&gt;&lt;li&gt;chargeback: estado inicial&lt;/li&gt; &lt;li&gt;restatement: devolutiva negativa do credenciador, o emissor deve escolher se quer continuar com a disputa ou não.&lt;/li&gt; &lt;li&gt;pre-arbitration: o processo que é feito entre emissor e credenciador, para assim caso aceito e seguido adiante começar o processo de arbitragem com a bandeira.&lt;/li&gt; &lt;li&gt;arbitration: fase em que a ELO faz a análise do pedido de arbitragem.&lt;/li&gt; &lt;li&gt;lost: perdeu o processo de disputa.&lt;/li&gt; &lt;li&gt;undone: desiste do chargeback.&lt;/li&gt; &lt;li&gt;successful: disputa aprovada e estorno enviado.&lt;/li&gt; &lt;li&gt;withdrawal:  quando desiste depois de ter recebido um restatement.&lt;/li&gt; &lt;/ul&gt;
        /// </summary>
        [Required]
        public EstagioDaDisputa CurrentStage { get; set; }

        /// <summary>
        /// Tipo da fraude. Presente quando o motivo de disputa for algum tipo de fraude.
        /// </summary>
        public string FraudType { get; set; }

        /// <summary>
        /// Histórico de eventos nessa disputa.
        /// </summary>
        public List<DisputeEvent> DisputeHistory { get; set; }

        /// <summary>
        /// Gets or Sets Transaction
        /// </summary>
        public Transaction Transaction { get; set; }
    }
}
