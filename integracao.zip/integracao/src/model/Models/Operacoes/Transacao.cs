﻿using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Operacoes
{
    /// <summary>
    /// Dados básicos da transação
    /// </summary>
    public abstract class Transacao
    {
        /// <summary>
        /// Identificador único da transação.
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Origem da transação.
        /// </summary>
        [Required]
        public Origem Origem { get; set; }

        /// <summary>
        /// Indica o status atual da transação.
        /// </summary>
        [Required]
        public SituacaoTransacao SituacaoTransacao { get; set; }

        /// <summary>
        /// Gets or Sets TransactionType
        /// </summary>
        [Required]
        public TipoTransacao TipoTransacao { get; set; }

        /// <summary>
        /// Data e hora em que a transação foi criada.
        /// </summary>
        public DateTime Criacao { get; set; }
    }
}

