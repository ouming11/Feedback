using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Operacoes
{
    /// <summary>
    /// Saque
    /// </summary>
    [DataContract]
    public sealed class Saque : TransacaoCartao
    {
    }
}