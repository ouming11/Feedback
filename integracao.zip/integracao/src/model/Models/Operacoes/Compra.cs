using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Operacoes
{
    /// <summary>
    /// Dados de Compra
    /// </summary>
    [DataContract]
    public sealed class Compra : TransacaoCartao
    {
        /// <summary>
        /// Indica se é uma pré-autorização (true) ou autorização normal (false)
        /// </summary>
        [Required]
        public bool PreAutorizacao { get; set; }

        /// <summary>
        /// Indica se é uma autorização incremental (true) ou não (false)
        /// </summary>
        [Required]
        public bool AutorizacaoIncremental { get; set; }

        /// <summary>
        /// Indica se esta compra é um aviso de autorização de compra (true) ou
        /// é uma requisição de compra que deve ser validada pelo emissor
        /// (false ou não informado). Avisos de autorização devem ser aceitos
        /// pelo emissor, pois já foram aprovados pelo sistema de Stand-In da
        /// bandeira ou processadora mediante parâmetros informados pelo
        /// emissor no sistema de Stand-In.
        /// </summary>
        public bool? AvisoAutorizacao { get; set; }

        /// <summary>
        /// Dados de parcelamento
        /// </summary>
        public Parcelamento Parcelamento { get; set; }
    }
}