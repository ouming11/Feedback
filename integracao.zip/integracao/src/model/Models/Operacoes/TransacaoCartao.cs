﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Operacoes
{
    /// <summary>
    /// Classe base para Transação de Cartão.
    /// </summary>
    public abstract class TransacaoCartao : Transacao
    {
        /// <summary>
        /// Identificador de aceite da transação informado pela processadora.
        /// </summary>
        public Guid Token { get; set; }

        /// <summary>
        /// Identificador interno da conta, no emissor.
        /// </summary>
        [Required]
        public Guid IdConta { get; set; }

        /// <summary>
        /// Código de Processamento
        /// </summary>
        [Required]
        public CodigoProcessamento CodigoProcessamento { get; set; }

        /// <summary>
        /// IDentificacao do Produto associado a transação
        /// </summary>
        public Produto Produto { get; set; }

        /// <summary>
        /// Dados do Estabelecimento.
        /// </summary>
        [Required]
        public Estabelecimento Estabelecimento { get; set; }

        /// <summary>
        /// Código do país (alfa-3) conforme ISO 3166-1.
        /// </summary>
        [Required]
        public string CodigoPais { get; set; }

        /// <summary>
        /// Cartão utilizado na transação.
        /// </summary>
        [Required]
        public Cartao Cartao { get; set; }

        /// <summary>
        /// Valor da Transação.
        /// </summary>
        [Required]
        public DescritorValor Valor { get; set; }

        /// <summary>
        /// Valor em Dolar
        /// </summary>
        public DescritorValor ValorEmDolar { get; set; }

        /// <summary>
        /// Cotação para conversão de câmbio Dólar / Real.
        /// </summary>
        public decimal? CotacaoDolar { get; set; }

        /// <summary>
        /// Spread (ou markup) aplicado em transações internacionais.
        /// </summary>
        public decimal? Spread { get; set; }

        /// <summary>
        /// Tarifas
        /// </summary>
        [Required]
        public List<Tarifa> Tarifas { get; set; }

        /// <summary>
        /// Detalhes de Financiamento
        /// </summary>
        public DetalhesFinanciamento DetalhesFinanciamento { get; set; }

        /// <summary>
        /// Modo de entrada do Número do Cartão - Primary Account Number (PAN).
        /// </summary>
        public ModoEntradaPan ModoEntradaPan { get; set; }

        /// <summary>
        /// Modo de Validação Do Portador
        /// </summary>
        public ModoValidacaoDoPortador ModoValidacaoDoPortador { get; set; }

        /// <summary>
        /// Dados adicionais do terminal
        /// </summary>
        public DadosAdicionaisTerminal DadosAdicionaisTerminal { get; set; }

        /// <summary>
        /// Indica se a transação é internacional (true) ou nacional (false)
        /// </summary>
        public bool Internacional { get; set; }

        /// <summary>
        /// Dados de Fraude, preenchido apenas quando há suspeita de fraude.
        /// </summary>
        public DadosFraude DadosFraude { get; set; }

        /// <summary>
        /// Nome/identificador do serviço que fez essa chamada.
        /// </summary>
        [Required]
        public string IdServicoChamador { get; set; }
    }
}

