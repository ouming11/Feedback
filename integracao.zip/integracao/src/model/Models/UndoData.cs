using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Dados sobre o estorno.
    /// </summary>
    [DataContract]
    public class UndoData
    {
        /// <summary>
        /// Usado somente no caso de estorno. Indica que o estorno é parcial.
        /// </summary>
        public bool? PartialUndo { get; set; }

        /// <summary>
        /// Uma descrição opcional de por que o estorno foi feito.
        /// </summary>
        public string UndoDescription { get; set; }
    }
}
