using System;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class QrCodeTransactionInfoInner
    {
        /// <summary>
        /// Identificador global
        /// </summary>
        public string GlobalUniqueIdentifier { get; set; }

        /// <summary>
        /// Código único da transação.
        /// </summary>
        public string TransactionId { get; set; }

        /// <summary>
        /// Data e hora da transação.
        /// </summary>
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Código do produto matriz.
        /// </summary>
        public string MainProduct { get; set; }

        /// <summary>
        /// Código do sub produto.
        /// </summary>
        public string SubProduct { get; set; }

        /// <summary>
        /// Número de parcelas.
        /// </summary>
        public string PaymentInstallments { get; set; }

        /// <summary>
        /// Tipo da transação.
        /// </summary>
        public string TransactionType { get; set; }

        /// <summary>
        /// Fonte de dados do pagamento.
        /// </summary>
        public string PaymentSource { get; set; }

        /// <summary>
        /// Identificador único da transação original que será cancelada.
        /// </summary>
        public string OriginalTransactionId { get; set; }

        /// <summary>
        /// Data da transação original quer será cancelada.
        /// </summary>
        public DateTime OriginalTransactionDate { get; set; }

        /// <summary>
        /// Identificação do terminal do estabelecimento utilizado na transação original.
        /// </summary>
        public string OriginalTransactionTerminalId { get; set; }
    }
}
