using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CreditListResult
    {
        /// <summary>
        /// Indica que atingiu o limite de retorno e existem mais elementos a serem retornados.
        /// </summary>
        public bool? HasMore { get; set; }

        /// <summary>
        /// Lista de créditos futuros.
        /// </summary>
        public List<Credit> Credits { get; set; }
    }
}

