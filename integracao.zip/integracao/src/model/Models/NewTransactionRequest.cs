using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class NewTransactionRequest
    {
        /// <summary>
        /// Identificador único do transação. Gerado pelo emissor.
        /// </summary>
        public string IssuerTransactionId { get; set; }

        /// <summary>
        /// Gets or Sets TransactionType
        /// </summary>
        [Required]
        public TipoTransacao TransactionType { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }

        /// <summary>
        /// Valor do crédito ou débito a ser adicionado na conta.
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// Descrição do motivo ou da situação da transação.
        /// </summary>
        [Required]
        public string Reason { get; set; }
    }
}
