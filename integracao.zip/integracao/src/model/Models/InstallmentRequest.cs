using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class InstallmentRequest
    {
        /// <summary>
        /// Número de parcelas em que o pagamento deve ser quebrado.
        /// </summary>
        [Required]
        public int NumberOfInstallments { get; set; }

        /// <summary>
        /// Gets or Sets InstallmentAmount
        /// </summary>
        public DescritorValor InstallmentAmount { get; set; }
    }
}
