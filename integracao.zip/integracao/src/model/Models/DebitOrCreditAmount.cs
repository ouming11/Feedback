using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class DebitOrCreditAmount
    {
        /// <summary>
        /// Valor
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// Define se a transação deve gerar um débito ou um crédito.
        /// </summary>
        [Required]
        public DebitoOuCredito DebitOrCredit { get; set; }
    }
}
