using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CancelVirtualCardRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse identificador é ecoado na resposta. Nenhuma verificação dele é feita por parte da integracao, o emissor é livre para escolher o valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Código identificando o tipo de cancelamento.
        /// </summary>
        [Required]
        public int CancellationCode { get; set; }

        /// <summary>
        /// Motivo do cancelamento.
        /// </summary>
        public string Reason { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
