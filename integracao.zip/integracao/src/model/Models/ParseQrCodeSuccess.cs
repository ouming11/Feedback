using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class ParseQrCodeSuccess
    {
        /// <summary>
        /// Identifica a versão do template QR Code
        /// </summary>
        public string PayloadFormatIndicator { get; set; }

        /// <summary>
        /// Identifica a tecnologia de comunicação e se o QR Code é dinâmico ou estático.
        /// </summary>
        public string PointOfInitiationMethod { get; set; }

        /// <summary>
        /// Gets or Sets MerchantAccountInformation
        /// </summary>
        public List<MerchantAccountInfoInner> MerchantAccountInformation { get; set; }

        /// <summary>
        /// Código da categoria do estabelecimento de acordo com a ISO18245.
        /// </summary>
        public string MerchantCategoryCode { get; set; }

        /// <summary>
        /// Código da moeda de acordo com a ISO4217.
        /// </summary>
        public string TransactionCurrency { get; set; }

        /// <summary>
        /// Valor da transação.
        /// </summary>
        public string TransactionAmount { get; set; }

        /// <summary>
        /// Código do país de acordo com a ISO3166-1 alpha 2.
        /// </summary>
        public string CountryCode { get; set; }

        /// <summary>
        /// Nome do recebedor.
        /// </summary>
        public string MerchantName { get; set; }

        /// <summary>
        /// Nome da cidade onde é efetuada a transação.
        /// </summary>
        public string MerchantCity { get; set; }

        /// <summary>
        /// CEP da localidade onde é efetuada a transação.
        /// </summary>
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or Sets AdditionalDataInformation
        /// </summary>
        public AdditionalDataInfo AdditionalDataInformation { get; set; }

        /// <summary>
        /// Dados adicionais do template.
        /// </summary>
        public string UnreservedTemplates { get; set; }

        /// <summary>
        /// Gets or Sets TransactionInformation
        /// </summary>
        public List<QrCodeTransactionInfoInner> TransactionInformation { get; set; }

        /// <summary>
        /// Checksum calculado a partir de todos os dados do QR Code.
        /// </summary>
        public string Crc { get; set; }
    }
}
