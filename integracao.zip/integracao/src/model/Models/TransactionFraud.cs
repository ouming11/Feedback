using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class TransactionFraud
    {
        /// <summary>
        /// Identificador da transação na rede de captura.
        /// </summary>
        public string AcquirerTransactionId { get; set; }

        /// <summary>
        /// Gets or Sets TransactionAuthorizationResponse
        /// </summary>
        public TransactionAuthorizationResponse TransactionAuthorizationResponse { get; set; }

        /// <summary>
        /// Produto
        /// </summary>
        public Produto Produto { get; set; }

        /// <summary>
        /// Nome do estabelecimento.
        /// </summary>
        public string MerchantName { get; set; }

        /// <summary>
        /// Identificador único da disputa na integracao.
        /// </summary>
        public string DisputeId { get; set; }

        /// <summary>
        /// Gets or Sets TransactionType
        /// </summary>
        [Required]
        public TipoTransacao TransactionType { get; set; }

        /// <summary>
        /// Origem da transação
        /// </summary>
        public string TransactionSource { get; set; }

        /// <summary>
        /// Gets or Sets Fees
        /// </summary>
        public List<Tarifa> Tarifas { get; set; }

        /// <summary>
        /// Identificação do terminal informada na autorização.
        /// </summary>
        public string TerminalId { get; set; }

        /// <summary>
        /// Data da transação.
        /// </summary>
        public DateTime? TransactionDate { get; set; }

        /// <summary>
        /// Incremento de pré-autorização
        /// </summary>
        public bool? Incremental { get; set; }

        /// <summary>
        /// Indica se a transação for uma transação internacional. Falso se for uma transação doméstica.
        /// </summary>
        public bool? International { get; set; }

        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        [Required]

        public string AccountId { get; set; }

        /// <summary>
        /// Código do país conforme ISO 3166-1.
        /// </summary>
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or Sets EntryMode
        /// </summary>
        public ModoEntradaPan EntryMode { get; set; }

        /// <summary>
        /// Código de identificação da rede de captura da transação.
        /// </summary>
        public string AcquirerId { get; set; }

        /// <summary>
        /// Código postal do vendedor
        /// </summary>
        public string MerchantZipcode { get; set; }

        /// <summary>
        /// Situacao da Transacao
        /// </summary>
        [Required]
        public SituacaoTransacao SituacaoTransacao { get; set; }

        /// <summary>
        /// Endereço do estabelecimento.
        /// </summary>
        public string MerchantAddress { get; set; }

        /// <summary>
        /// Se transação foi realizada por meio de um cartão, os dados do cartão são representados por este campo.
        /// </summary>
        public Card Card { get; set; }

        /// <summary>
        /// Identificador da transação atribuído pela integracao.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// MCC da transação
        /// </summary>
        public string Mcc { get; set; }

        /// <summary>
        /// Cidade do estabelecimento.
        /// </summary>
        public string MerchantCity { get; set; }

        /// <summary>
        /// Gets or Sets FraudNotificationStatus
        /// </summary>
        public SituacaoFraude FraudNotificationStatus { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [Required]
        public AmountFraud Amount { get; set; }

        /// <summary>
        /// Gets or Sets RemainingAmount
        /// </summary>
        public DescritorValor RemainingAmount { get; set; }

        /// <summary>
        /// Gets or Sets RefundedAmount
        /// </summary>
        public DescritorValor RefundedAmount { get; set; }

        /// <summary>
        /// Identificação do estabelecimento informada na autorização.
        /// </summary>
        public string MerchantId { get; set; }

        /// <summary>
        /// Data e hora do recebimento na liquidação no formato definido pela RFC 3339, seção 5.6.
        /// </summary>
        public DateTime? SettlementDateTime { get; set; }

        /// <summary>
        /// CNPJ do estabelecimento.
        /// </summary>
        public string MerchantDocumentId { get; set; }

        /// <summary>
        /// Uf do estabelecimento
        /// </summary>
        public string MerchantUf { get; set; }

        /// <summary>
        /// Identificador da transação que realizou o estorno dessa transação. Deprecado. Será substituído progressivamente pelo cancellingTransactionIds (lista de IDs de transações de cancelamento/estornos).
        /// </summary>
        public string CancellingTransactionId { get; set; }

        /// <summary>
        /// Lista contendo um ou mais identificadores de transações de estorno.
        /// </summary>
        public List<string> CancellingTransactionIds { get; set; }

        /// <summary>
        /// Se transação for internacional, contêm dados referentes a esse tipo de transação.
        /// </summary>
        public InternationalData InternationalTransactionData { get; set; }

        /// <summary>
        /// Indica se esta transação é um aviso de autorização (true) ou é uma requisição que foi validada pelo emissor (false ou não informado).
        /// </summary>
        public bool? AuthorizationAdvice { get; set; }

        /// <summary>
        /// Gets or Sets MitAdditionalData
        /// </summary>
        public MitAdditionalData MitAdditionalData { get; set; }

        /// <summary>
        /// Gets or Sets AdditionalTerminalData
        /// </summary>
        public DadosAdicionaisTerminal AdditionalTerminalData { get; set; }
    }
}
