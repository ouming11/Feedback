using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using model.Models.Entidades;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Card
    {
        /// <summary>
        /// Identificador único do cartão.
        /// </summary>
        [Required]
        public string CardId { get; set; }

        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Identificador único para esse cartão no emissor.
        /// </summary>
        public string IssuerCardId { get; set; }

        /// <summary>
        /// Identificador único para esse cartão no emissor.
        /// </summary>
        public string IssuerCardHolderId { get; set; }

        /// <summary>
        /// BIN do cartão (6 a 8 dígitos).
        /// </summary>
        [Required]
        public string Bin { get; set; }

        /// <summary>
        /// Últimos 4 dígitos do cartão.
        /// </summary>
        [Required]
        public string Last4Digits { get; set; }

        /// <summary>
        /// Data de expiração
        /// </summary>
        [Required]
        public DataExpiracaoCartao DataExpiracaoCartao { get; set; }

        /// <summary>
        /// Gets or Sets CardholderData
        /// </summary>
        [Required]
        public Portador CardholderData { get; set; }

        /// <summary>
        /// Perfil do cartão EMV de pagamento.
        /// </summary>
        [Required]
        public TipoCartao? Profile { get; set; }

        /// <summary>
        /// Identifica o tipo de produto do emissor representado pelo cartão.
        /// </summary>
        [Required]
        public string Product { get; set; }

        /// <summary>
        /// Gets or Sets Status
        /// </summary>
        [Required]
        public CardStatus Status { get; set; }

        /// <summary>
        /// Informações sobre o bloqueio do cartão. Só presente no caso de cartões bloqueados.
        /// </summary>
        public CardBlockInformation BlockInformation { get; set; }

        /// <summary>
        /// Data de emisão.
        /// </summary>
        [Required]
        public DateOnly DataEmissão { get; set; }

        /// <summary>
        /// Identificador de rastreamento do cartão enviado pela integracao para a gráfica
        /// </summary>
        public string TrackingId { get; set; }
    }
}
