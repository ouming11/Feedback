using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class InstallmentPurchase
    {
        /// <summary>
        /// Identificador único da transação representada nessa parcela.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// Identificador único do cartão.
        /// </summary>
        public string CardId { get; set; }

        /// <summary>
        /// Últimos quatro dígitos do cartão.
        /// </summary>
        [Required]
        public string LastFourDigits { get; set; }

        /// <summary>
        /// Descrição da transação.
        /// </summary>
        [Required]
        public string TransactionDescription { get; set; }

        /// <summary>
        /// Data em que a transação ocorreu.
        /// </summary>
        [Required]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or Sets Installments
        /// </summary>
        [Required]
        public List<Installment> Installments { get; set; }
    }
}
