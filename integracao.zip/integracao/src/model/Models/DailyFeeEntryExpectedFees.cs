using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Encargos previsto até o vencimento
    /// </summary>
    [DataContract]
    public class DailyFeeEntryExpectedFees
    {
        /// <summary>
        /// Saldo financiado utilizado para previsão de encargos
        /// </summary>
        public int? Financed { get; set; }

        /// <summary>
        /// Porcentagem de Juros rotativo diário
        /// </summary>
        public string InterestDay { get; set; }

        /// <summary>
        /// Porcentagem de IOF diário
        /// </summary>
        public string IOFDay { get; set; }

        /// <summary>
        /// Rotativo diário esperado
        /// </summary>
        public int? InterestCharged { get; set; }

        /// <summary>
        /// IOF diário esperado
        /// </summary>
        public int? IOFCharged { get; set; }

        /// <summary>
        /// Dias entre o fechamento e vencimento real da fatura
        /// </summary>
        public int? DaysInAdvance { get; set; }

        /// <summary>
        /// Valor previsto a ser cobrado em adiantamento
        /// </summary>
        public int? ExpectedCharged { get; set; }
    }
}
