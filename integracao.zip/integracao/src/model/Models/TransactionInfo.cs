using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class TransactionInfo
    {
        /// <summary>
        /// Gets or Sets Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or Sets ReferenceLabel
        /// </summary>
        public string ReferenceLabel { get; set; }

        /// <summary>
        /// Gets or Sets ApprovalTimestamp
        /// </summary>
        public string ApprovalTimestamp { get; set; }

        /// <summary>
        /// Gets or Sets AuthorizationCode
        /// </summary>
        public string AuthorizationCode { get; set; }

        /// <summary>
        /// Gets or Sets AuthenticationCode
        /// </summary>
        public string AuthenticationCode { get; set; }

        /// <summary>
        /// Gets or Sets HostNsu
        /// </summary>
        public string HostNsu { get; set; }

        /// <summary>
        /// Gets or Sets TerminalNsu
        /// </summary>
        public string TerminalNsu { get; set; }

        /// <summary>
        /// Gets or Sets MerchantId
        /// </summary>
        public string MerchantId { get; set; }

        /// <summary>
        /// Gets or Sets TerminalId
        /// </summary>
        public string TerminalId { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// Gets or Sets Status
        /// </summary>
        public string Status { get; set; }
    }
}
