using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class InstallmentOption
    {
        /// <summary>
        /// Número de parcelas.
        /// </summary>
        [Required]
        public int NumInstallments { get; set; }

        /// <summary>
        /// Gets or Sets InstallmentAmount
        /// </summary>
        [Required]
        public DescritorValor InstallmentAmount { get; set; }

        /// <summary>
        /// Gets or Sets TotalAmount
        /// </summary>
        [Required]
        public DescritorValor TotalAmount { get; set; }

        /// <summary>
        /// Gets or Sets CET
        /// </summary>
        [Required]
        public CustoEfetivoTotal CET { get; set; }
    }
}
