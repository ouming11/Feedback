﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Produto
    /// </summary>
    public sealed class Produto
    {
        /// <summary>
        /// Código do produto. Ex.: 233101
        /// </summary>
        [Required]
        public string CodigoProduto { get; set; }

        /// <summary>
        /// Tipo do produto. 
        /// </summary>
        public string TipoProduto { get; set; }

        /// <summary>
        /// Nome do produto. Ex.: Saque Consignado.
        /// </summary>
        public string NomeProduto { get; set; }
    }
}

