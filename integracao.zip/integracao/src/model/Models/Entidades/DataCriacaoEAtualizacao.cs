﻿using System;
namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Data de criação e data de atualização.
    /// </summary>
    public abstract class DataCriacaoEAtualizacao
    {
        /// <summary>
        /// Data e hora da última atualização. Formato UTC, conforme
        /// especificação RFC-3339.
        /// </summary>
        public DateTime? DataAtualizacao { get; set; }

        /// <summary>
        /// Data e hora da criação. Formato UTC, conforme especificação
        /// RFC-3339.
        /// </summary>
        public DateTime? DataCriacao { get; set; }
    }
}
