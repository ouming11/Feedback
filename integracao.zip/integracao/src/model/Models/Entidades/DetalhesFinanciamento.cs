using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Detalhes do financiamento.
    /// </summary>
    [DataContract]
    public sealed class DetalhesFinanciamento
    {
        /// <summary>
        /// Identifica o tipo do financiamento.
        /// </summary>
        [Required]
        public TipoFinanciamento TipoFinanciamento { get; set; }

        /// <summary>
        /// Valor da Tarifa.
        /// </summary>
        public DescritorValor Tarifa { get; set; }

        /// <summary>
        /// Valor do Seguro.
        /// </summary>
        public DescritorValor Seguro { get; set; }

        /// <summary>
        /// Valor pagamento a terceiros.
        /// </summary>
        public DescritorValor ValorPagamentoTerceiros { get; set; }

        /// <summary>
        /// Valor de registros de pagamento.
        /// </summary>
        public DescritorValor RegistrosDePagamento { get; set; }

        /// <summary>
        /// Valor total calculado pelo emissor.
        /// </summary>
        public DescritorValor ValorTotalCalculadoEmissor { get; set; }

        /// <summary>
        /// Identifica a data de pagamento da primeira parcela. Formato - AAMMDD.
        /// </summary>
        public DateOnly DataPrimeiroPagamento { get; set; }

        /// <summary>
        /// Quantidade de parcelas (2 inteiros)
        /// </summary>
        [Required]
        public int QuantidadeParcelas { get; set; }

        /// <summary>
        /// Identifica a taxa de juros mensal.
        /// </summary>
        public decimal? TaxaJurosMensal { get; set; }

        /// <summary>
        /// Identifica o custo efetivo total (CET).
        /// </summary>
        public decimal? TaxaCet { get; set; }

        /// <summary>
        /// Valor da Parcela
        /// </summary>
        [Required]
        public DescritorValor ValorParcela { get; set; }

        /// <summary>
        /// Identifica Taxa Anual de Juros.
        /// </summary>
        public decimal? TaxaAnualJuros { get; set; }

        /// <summary>
        /// Valor do Principal
        /// </summary>
        public DescritorValor Principal { get; set; }
    }
}