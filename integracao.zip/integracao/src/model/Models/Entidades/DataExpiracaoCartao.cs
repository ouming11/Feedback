﻿using System;
using System.ComponentModel.DataAnnotations;

namespace model.Models.Entidades
{
    /// <summary>
    /// Data de expiração do cartão.
    /// </summary>
    public sealed class DataExpiracaoCartao
    {
        /// <summary>
        /// Mês.
        /// </summary>
        [Required]
        [Range(1, 12)]
        public string Mes { get; set; }

        /// <summary>
        /// Ano, 2 dígitos.
        /// </summary>
        [Required]
        [Range(1, 99)]
        public int Ano { get; set; }
    }
}

