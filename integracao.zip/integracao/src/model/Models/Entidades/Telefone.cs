﻿using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Telefone.
    /// </summary>
    public class Telefone : DataCriacaoEAtualizacao
    {
        /// <summary>
        /// Identifica se o telefone é o que tem maior chance de obter contato.
        /// </summary>
        public bool MaiorChanceContato { get; set; }

        /// <summary>
        /// Indica se o telefone foi verificado.
        /// </summary>
        public bool Verificado { get; set; }

        /// <summary>
        /// Identificação do tipo do telefone.
        /// </summary>
        public TipoTelefone Tipo { get; set; }

        /// <summary>
        /// Informação complementar relativa ao telefone.
        /// Preenchimento obrigatório quando selecionado o tipo 'OUTRO'.
        /// </summary>
        [MaxLength(70)]
        public string InformacoesAdicionais { get; set; }

        /// <summary>
        /// Número de DDI (Discagem Direta Internacional), se houver.
        /// Preenchimento é obrigatório quando for diferente de 55.
        /// Somente dígitos.
        /// </summary>
        [MaxLength(4)]
        [RegularExpression("^[0-1]{1,4}$")]
        public string CodigoPais { get; set; }

        /// <summary>
        /// Número de DDD (Discagem Direta à Distância), se houver.
        /// Somente dígitos.
        /// </summary>
        [MaxLength(2)]
        [RegularExpression("^[0-1]{2}$")]
        public string CodigoArea { get; set; }

        /// <summary>
        /// Número de telefone do cliente, somente dígitos.
        /// </summary>
        [MaxLength(11)]
        [RegularExpression("^[0-1]{8,11}$")]
        public string Numero { get; set; }
    }
}

