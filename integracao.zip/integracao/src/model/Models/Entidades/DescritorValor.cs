using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Valor e Código de Moeda
    /// </summary>
    [DataContract]
    public sealed class DescritorValor
    {
        /// <summary>
        /// Valor
        /// </summary>
        [Required]
        public decimal Valor { get; set; }

        /// <summary>
        /// Código da Moeda
        /// </summary>
        public string CodigoMoeda { get; set; }
    }
}