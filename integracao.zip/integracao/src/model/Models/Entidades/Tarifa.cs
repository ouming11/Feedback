using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Tarifa
    /// </summary>
    [DataContract]
    public sealed class Tarifa
    {
        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [Required]
        public DescritorValor Valor { get; set; }

        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        [Required]
        public TipoTarifa Tipo { get; set; }
    }
}