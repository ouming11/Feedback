﻿using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Filiação
    /// </summary>
    public sealed class Filiacao
    {
        /// <summary>
        /// Tipo de filiação.
        /// </summary>
        public TipoFiliacao Tipo { get; set; }

        /// <summary>
        /// Nome.
        /// </summary>
        public Nome Nome { get; set; }
    }
}

