﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Nome
    /// </summary>
    public sealed class Nome
    {
        /// <summary>
        /// Nome civil completo da pessoa relativa à filiação. (Direito
		/// fundamental da pessoa, o nome civil é aquele atribuído à pessoa
		/// natural desde o registro de seu nascimento, com o qual será
		/// identificada por toda a sua vida, bem como após a sua morte).
        /// </summary>
        [MaxLength(70)]
        public string NomeCivil { get; set; }

        /// <summary>
        /// Nome social da pessoa natural, se houver. (aquele pelo qual prefere
		/// ser chamado, identificado por sua comunidade e em seu meio social,
		/// conforme Decreto Local).
        /// </summary>
        [MaxLength(70)]
        public string NomeSocial { get; set; }
    }
}

