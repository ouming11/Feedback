using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using PrbCartao.Integracao.Models;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Entidades
{
    /// <summary>
    /// Conta
    /// </summary>
    [DataContract]
    public class Conta
    {
        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        public Guid IdConta { get; set; }

        /// <summary>
        /// Produto associado.
        /// </summary>
        [Required]
        public Produto Produto { get; set; }

        /// <summary>
        /// Identificador único da conta atribuído pela processadora.
        /// </summary>
        public string IdExterno { get; set; }

        /// <summary>
        /// Informações relacionadas ao titular da conta.
        /// </summary>
        [Required]
        public Titular Titular { get; set; }

        /// <summary>
        /// Informações de Crédito
        /// </summary>
        public InformacoesCredito InformacoesCredito { get; set; }

        /// <summary>
        /// Cartões associados a esta conta
        /// </summary>
        public List<Card> Cartoes { get; set; }

        /// <summary>
        /// Situação da conta
        /// </summary>
        public SituacaoConta Situacao { get; set; }

        /// <summary>
        /// Endereço de cobrança
        /// </summary>
        public Endereco EnderecoCobranca { get; set; }

        /// <summary>
        /// Endereço de entrega do Cartão.
        /// </summary>
        public Endereco EnderecoEntregaCartao { get; set; }

        /// <summary>
        /// Data de inclusão da conta.
        /// </summary>
        public DateTime DataCriacao { get; set; }
    }
}
