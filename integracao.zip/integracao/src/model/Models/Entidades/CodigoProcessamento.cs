using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Código de Processamento.
    /// Combinação de Tipo de Transação e Tipo de Conta que determinam
    /// roteamento de mensagens internas no backoffice.
    /// </summary>
    [DataContract]
    public sealed class CodigoProcessamento
    {
        /// <summary>
        /// Identifica qual é o tipo da transação
        /// </summary>
        public TipoTransacao TipoTransacao { get; set; }

        /// <summary>
        /// Identifica qual é o tipo da conta de origem
        /// </summary>
        [Required]
        public TipoConta TipoContaOrigem { get; set; }

        /// <summary>
        /// Identifica qual é o tipo da conta de destino
        /// </summary>
        [Required]
        public TipoConta TipoContaDestino { get; set; }
    }
}