using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Identificação do cartão.
    /// </summary>
    [DataContract]
    public sealed class Cartao
    {
        /// <summary>
        /// Identificador único do cartão na processadora.
        /// De acordo com as regras de imutabilidade da processadora.
        /// </summary>
        [Required]
        public string IdCartaoProcessadora { get; set; }

        /// <summary>
        /// Identificador do cartão no emissor.
        /// </summary>
        public Guid IdCartaoEmissor { get; set; }

        /// <summary>
        /// Últimos 4 dígitos do número do cartão - Primary Account Number (PAN).
        /// </summary>
        [Required]
        public string Pan { get; set; }

        /// <summary>
        /// Número de sequência do PAN.
        /// </summary>
        public string NumeroSequenciaPan { get; set; }
    }
}