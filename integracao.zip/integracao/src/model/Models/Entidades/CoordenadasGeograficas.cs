﻿using System;
namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Coordenadas Geográficas
    /// </summary>
    public class CoordenadasGeograficas
    {
        /// <summary>
        /// Latitude da posição geográfica.
        /// Valores válidos são entre -90.0 e 90.0 graus.
        /// </summary>
        public double Latitude { get; set; }

        /// <summary>
        /// Longitude da posição geográfica.
        /// Valores válidos são entre -180.0 até 180.0 graus.
        /// </summary>
        public double Longitude { get; set; }

        /// <summary>
        /// Horário em que as coordenadas foram determinadas.
        /// </summary>
        public DateTime Timestamp { get; set; }
    }
}
