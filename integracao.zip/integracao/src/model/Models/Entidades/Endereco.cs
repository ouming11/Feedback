﻿using System;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Endereço
    /// </summary>
    public sealed class Endereco
    {
        /// <summary>
        /// Identifica quando o endereço é o preferencial.
        /// </summary>
        public bool Preferencial { get; set; }

        /// <summary>
        /// Tipo do endereço.
        /// </summary>
        public TipoEndereco TipoEndereco { get; set; }

        /// <summary>
        /// Logradouro.
        /// </summary>
        public string Logradouro { get; set; }

        /// <summary>
        /// Complemento.
        /// </summary>
        public string Complemento { get; set; }

        /// <summary>
        /// Bairro, comunidade ou região localizada em uma cidade ou município de acordo com as suas subdivisões geográficas.
        /// </summary>
        public string Bairro { get; set; }

        /// <summary>
        /// Cidade.
        /// </summary>
        public string Cidade { get; set; }

        /// <summary>
        /// Código da cidade conforme IBGE.
        /// </summary>
        public string CodigoCidadeIbge { get; set; }

        /// <summary>
        /// UF.
        /// </summary>
        public string UF { get; set; }

        /// <summary>
        /// CEP.
        /// </summary>
        public string CEP { get; set; }

        /// <summary>
        /// País.
        /// </summary>
        public string Pais { get; set; }

        /// <summary>
        /// Código do país (alfa-3) conforme ISO 3166-1.
        /// </summary>
        public string CodigoPais { get; set; }

        /// <summary>
        /// Coordenadas geográficas do endereço.
        /// </summary>
        public CoordenadasGeograficas CoordenadasGeograficas { get; set; }
    }
}
