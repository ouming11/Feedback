﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Pessoa
    /// </summary>
    public abstract class Pessoa : DataCriacaoEAtualizacao
    {
        /// <summary>
        /// Identificador único imutável da pessoa.
        /// </summary>
        public Guid IdPessoa { get; set; }

        /// <summary>
        /// Nome.
        /// </summary>
        public Nome Nome { get; set; }

        /// <summary>
        /// Data de nascimento no formato dd/MM/yyyy
        /// </summary>
        [Required]
        public DateOnly Nascimento { get; set; }

        /// <summary>
        /// Estado civil.
        /// </summary>
        public EstadoCivil? CivilStatus { get; set; }

        /// <summary>
        /// Sexo
        /// </summary>
        public Sexo? Sexo { get; set; }

        /// <summary>
        /// Número completo do CPF. Atributo que corresponde às informações
        /// mínimas exigidas pela Regulamentação em vigor. O CPF é o Cadastro
        /// de Pessoa natural. Ele é um documento feito pela Receita Federal e
        /// serve para identificar os contribuintes. O CPF é uma numeração com
        /// 11 dígitos, que só mudam por decisão judicial. O documento é emitido
        /// pela receita federal. Caso necessário, completar com zeros à
        /// esquerda.
        /// </summary>
        [Required]
        [RegularExpression("^[0-9]{11}$")]
        public string Documento { get; set; }

        /// <summary>
        /// Gets or Sets OtherIdentityDocumentNumber
        /// </summary>
        public List<DetalheDocumento> OutrosDocumentos { get; set; }

        /// <summary>
        /// Nome do país de nascimento ou de naturalização do portador.
        /// Obrigatório caso o cliente não possua nacionalidade brasileira.
        /// Utilize o código de pais de acordo com o código alpha3 do
        /// ISO-3166, por exemplo, "CAN".
        /// </summary>
        [Required]
        public string Nacionalidade { get; set; }

        /// <summary>
        /// Filiação
        /// </summary>
        public Filiacao Filiacao { get; set; }

        /// <summary>
        /// Números de telefone associados à pessoa.
        /// </summary>
        public List<Telefone> Telefones { get; set; }

        /// <summary>
        /// email
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Endereços
        /// </summary>
        public List<Endereco> Enderecos { get; set; }

        /// <summary>
        /// Ocupação
        /// </summary>
        public Ocupacao Ocupacao { get; set; }
    }
}

