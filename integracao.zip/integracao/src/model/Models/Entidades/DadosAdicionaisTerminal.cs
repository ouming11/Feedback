using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Contempla os dados adicionais pertencentes ao ponto de venda/saque
    /// (por exemplo, um POS) no momento em que a transação foi realizada.
    /// </summary>
    [DataContract]
    public sealed class DadosAdicionaisTerminal
    {
        /// <summary>
        /// Indicador de tipo de atendimento no Terminal.
        /// </summary>
        public TipoAtendimentoTerminal? TipoAtendimentoTerminal { get; set; }

        /// <summary>
        /// Aprovação Parcial.
        /// </summary>
        public AprovacaoParcial? AprovacaoParcial { get; set; }

        /// <summary>
        /// Localização do Terminal.
        /// </summary>
        public LocalizacaoTerminal? LocalizacaoTerminal { get; set; }

        /// <summary>
        /// Indicador de Presença do Portador.
        /// </summary>
        public PresencaDoPortador? PresencaDoPortador { get; set; }

        /// <summary>
        /// Indicador de Presença do Cartão.
        /// </summary>
        public PresencaDoCartao? PresencaDoCartao { get; set; }

        /// <summary>
        /// Capacidade de Captura de Cartão.
        /// </summary>
        public CapacidadeCapturaCartao? CapacidadeCapturaCartao { get; set; }

        /// <summary>
        /// Propósito da solicitação.
        /// </summary>
        public PropositoTransacao? PropositoTransacao { get; set; }

        /// <summary>
        /// Indicador de Segurança da Transação.
        /// Este subcampo será preenchido pelo Estabelecimento para indicar se
        /// existe suspeita de fraude ou não.
        /// </summary>
        public IndicadorSegurancaTransacao? IndicadorSegurancaTransacao { get; set; }

        /// <summary>
        /// Tipo do Terminal (Dispositivo).
        /// </summary>
        public TipoTerminal? TipoTerminal { get; set; }

        /// <summary>
        /// Capacidade de Entrada do Terminal.
        /// </summary>
        public CapacidadeEntradaTerminal? CapacidadeEntradaTerminal { get; set; }
    }
}