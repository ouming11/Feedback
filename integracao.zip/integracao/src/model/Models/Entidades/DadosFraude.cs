using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// A presença deste campo indica que um Score de Fraude é entregue ao
    /// Emissor juntamente com dados adicionais de fraude. O Credenciador pode
    /// enviar seu Score de Fraude para a Bandeira e Emissor utilizando este
    /// campo.
    /// </summary>
    [DataContract]
    public sealed class DadosFraude
    {
        /// <summary>
        /// Score de Fraude do Emissor.
        /// </summary>
        public int? ClassificacaoPeloEmissor { get; set; }

        /// <summary>
        /// Score de Fraude da Bandeira.
        /// </summary>
        public int? ClassificacaoPelaBandeira { get; set; }

        /// <summary>
        /// Lista com os códigos de motivos para o score de fraude.
        /// </summary>
        public int[] Razoes { get; set; }

        /// <summary>
        /// Recomendação de decisão por fraude.
        /// </summary>
        public string RecomendacaoDeDecisao { get; set; }
    }
}