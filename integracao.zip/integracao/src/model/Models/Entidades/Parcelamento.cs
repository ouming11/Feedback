using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Pagamentos Parcelados.
    /// </summary>
    [DataContract]
    public sealed class Parcelamento
    {
        /// <summary>
        /// Quantidade total de parcelamento.
        /// Indica o número de Pagamentos ou Prestações Recorrentes de acordo
        /// com o Contrato do Portador do Cartão com o Estabelecimento.
        /// Valores válidos:
        /// - 02 a 99
        /// - ND - Não Definido
        /// - UC – Até o Cancelamento
        /// </summary>
        public string QuantidadeTotalDeParcelas { get; set; }

        /// <summary>
        /// Tipo de Parcelamento.
        /// </summary>
        public TipoParcelamento TipoParcelamento { get; set; }

        /// <summary>
        /// Tipo de pagamento.
        /// Indica se um Pagamento Recorrente ou Prestação é um valor fixo ou
        /// variável.
        /// </summary>
        public TipoPagamento? TipoPagamento { get; set; }

        /// <summary>
        /// Tipo de Transação iniciada pelo Estabelecimento.
        /// Os valores são usados para processar a primeira transação de
        /// pagamento e as subsequentes.
        /// </summary>
        public TipoPagamento? TipoTransacaoPagamento { get; set; }

        /// <summary>
        /// Valor da transação iniciada pelo estabelecimento (MIT).
        /// Indica o valor do Parcelamento ou Pagamento Recorrente.
        /// Os valores são usados para processar a primeira e as transações de
        /// pagamento subsequentes para esses tipos de pagamento específicos.
        /// </summary>
        public decimal? ValorDaTransacao { get; set; }

        /// <summary>
        /// ID Único.
        /// Usado para identificar de forma única cada Pagamento Recorrente ou
        /// Parcelado (fornecido automaticamente). Este ID é usado para fazer
        /// referência a autorizações e avisos de autorizações.  Os valores são
        /// usados para processar a primeira e as subsequentes Transações com
        /// Cartão de uma transação de pagamento.
        /// </summary>
        public string IdTransacao { get; set; }

        /// <summary>
        /// Frequência da transação iniciada pelo estabelecimento(MIT). Indica a
        /// frequência de um pagamento ou parcelamento recorrente. 
        /// </summary>
        public Frequencia? Frequencia { get; set; }

        /// <summary>
        /// Indicador de validação da transação do cartão com a fonte de
        /// validação.
        /// </summary>
        public Validacao? Validacao { get; set; }
    }
}