using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Portador : Pessoa
    {
        /// <summary>
        /// Tipo de portador.
        /// </summary>
        [Required]
        public TipoPortador CardholderType { get; set; }

        /// <summary>
        /// Gets or Sets CardData
        /// </summary>
        [Required]
        public string NomeImpresso { get; set; }


    }
}
