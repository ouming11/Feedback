using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Ocupação
    /// </summary>
    [DataContract]
    public class Ocupacao
    {
        /// <summary>
        /// Nome da empresa onde trabalha
        /// </summary>
        public string Empregador { get; set; }

        /// <summary>
        /// Nome do cargo ou função exercida na empresa.
        /// </summary>
        public string Cargo { get; set; }

        /// <summary>
        /// Quantos anos no cargo atual.
        /// </summary>
        public int? AnosNoCargoAtual { get; set; }

        /// <summary>
        /// Salário ou renda da pessoa.
        /// </summary>
        public DescritorValor Renda { get; set; }
    }
}