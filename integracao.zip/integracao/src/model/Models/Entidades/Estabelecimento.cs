using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Estabelecimento
    /// </summary>
    [DataContract]
    public sealed class Estabelecimento
    {
        /// <summary>
        /// Merchant Category Code (MCC) do estabelecimento
        /// </summary>
        [Required]
        public string Mcc { get; set; }

        /// <summary>
        /// Nome do estabelecimento
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Endereço do estabelecimento.
        /// </summary>
        public Endereco Endereco { get; set; }

        /// <summary>
        /// Documento do estabelecimento
        /// </summary>
        public string Cnpj { get; set; }
    }
}