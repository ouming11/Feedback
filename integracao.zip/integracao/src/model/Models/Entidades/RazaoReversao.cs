using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// Informa ao Emissor a razão ou motivo.
    /// </summary>
    [DataContract]
    public sealed class RazaoReversao
    {
        /// <summary>
        /// Código da razão.
        /// </summary>
        [Required]
        public int Codigo { get; set; }

        /// <summary>
        /// Descrição da razão.
        /// </summary>
        [Required]
        public string Descricao { get; set; }
    }
}