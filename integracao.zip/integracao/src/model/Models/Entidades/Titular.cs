using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace PrbCartao.Integracao.Models.Entidades
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Titular : Pessoa
    {

    }
}
