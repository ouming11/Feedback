using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class TransactionQueryResult
    {
        /// <summary>
        /// Identificador da transação atribuído pela integracao.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Data e hora da transação.
        /// </summary>
        [Required]
        public DateTime TransactionDateTime { get; set; }

        /// <summary>
        /// Data e hora do recebimento na liquidação.
        /// </summary>
        public DateTime SettlementDateTime { get; set; }

        /// <summary>
        /// Gets or Sets TransactionType
        /// </summary>
        [Required]
        public TipoTransacao TransactionType { get; set; }

        /// <summary>
        /// Situacao da Transacao
        /// </summary>
        [Required]
        public SituacaoTransacao SituacaoTransacao { get; set; }

        /// <summary>
        /// Gets or Sets TransactionAuthorizationResponse
        /// </summary>
        public TransactionAuthorizationResponse TransactionAuthorizationResponse { get; set; }

        /// <summary>
        /// Código de identificação da rede de captura da transação.
        /// </summary>
        public string AcquirerId { get; set; }

        /// <summary>
        /// Identificador da transação na rede de captura.
        /// </summary>
        public string AcquirerTransactionId { get; set; }

        /// <summary>
        /// Identificação do estabelecimento informada na autorização.
        /// </summary>
        public string MerchantId { get; set; }

        /// <summary>
        /// Nome do estabelecimento.
        /// </summary>
        public string MerchantName { get; set; }

        /// <summary>
        /// CNPJ do estabelecimento.
        /// </summary>
        public string MerchantDocumentId { get; set; }

        /// <summary>
        /// Endereço do estabelecimento.
        /// </summary>
        public string MerchantAddress { get; set; }

        /// <summary>
        /// Cidade do estabelecimento.
        /// </summary>
        public string MerchantCity { get; set; }

        /// <summary>
        /// Uf do estabelecimento
        /// </summary>
        public string MerchantUf { get; set; }

        /// <summary>
        /// Código do país conforme ISO 3166-1.
        /// </summary>
        public string CountryCode { get; set; }

        /// <summary>
        /// MCC da transação
        /// </summary>
        public string Mcc { get; set; }

        /// <summary>
        /// Identificação do terminal informada na autorização.
        /// </summary>
        public string TerminalId { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// Gets or Sets RemainingAmount
        /// </summary>
        public DescritorValor RemainingAmount { get; set; }

        /// <summary>
        /// Gets or Sets RefundedAmount
        /// </summary>
        public DescritorValor RefundedAmount { get; set; }

        /// <summary>
        /// Gets or Sets EntryMode
        /// </summary>
        public ModoEntradaPan EntryMode { get; set; }

        /// <summary>
        /// Se transação foi realizada por meio de um cartão, os dados do cartão são representados por este campo.
        /// </summary>
        public CardQueryResult Card { get; set; }

        /// <summary>
        /// Identificador da transação que realizou o estorno dessa transação. Deprecado. Será substituído progressivamente pelo cancellingTransactionIds (lista de IDs de transações de cancelamento/estornos).
        /// </summary>
        public string CancellingTransactionId { get; set; }

        /// <summary>
        /// Lista contendo um ou mais identificadores de transações de estorno.
        /// </summary>
        public List<string> CancellingTransactionIds { get; set; }

        /// <summary>
        /// Indica se a transação for uma transação internacional. Falso se for uma transação doméstica.
        /// </summary>
        public bool? International { get; set; }

        /// <summary>
        /// Se transação for internacional, contêm dados referentes a esse tipo de transação.
        /// </summary>
        public InternationalData InternationalTransactionData { get; set; }

        /// <summary>
        /// Indica se esta transação é um aviso de autorização (true) ou é uma requisição que foi validada pelo emissor (false ou não informado).
        /// </summary>
        public bool? AuthorizationAdvice { get; set; }

        /// <summary>
        /// Gets or Sets MitAdditionalData
        /// </summary>
        public MitAdditionalData MitAdditionalData { get; set; }

        /// <summary>
        /// Gets or Sets AdditionalTerminalData
        /// </summary>
        public DadosAdicionaisTerminal AdditionalTerminalData { get; set; }

        /// <summary>
        /// Gets or Sets TokenPaymentData
        /// </summary>
        public TokenPaymentData TokenPaymentData { get; set; }

        /// <summary>
        /// Gets or Sets InstallmentDetails
        /// </summary>
        public InstallmentDetails InstallmentDetails { get; set; }

        /// <summary>
        /// Indica se é uma transação feita com cartão HCE (true) ou outro tipo de cartão (false)
        /// </summary>
        public bool? HceTransaction { get; set; }

        /// <summary>
        /// Motivo do cancelamento da transação. Presente somente em transações canceladas por expiração de prazo.
        /// </summary>
        public RazaoCancelamento? CancellationReason { get; set; }
    }
}
