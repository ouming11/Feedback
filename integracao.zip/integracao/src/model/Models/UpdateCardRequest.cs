using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UpdateCardRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse identificador é ecoado na resposta. Nenhuma verificação dele é feita por parte da integracao, o emissor é livre para escolher o valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Identificador único para esse cartão no emissor.
        /// </summary>
        public string IssuerCardId { get; set; }

        /// <summary>
        /// Flag indicando se o cartão deve ou não acatar transações feitas com o modo de entrada sem contato. Assumido como \&quot;true\&quot; se não enviado. Obrigatório caso o campo &#x27;cardholder&#x27; não seja enviado.
        /// </summary>
        public bool? AllowContactless { get; set; }

        /// <summary>
        /// Informações relacionadas ao portador do cartão.
        /// </summary>
        [Required]
        public Portador Cardholder { get; set; }
    }
}

