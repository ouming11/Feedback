using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class FunctionalitiesInformation
    {
        /// <summary>
        /// Descrição da funcionalidade.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Indica qual o tipo da funcionalidade.
        /// </summary>
        [Required]
        public TipoFuncionalidade Code { get; set; }

        /// <summary>
        /// Indica se a funcionalidade é internacional ou não.
        /// </summary>
        [Required]
        public bool International { get; set; }

        /// <summary>
        /// Indica se a funcionalidade compras está ativa.
        /// </summary>
        [Required]
        public bool Active { get; set; }
    }
}

