﻿using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Requisição de Transação de Provisionamento de Host-based Card Emulation (HCE)
    /// </summary>
    [DataContract]
    public class HceProvisionRequestTransaction
    {
        /// <summary>
        /// Informação extra do emissor que pode ser associada à transação e recuperada posteriormente no ‘status’.
        /// </summary>
        public string IssuerCustomData { get; set; }

        /// <summary>
        /// Identificador único do emissor para a transação.
        /// </summary>
        public string IssuerTxId { get; set; }
    }
}
