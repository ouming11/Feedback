using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Installment
    {
        /// <summary>
        /// Data da parcela.
        /// </summary>
        [Required]
        public DateOnly DataParcela { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }
    }
}
