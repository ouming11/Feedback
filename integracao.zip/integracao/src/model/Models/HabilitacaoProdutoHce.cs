using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class HabilitacaoProdutoHce
    {
        /// <summary>
        /// Dados de habilitação do produto (PAN, dados EMV), que serão lidos e
        /// utilizados pela aplicação adquirente para validar a transação. São
        /// cifrados com as credenciais do token vault.
        /// </summary>
        public string ProductResponse { get; set; }

        /// <summary>
        /// Identificador único do dispositivo, fornecido pelo emissor.
        /// </summary>
        public string IssuerDeviceId { get; set; }
    }
}
