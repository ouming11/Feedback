using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class TaxasECet
    {
        /// <summary>
        /// Gets or Sets RevolvingCredit
        /// </summary>
        [Required]
        public CustoEfetivoTotal RevolvingCredit { get; set; }

        /// <summary>
        /// Gets or Sets StatementInstallmentFinancing
        /// </summary>
        public CustoEfetivoTotal StatementInstallmentFinancing { get; set; }

        /// <summary>
        /// Gets or Sets CashWithdrawal
        /// </summary>
        public CustoEfetivoTotal CashWithdrawal { get; set; }

        /// <summary>
        /// Gets or Sets LatenessInterest
        /// </summary>
        [Required]
        public CustoEfetivoTotal LatenessInterest { get; set; }
    }
}
