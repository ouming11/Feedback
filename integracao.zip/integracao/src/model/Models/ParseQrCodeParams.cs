using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class ParseQrCodeParams
    {
        /// <summary>
        /// String do QR Code.
        /// </summary>
        [Required]
        public string QrCode { get; set; }
    }
}
