using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Dados bancários.
    /// </summary>
    [DataContract]
    public class DadosBancarios
    {
        /// <summary>
        /// Número do Banco.
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Nome do banco.
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Código da agência.
        /// </summary>
        public string Agencia { get; set; }

        /// <summary>
        /// Número da conta, incluindo dígito verificador.
        /// </summary>
        public string ContaComDigito { get; set; }
    }
}
