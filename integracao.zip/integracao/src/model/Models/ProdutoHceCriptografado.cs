using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class ProdutoHceCriptografado
    {
        /// <summary>
        /// Informações sobre o produto, criptografadas com as chaves compartilhadas entre o token vault e o TSP.
        /// </summary>
        [Required]
        public string ProductData { get; set; }

        /// <summary>
        /// Identificador único do dispositivo, fornecido pelo emissor.
        /// </summary>
        [Required]
        public string IssuerDeviceId { get; set; }

        /// <summary>
        /// Identificador do produto no Token Vault.
        /// </summary>
        [Required]
        public string ProductId { get; set; }
    }
}
