using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UnprovisionRequest
    {
        /// <summary>
        /// Gets or Sets Transaction
        /// </summary>
        public UnprovisionRequestTransaction Transaction { get; set; }
    }
}
