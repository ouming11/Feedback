using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class FraudNotificationUndoRequest
    {
        /// <summary>
        /// Identificador único da conta atribuído pela integracao.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Identificador da transação fraudada.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
