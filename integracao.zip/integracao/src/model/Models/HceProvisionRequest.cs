using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Requisição de Provisionamento de Host-based Card Emulation (HCE)
    /// </summary>
    [DataContract]
    public class HceProvisionRequest
    {
        /// <summary>
        /// Gets or Sets Mobile Token Vault
        /// </summary>
        public HceProvisionRequestMtv MobileTokenVault { get; set; }

        /// <summary>
        /// Gets or Sets Constraints
        /// </summary>
        public HceProvisionRequestConstraints Constraints { get; set; }

        /// <summary>
        /// Gets or Sets Transaction
        /// </summary>
        public HceProvisionRequestTransaction Transaction { get; set; }
    }
}
