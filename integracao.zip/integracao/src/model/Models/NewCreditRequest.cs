using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class NewCreditRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse identificador é ecoado na resposta. Nenhuma verificação dele é feita por parte da integracao, o emissor é livre para escolher o valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Descrição do crédito
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Data de início de validade/disponibilização de crédito nos cartões.
        /// </summary>
        public DateTime? InclusionDate { get; set; }

        /// <summary>
        /// Gets or Sets EffectivePaymentDate
        /// </summary>
        public DateTime? EffectivePaymentDate { get; set; }

        /// <summary>
        /// Valor do crédito a ser adicionado na conta.
        /// </summary>
        [Required]
        public DescritorValor Amount { get; set; }

        /// <summary>
        /// tipo de caga de crédito realizada (normal, emergencial, etc).
        /// </summary>
        public int? CreditType { get; set; }

        /// <summary>
        /// Tipo de crédito realizado. Em atualizações futuras essa propriedade será obrigatória.
        /// </summary>
        public TipoCredito? Type { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
