using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class InputPin
    {
        /// <summary>
        /// Identificador da chave de transporte de PIN estabelecido entre emissor e integracao.
        /// </summary>
        [Required]
        public string IdTransportKey { get; set; }

        /// <summary>
        /// PIN cifrado pela chave de transporte de identificador [idTransportKey]
        /// </summary>
        [Required]
        public string PinBlock { get; set; }
    }
}
