using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class PinChangeRequest
    {
        /// <summary>
        /// Identificador único da requisição de mudança de senha. Gerado pelo emissor.
        /// </summary>
        public string IssuerPINChangeId { get; set; }

        /// <summary>
        /// Gets or Sets NewPin
        /// </summary>
        [Required]
        public Pin NewPin { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
