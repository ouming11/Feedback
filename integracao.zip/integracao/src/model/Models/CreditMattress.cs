using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CreditMattress
    {
        /// <summary>
        /// Identificador da transação.
        /// </summary>
        [Required]
        public string TransactionId { get; set; }

        /// <summary>
        /// Data e hora do recebimento da transação no serviço, no formato definido pela RFC 3339, seção 5.6.
        /// </summary>
        [Required]
        public DateTime CreditReceivedDateTime { get; set; }

        /// <summary>
        /// Data da transação
        /// </summary>
        public DateOnly Data { get; set; }

        /// <summary>
        /// Hora da transação
        /// </summary>
        public TimeOnly Hora { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [Required]
        public DebitOrCreditAmount Amount { get; set; }

        /// <summary>
        /// Status do aporte.
        /// </summary>
        [Required]
        public SituacaoAporte Status { get; set; }

        /// <summary>
        /// Indica se esse aporte é um cancelamento de outro aporte anterior.
        /// </summary>
        public bool? Cancellation { get; set; }
    }
}
