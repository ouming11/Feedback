using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Pin
    {
        /// <summary>
        /// Identificador da chave de transporte de PIN estabelecido entre emissor e integracao.
        /// </summary>
        [Required]
        public string IdTransportKey { get; set; }

        /// <summary>
        /// PIN cifrado pela chave de transporte de identificador [idTransportKey]
        /// </summary>
        [Required]
        public string PinBlock { get; set; }

        /// <summary>
        /// Formato do PINBlock (Só ISO-0 e ISO-1 são suportados)
        /// </summary>
        public Iso? Format { get; set; }
    }
}
