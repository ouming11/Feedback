using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class TransferData
    {
        /// <summary>
        /// Gets or Sets PaymentType
        /// </summary>
        [Required]
        public TipoTransferencia PaymentType { get; set; }

        /// <summary>
        /// Número Único de referência. Número de Referência atribuído pelo Originador da Transferência de Fundos (Gateway). Preenchimento - Conteúdo alfanumérico, espaços a direita se necessário. Para transação doméstica, caso o tipo de pagamento seja igual a P2P e os cartões do remetente e do destinatário forem da bandeira Elo, o conteúdo deste campo deverá ser o mesmo nas transações de retirada de fundos e de recebimento de fundos.
        /// </summary>
        public string UniqueReferenceNumber { get; set; }

        /// <summary>
        /// Nome do Remetente. Nome de quem está enviando os fundos na transferência. Transação de recebimento de fundos e retirada de fundos - Enviado se capturado pelo gateway.
        /// </summary>
        public string SendersName { get; set; }

        /// <summary>
        /// Endereço do Remetente. Endereço de quem está enviando os fundos na transferência. Campo Mandatório em transações internacionais. Opcional em transações domésticas.
        /// </summary>
        public string SendersAddress { get; set; }

        /// <summary>
        /// Cidade do Remetente. Cidade de quem está enviando os fundos na transferência. Campo Mandatório em transações internacionais. Opcional em transações domésticas.
        /// </summary>
        public string SendersCity { get; set; }

        /// <summary>
        /// Código do País ou código estado se o país for os Estados Unidos. Código do País de quem está enviando os fundos na transferência. Se o país for Estados Unidos deve ser enviado o código do estado e não o do país. Esta informação deve ser enviada em todas as transações utilizando como base a ISO 3166-1 numeric. Para transações nacionais utiliza-se o código 076 (Brasil). Campo Mandatório em transações internacionais. Opcional em transações domésticas.
        /// </summary>
        public string CountryOrStateCodeIfUS { get; set; }

        /// <summary>
        /// CEP do Portador. CEP de quem está retirando ou recebendo os fundos na transferência. Na transação de retirada de fundos - Campo refere-se ao Destinatário. Na transação de recebimento de fundos - Campo refere-se ao Remetente. Campo Mandatório em transações internacionais exceto na retirada de fundos. Campo Opcional em transações domésticas.
        /// </summary>
        public string CardholderZipcode { get; set; }

        /// <summary>
        /// Número de identificação do portador impactado com esta transação. No caso de transações internacionais, o conteúdo deste campo deve corresponder a um Número único designado e enviado pelo originador da transação (Gateway). Não deve ser o PAN. No caso de domésticas, o conteúdo deste campo deve corresponder ao CPF / CNPJ do portador que está recebendo os fundos da transferência no caso de transação de retirada de fundos e ao CPF / CNPJ do portador que está enviando os fundos da transferência no caso de transação de recebimento de fundos. Neste caso, a formatação do campo para transação doméstica seguirá o seguinte formato.  Posições de 0 a 14 Na transação de retirada de fundos, preencher com o Número do CPF ou CNPJ do Destinatário, completando com zeros a esquerda se necessário. Na transação de recebimento de fundos preencher com o Número do CPF ou CNPJ do Remetente, completando com zeros a esquerda se necessário.
        /// </summary>
        public string CardholderIdentificationNumber { get; set; }

        /// <summary>
        /// Origem dos fundos. A origem dos fundos que o remetente está utilizando. Valores válidos incluem: * 01 &#x3D; Crédito * 02 &#x3D; Débito * 03 &#x3D; Pré pago * 04 &#x3D; Dinheiro * 05 &#x3D; Cheque * 06 &#x3D; ACH/FED * 07-16 &#x3D; Reservado para Uso Futuro * 17 &#x3D; Conta Corrente * 18 &#x3D; Conta Poupança  Campo Mandatório quando tipo de pagamento for igual a &#x27;P2P&#x27;, &#x27;A2A&#x27; ou &#x27;B2A&#x27; e opcional para os demais.
        /// </summary>
        public string OriginOfFunds { get; set; }

        /// <summary>
        /// Data de Nascimento do remetente.  O formato deve ser MMDDAAAA.
        /// </summary>
        public DateOnly BirthDateOfSender { get; set; }

        /// <summary>
        /// Nome do destinatário. Nome de quem está recebendo os fundos da transferência (recebedor). Enviado se capturado pelo gateway.
        /// </summary>
        public string RecipientsName { get; set; }

        /// <summary>
        /// Dados Adicionais da Transferência. Exclusivamente para transações domésticas. Carrega dados complementares para transações de transferência de fundos. O conteúdo das informações deste elemento é livre e estabelecido pelo próprio Gateway.
        /// </summary>
        public string AdditionalTransferData { get; set; }

        /// <summary>
        /// Código do Destinatário. Exclusivamente para transações domésticas. Apresenta o código do Destinatário constante no Diretório do Gateway (código do recebedor).
        /// </summary>
        public string RecipientCode { get; set; }

        /// <summary>
        /// E-mail do Remetente dos fundos. Exclusivamente para transações domésticas, sendo enviado se capturado pelo gateway. Esta Tag é de uso exclusivo para o Tipo de pagamento P2P.
        /// </summary>
        public string FundSenderEmail { get; set; }

        /// <summary>
        /// E-mail do Destinatário dos fundos. Exclusivamente para transações domésticas, sendo enviado se capturado pelo gateway. Esta Tag é de uso exclusivo para os Tipos de pagamento P2P, CSB e DSB.
        /// </summary>
        public string FundRecipientEmail { get; set; }

        /// <summary>
        /// Telefone do Remetente dos fundos. Exclusivamente para transações domésticas, sendo enviado se capturado pelo gateway. Esta Tag é de uso exclusivo para o Tipo de pagamento P2P.
        /// </summary>
        public string FundSenderPhone { get; set; }

        /// <summary>
        /// Telefone do Destinatário dos fundos. Exclusivamente para transações domésticas, sendo enviado se capturado pelo gateway. Esta Tag é de uso exclusivo para os Tipos de pagamento P2P, CSB e DSB.
        /// </summary>
        public string FundRecipientPhone { get; set; }

        /// <summary>
        /// Device ID. Exclusivamente para transações domésticas, onde este campo deve ser enviado com o conteúdo que identifica de forma única o dispositivo que originou a transação de retirada ou recebimento de fundos. Esta Tag deve ser enviada para o Tipo de pagamento P2P se capturada pelo gateway. Esta Tag é opcional para os Tipos de pagamento DSB e CSB.
        /// </summary>
        public string DeviceID { get; set; }

        /// <summary>
        /// CPF/CNPJ do Portador do cartão desta transação. Exclusivamente para transações domésticas, onde este campo deve ser enviado se a informação for capturada pelo gateway. Dado que identifica o CPF / CNPJ do portador do cartão desta transação. Para transação de retirada de fundos, deverá ser considerado o CPF / CNPJ do remetente dos fundos da transferência. Para transação de recebimento de fundos, deverá ser considerado o CPF / CNPJ do destinatário dos fundos da transferência. Completar com zeros a esquerda se necessário.
        /// </summary>
        public string CardholderCpfOrCnpj { get; set; }

        /// <summary>
        /// BIN Retirada. Exclusivamente para transações domésticas de recebimento de fundos, onde este campo é mandatório se a origem dos fundos for uma conta cartão. Esta Tag é de uso exclusivo para o Tipo de pagamento P2P.
        /// </summary>
        public string BINOrigin { get; set; }

        /// <summary>
        /// BIN Destino. Exclusivamente para transações domésticas de retirada de fundos, onde este campo é mandatório se o destino dos fundos for uma conta cartão. Esta Tag é de uso exclusivo para o Tipo de pagamento P2P.
        /// </summary>
        public string BINDestination { get; set; }

        /// <summary>
        /// 4 últimos dígitos do cartão da retirada de fundos. Exclusivamente para transações domésticas de recebimento de fundos, onde este campo é mandatório se a origem dos fundos for uma conta cartão. Esta Tag é de uso exclusivo para o Tipo de pagamento P2P.
        /// </summary>
        public string OriginCardLast4digits { get; set; }

        /// <summary>
        /// 4 últimos dígitos do cartão de destino dos fundos. Exclusivamente para transações domésticas de retirada de fundos, onde este campo é mandatório se o destino dos fundos for uma conta cartão. Esta Tag é de uso exclusivo para o Tipo de pagamento P2P (Tag 01).
        /// </summary>
        public string DestinationCardLast4digits { get; set; }
    }
}
