using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class SimplePaymentCardParams
    {
        /// <summary>
        /// Identificador único do cartão virtual gerado pea integracao no momento da sua criação, no formato \&quot;vcrt-{UUID-v4}\&quot;
        /// </summary>
        [Required]
        public string VCardId { get; set; }

        /// <summary>
        /// String do QR Code.
        /// </summary>
        [Required]
        public string QrCode { get; set; }
    }
}
