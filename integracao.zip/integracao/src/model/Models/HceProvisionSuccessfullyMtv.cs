using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Provisionamento de Host-based Card Emulation (HCE) no Mobile Token Vault (MTV)
    /// </summary>
    [DataContract]
    public class HceProvisionSuccessfullyMtv
    {
        /// <summary>
        /// Dados de provisionamento prontos para serem carregados no dispositivo através da interface do Mobile Token Vault.
        /// </summary>
        public string ProvResponse { get; set; }

        /// <summary>
        /// Identificador único do dispositivo, fornecido pelo emissor.
        /// </summary>
        public string IssuerDeviceId { get; set; }
    }
}
