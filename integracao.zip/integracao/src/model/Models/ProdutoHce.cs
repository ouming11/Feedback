using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class ProdutoHce

    {
        /// <summary>
        /// Valor do produto real que será representado por um token para evitar
        /// expor seu conteúdo e para permitir sua validação em transações e
        /// tradução de forma segura utilizando os mecanismos providos pelo
        /// Mobile Token Vault e pelo Token Service Provider.
        /// </summary>
        [Required]
        public string ProductValue { get; set; }

        /// <summary>
        /// Tipo de produto.
        /// </summary>
        [Required]
        public string ProductType { get; set; }

        /// <summary>
        /// Nome do emissor do produto.
        /// </summary>
        [Required]
        public string IssuerName { get; set; }
    }
}
