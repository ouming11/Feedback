using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class FraudNotificationCardholderData
    {
        /// <summary>
        /// Nome completo do portador, ou razão social se for pessoa jurídica.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Código postal do portador
        /// </summary>
        [Required]
        public string Zipcode { get; set; }

        /// <summary>
        /// Cidade do portador
        /// </summary>
        [Required]
        public string City { get; set; }

        /// <summary>
        /// Estado do portador
        /// </summary>
        [Required]
        public string State { get; set; }
    }
}
