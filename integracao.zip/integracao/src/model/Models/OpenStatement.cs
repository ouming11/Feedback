using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class OpenStatement
    {
        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Data de vencimento da fatura.
        /// </summary>
        [Required]
        public string PaymentDue { get; set; }

        /// <summary>
        /// Data de fechamento da fatura.
        /// </summary>
        public string CloseDate { get; set; }

        /// <summary>
        /// Saldo da fatura anterior
        /// </summary>
        public DescritorValor PreviousBalance { get; set; }

        /// <summary>
        /// Saldo total da fatura
        /// </summary>
        [Required]
        public DescritorValor Balance { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor limite de crédito atribuído à conta pelo emissor.
        /// </summary>
        [Required]
        public DescritorValor CreditLimit { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor limite de crédito para saques atribuído à conta pelo emissor.
        /// </summary>
        [Required]
        public DescritorValor WithdrawalCreditLimit { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor do limite disponível atualmente para a conta, já descontando o saldo.
        /// </summary>
        [Required]
        public DescritorValor CurrentCreditLimit { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor limite atualmente disponível para saques, j´descontando gastos.
        /// </summary>
        [Required]
        public DescritorValor CurrentWithdrawalCreditLimit { get; set; }

        /// <summary>
        /// Lista de lançamentos em aberto
        /// </summary>
        [Required]
        public List<StatementEntry> TransactionsList { get; set; }

        /// <summary>
        /// Data e hora da última transação inserida na fatura.
        /// </summary>
        public DateTime? FirstTransactionInserted { get; set; }

        /// <summary>
        /// Data e hora de abertura da Fatura.
        /// </summary>
        public DateTime? OpeningDateTime { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
