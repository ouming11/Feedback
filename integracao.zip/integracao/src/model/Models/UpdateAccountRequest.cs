using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UpdateAccountRequest
    {
        /// <summary>
        /// Identificador único da requisição gerado pelo emissor. Esse identificador é ecoado na resposta. Nenhuma verificação dele é feita por parte da integracao, o emissor é livre para escolher o valor que quiser.
        /// </summary>
        public string IssuerRequestId { get; set; }

        /// <summary>
        /// Produto
        /// </summary>
        public Produto Produto { get; set; }

        /// <summary>
        /// Gets or Sets CreditInfo
        /// </summary>
        public InformacoesCredito CreditInfo { get; set; }

        /// <summary>
        /// Endereço de faturamento da conta.
        /// </summary>
        public Endereco BillingAddress { get; set; }

        /// <summary>
        /// Endereço para entrega do cartão.
        /// </summary>
        public Endereco CardDeliveryAddress { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
