using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class FutureStatement
    {
        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Data de vencimento da fatura.
        /// </summary>
        [Required]
        public DateOnly Vencimento { get; set; }

        /// <summary>
        /// Data de fechamento da fatura.
        /// </summary>
        public DateOnly Fechamento { get; set; }

        /// <summary>
        /// Saldo total da fatura
        /// </summary>
        [Required]
        public DescritorValor Balance { get; set; }

        /// <summary>
        /// Lista de lançamentos em aberto
        /// </summary>
        [Required]
        public List<StatementEntry> TransactionsList { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
