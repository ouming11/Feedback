using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class PaymentCardParams
    {
        /// <summary>
        /// Identificador da chave pública usada para cifrar os dados de pagamento. Essa chave tem ter sido obtida em algum ponto através de uma chamada de /qrcode/publickey.
        /// </summary>
        [Required]
        public string KeyId { get; set; }

        /// <summary>
        /// Dados do cartão e do portador, cifrados pela chave pública. Os dados devem estar no formato JSON, porém removendo os espaços em branco entre os campos, como evidenciado nesse exemplo: {\&quot;cardHolder\&quot;:{\&quot;card\&quot;:{\&quot;pan\&quot;:\&quot;6550001020301234\&quot;,\&quot;expiry\&quot;:{\&quot;month\&quot;:\&quot;01\&quot;,\&quot;year\&quot;:\&quot;2021\&quot;},\&quot;name\&quot;:\&quot;JOAO SILVA\&quot;,\&quot;csc\&quot;:\&quot;123\&quot;},\&quot;cpf\&quot;:\&quot;18535908005\&quot;}}
        /// </summary>
        [Required]
        public string CipheredInformation { get; set; }

        /// <summary>
        /// String do QR Code.
        /// </summary>
        [Required]
        public string QrCode { get; set; }

        /// <summary>
        /// Parâmetro opcional. Um booleano indicando se a resposta desse pagamento deve ser recebida como callback (valor true) ao invés de ser recebida diretamente na resposta desse endpoint. Por padrão o valor é falso, e sugerimos que ele seja mantido assim nas primeiras implementações do uso do pagamento por QR Code.
        /// </summary>
        public bool? ReceiveCallback { get; set; }
    }
}
