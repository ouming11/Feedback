using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class TransactionDenialReason
    {
        /// <summary>
        /// Código de negação retornado pelo autorizador.
        /// </summary>
        public string DenialCode { get; set; }

        /// <summary>
        /// Descrição textual do motivo da negação.
        /// </summary>
        public string DenialDescription { get; set; }
    }
}
