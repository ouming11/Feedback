﻿using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Requisição de Provisionamento de Host-based Card Emulation (HCE)
    /// </summary>
    [DataContract]
    public class HceProvisionSuccessfullyTransaction
    {
        /// <summary>
        /// Identificador único de resposta da integracao.
        /// </summary>
        public string ProcessadoraTxId { get; set; }

        /// <summary>
        /// Identificador único do emissor para a transação.
        /// </summary>
        public string IssuerTxId { get; set; }
    }
}
