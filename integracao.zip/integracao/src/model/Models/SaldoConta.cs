using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Saldo da conta.
    /// </summary>
    [DataContract]
    public class SaldoConta
    {
        /// <summary>
        /// Identificador único da conta.
        /// </summary>
        [Required]
        public string AccountId { get; set; }

        /// <summary>
        /// Saldo de compras da conta
        /// </summary>
        [Required]
        public DescritorValor Saldo { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor limite de crédito atribuído à conta pelo emissor.
        /// </summary>
        public DescritorValor LimiteCredito { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor limite de crédito para saques atribuído à conta pelo emissor.
        /// </summary>
        public DescritorValor LimiteSaque { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor do limite disponível atualmente para a conta, já descontando o saldo.
        /// </summary>
        public DescritorValor LimiteCreditoAtual { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Valor limite atualmente disponível para saques, j´descontando gastos.
        /// </summary>
        public DescritorValor LimiteSaqueAtual { get; set; }

        /// <summary>
        /// Para produtos de crédito pós-pago: Dia de vencimento da fatura mensal.
        /// </summary>
        [Range(1, 31)]
        public int DiaVencimentoMensal { get; set; }
    }
}
