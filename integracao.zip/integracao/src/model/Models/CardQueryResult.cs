using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CardQueryResult
    {
        /// <summary>
        /// BIN do cartão.
        /// </summary>
        public string BIN { get; set; }

        /// <summary>
        /// Últimos quatro dígitos do cartão.
        /// </summary>
        public string LastFourDigits { get; set; }

        /// <summary>
        /// Identificador único do cartão.
        /// </summary>
        public string CardId { get; set; }
    }
}
