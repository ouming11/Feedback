using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class PinValidateRequest
    {
        /// <summary>
        /// Identificador único da requisição de validação de senha. Gerado pelo emissor.
        /// </summary>
        public string IssuerPINValidateId { get; set; }

        /// <summary>
        /// Gets or Sets Pin
        /// </summary>
        [Required]
        public InputPin Pin { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }
    }
}
