using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Entidades;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// Informa o limite de crédito para a conta.
    /// </summary>
    [DataContract]
    public class InformacoesCredito : DataCriacaoEAtualizacao
    {
        /// <summary>
        /// Valor limite de crédito atribuído à conta pelo emissor.
        /// </summary>
        public DescritorValor LimiteCredito { get; set; }

        /// <summary>
        /// Dia de vencimento da fatura mensal.
        /// </summary>
        [Range(1, 31)]
        public int DiaVencimentoFatura { get; set; }
    }
}
