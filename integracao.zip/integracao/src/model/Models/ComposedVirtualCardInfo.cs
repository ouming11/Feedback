using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class ComposedVirtualCardInfo
    {
        /// <summary>
        /// Gets or Sets _Virtual
        /// </summary>
        public VirtualCardDescriptor DescritorCartaoVirtual { get; set; }

        /// <summary>
        /// Gets or Sets Constraints
        /// </summary>
        public VirtualCardConstraints Constraints { get; set; }

        /// <summary>
        /// Gets or Sets Info
        /// </summary>
        public VirtualCardInfo Info { get; set; }
    }
}
