using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class UnblockAccountRequest
    {
        /// <summary>
        /// Código identificando o tipo de desbloqueio.
        /// </summary>
        [Required]
        public int UnblockCode { get; set; }
    }
}
