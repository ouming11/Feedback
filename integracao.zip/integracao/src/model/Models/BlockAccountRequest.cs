using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class BlockAccountRequest
    {
        /// <summary>
        /// Código identificando o tipo de bloqueio.
        /// </summary>
        [Required]
        public int BlockCode { get; set; }
    }
}
