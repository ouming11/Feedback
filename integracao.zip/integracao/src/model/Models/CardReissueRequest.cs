using System.Runtime.Serialization;
using System.Text;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class CardReissueRequest
    {
        /// <summary>
        /// Identificador do novo cartão no emissor
        /// </summary>
        public string IssuerCardId { get; set; }

        /// <summary>
        /// Dados extras para o novo cartão
        /// </summary>
        public string ExtraData { get; set; }

        /// <summary>
        /// Código numérico de até seis dígitos combinado entre emissor, integracao e gráfica, para determinar a arte do cartão.
        /// </summary>
        public decimal? DeliveryKitCode { get; set; }

        /// <summary>
        /// Identificador único da requisição de nova via. Gerado pelo emissor.
        /// </summary>
        public string IssuerCardReissueId { get; set; }

        /// <summary>
        /// Flag indicando se o cartão deve ou não acatar transações feitas com o modo de entrada sem contato. Assumido como \&quot;true\&quot; se não enviado.
        /// </summary>
        public bool? AllowContactless { get; set; }

        /// <summary>
        /// Transportadora escolhida para entrega
        /// </summary>
        public string Transportadora { get; set; }

        /// <summary>
        /// Campo que contém o endereço de devolução do cartão em caso de insucesso na entrega.
        /// </summary>
        public string ReturnAddress { get; set; }

        /// <summary>
        /// Motivo da nova via.
        /// </summary>
        public string Reason { get; set; }

        /// <summary>
        /// Endereço para entrega do cartão.
        /// </summary>
        public AddressWithRecipient CardDeliveryAddress { get; set; }

        /// <summary>
        /// Gets or Sets SourceAudit
        /// </summary>
        public SourceAudit SourceAudit { get; set; }

        /// <summary>
        /// Gráfica escolhida para emissão do Cartão
        /// </summary>
        public string Grafica { get; set; }
    }
}
