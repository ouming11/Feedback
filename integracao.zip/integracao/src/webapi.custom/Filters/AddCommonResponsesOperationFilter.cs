﻿using System;
using System.Reflection.Metadata;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace webapi.custom.Filters
{
    /// <summary>
    /// Adiciona respostas comuns quando necessário.
    /// </summary>
    public class AddCommonResponsesOperationFilter : IOperationFilter
    {
        private const string STATUS_200_OK = "200";
        private const string STATUS_202_ACCEPTED = "202";
        private const string STATUS_204_NO_CONTENT = "204";
        private const string STATUS_400_BAD_REQUEST = "400";
        private const string STATUS_409_CONFLICT = "409";
        private const string STATUS_500_INTERNAL_SERVER_ERROR = "500";
        private const string STATUS_503_SERVICE_UNAVAILABLE = "503";

        /// <summary>
        /// Aplica o filtro.
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="context"></param>
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation.Responses == null || !operation.Responses.Any())
                return;

            SetDescriptionIfPresent(operation, STATUS_202_ACCEPTED, "Requisição aceita. Indica que a requisição foi recebida, mas o processamento ainda não completou.");
            SetDescriptionIfPresent(operation, STATUS_204_NO_CONTENT, "Sem conteúdo / não encontrado. A requisição foi executada corretamente, mas nenhum dado foi encontrado para ser retornado.");
            SetDescriptionIfPresent(operation, STATUS_400_BAD_REQUEST, "Requisição inválida. O corpo da resposta pode conter informações adicionais. Corrija antes de tentar novamente.");
            SetDescriptionIfPresent(operation, STATUS_409_CONFLICT, "Conflito. O corpo da resposta pode conter informações adicionais. Corrija antes de tentar novamente.");
            AddIfMissing(operation, STATUS_500_INTERNAL_SERVER_ERROR, "Erro inesperado. O corpo da resposta pode conter informações adicionais.");
            AddIfMissing(operation, STATUS_503_SERVICE_UNAVAILABLE, "Sistema indisponível no momento. Aguarde antes de tentar novamente.");
        }

        private static void SetDescriptionIfPresent(OpenApiOperation operation, string statusCode, string description)
        {
            if (!operation.Responses.ContainsKey(statusCode))
                return;

            var openApiResponse = operation.Responses[statusCode];
            openApiResponse.Description = description;
        }

        private static void AddIfMissing(OpenApiOperation operation, string statusCode, string description)
        {
            if (operation.Responses.ContainsKey(statusCode))
                return;

            operation.Responses.Add(statusCode, new OpenApiResponse { Description = description });
        }
    }
}

