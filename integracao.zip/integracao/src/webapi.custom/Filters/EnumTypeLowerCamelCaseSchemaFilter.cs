﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace PrbCartao.Webapi.Custom.Filters
{
    /// <summary>
    /// Modifica a saída padrão do Swashbuckler para enums, adicionando
    /// a descrição contida na tag summary de cada membro do enum, quando
    /// possível.
    /// </summary>
    public class EnumTypeLowerCamelCaseSchemaFilter : ISchemaFilter
    {
        private const string NAME = "name";
        private const string MEMBER = "member";
        private const string SUMMARY = "summary";
        private const string BULLET = "- ";
        private const string SEPARATOR = " - ";
        private readonly XDocument _xmlComments;

        /// <summary>
        /// Inicializa uma nova instância, usando o arquivo XML de documentação
        /// informado para localizar as tags Summary para os membros dos
        /// enums expostos via Swagger.
        /// </summary>
        /// <param name="xmlPath"></param>
        public EnumTypeLowerCamelCaseSchemaFilter(string xmlPath)
        {
            if (File.Exists(xmlPath))
                _xmlComments = XDocument.Load(xmlPath);
            else
                _xmlComments = default!;
        }

        /// <summary>
        /// Complementa o "Description" original com as descrições dos membros
        /// de enums, inserindo uma lista com o valor e o conteúdo das tags
        /// Summary, caso presentes no XML de documentação.
        /// </summary>
        /// <param name="schema"></param>
        /// <param name="context"></param>
        public void Apply(OpenApiSchema schema, SchemaFilterContext context)
        {
            var sb = new StringBuilder(schema.Description);
            if (schema.Enum == null || schema.Enum.Count <= 0 || !(context.Type is { IsEnum: true }))
                return;

            sb.AppendLine();
            foreach (var memberName in Enum.GetNames(context.Type))
            {
                if (string.IsNullOrWhiteSpace(memberName))
                    continue;

                sb.Append(BULLET);
                sb.Append(ToLowerCamelCase(memberName));

                if (context.Type == null || context.Type.FullName == null)
                    continue;

                if (TryGetSummaryFromXmlDocumentation(context.Type.FullName, memberName, out var summary))
                {
                    sb.Append(SEPARATOR);
                    sb.Append(summary);
                }

                sb.AppendLine();
            }

            schema.Description = sb.ToString();
        }

        private static string ToLowerCamelCase(string value)
        {
            if (char.IsLower(value[0]))
                return value;

            if (value.Length == 1)
                return value.ToLower();

            return char.ToLowerInvariant(value[0]) + value[1..];
        }

        private bool TryGetSummaryFromXmlDocumentation(string fullTypeName, string memberName, out string summary)
        {
            var fullEnumMemberName = $"F:{fullTypeName}.{memberName}";
            var enumMemberComments = _xmlComments.Descendants(MEMBER).FirstOrDefault(m => m.Attribute(NAME)!.Value.Equals(fullEnumMemberName, StringComparison.OrdinalIgnoreCase));

            var contents = enumMemberComments?.Descendants(SUMMARY).FirstOrDefault();
            if (contents != null && !string.IsNullOrWhiteSpace(contents.Value))
            {
                summary = contents.Value.Trim();
                return true;
            }

            summary = null!;
            return false;
        }
    }
}

