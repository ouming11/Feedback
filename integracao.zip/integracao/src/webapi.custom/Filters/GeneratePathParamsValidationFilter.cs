using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace PrbCartao.Webapi.Custom.Filters
{
    /// <summary>
    /// Path Parameter Validation Rules Filter
    /// </summary>
    public sealed class GeneratePathParamsValidationFilter : IOperationFilter
    {
        /// <summary>
        /// Apply the filter.
        /// </summary>
        /// <param name="operation">Operation</param>
        /// <param name="context">OperationFilterContext</param>
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            var pars = context.ApiDescription.ParameterDescriptions;

            foreach (var par in pars)
            {
                if (!TryGetParams(operation, par, out var swaggerParam))
                    continue;

                if (!TryGetAttributes(par, out var attributes) || attributes == null)
                    continue;

                // [Required]
                swaggerParam.Required = IsRequired(attributes);

                // [RegularExpression]
                if (TryGetRegularExpression(attributes, out string pattern))
                    swaggerParam.Schema.Pattern = pattern;

                // [MinLength] ou [StringLength] minimo
                if (TryGetMin(attributes, out int? minLength))
                    swaggerParam.Schema.MinLength = minLength;

                // [MaxLength] ou [StringLength] máximo
                if (TryGetMax(attributes, out int? maxLength))
                    swaggerParam.Schema.MaxLength = maxLength;

                // Range [Range]
                if (TryGetRange(attributes, out int? rangeMin, out int? rangeMax))
                {
                    swaggerParam.Schema.Minimum = rangeMin;
                    swaggerParam.Schema.Maximum = rangeMax;
                }
            }
        }

        private static bool TryGetMin(IEnumerable<CustomAttributeData> attributes, out int? minLength)
        {
            var ret = false;
            if (TryGetStringMinLength(attributes, out minLength))
                ret = true;

            if (TryGetInt<MinLengthAttribute>(attributes, out minLength))
                ret = true;

            return ret;
        }

        private static bool TryGetMax(IEnumerable<CustomAttributeData> attributes, out int? maxLength)
        {
            var ret = false;
            if (TryGetInt<StringLengthAttribute>(attributes, out maxLength))
                ret = true;

            if (TryGetInt<MaxLengthAttribute>(attributes, out maxLength))
                ret = true;

            return ret;
        }

        private static bool TryGetParams(OpenApiOperation operation, ApiParameterDescription par, out OpenApiParameter swaggerParam)
        {
            swaggerParam = operation.Parameters.SingleOrDefault(p => p.Name == par.Name)!;
            return swaggerParam != null;
        }

        private static bool TryGetAttributes(ApiParameterDescription par, out IEnumerable<CustomAttributeData>? attributes)
        {
            attributes = ((ControllerParameterDescriptor)par.ParameterDescriptor).ParameterInfo.CustomAttributes;
            if (attributes == null || !attributes.Any())
            {
                attributes = null!;
                return false;
            }

            return true;
        }

        private static bool TryGetRange(IEnumerable<CustomAttributeData> attributes, out int? rangeMin, out int? rangeMax)
        {
            var rangeAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(RangeAttribute));
            if (rangeAttr == null)
            {
                rangeMin = null;
                rangeMax = null;
                return false;
            }

            rangeMin = (int?)rangeAttr.ConstructorArguments[0].Value;
            rangeMax = (int?)rangeAttr.ConstructorArguments[1].Value;
            return true;
        }

        private static bool TryGetStringMinLength(IEnumerable<CustomAttributeData> attributes, out int? minLength)
        {
            var stringLengthAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(StringLengthAttribute));
            if (stringLengthAttr != null && stringLengthAttr.NamedArguments.Count == 1)
            {
                minLength = (int?)stringLengthAttr.NamedArguments.Single(p => p.MemberName == "MinimumLength").TypedValue.Value;
                return true;
            }

            minLength = null;
            return false;
        }

        private static bool TryGetInt<T>(IEnumerable<CustomAttributeData> attributes, out int? value)
        {
            var maxLengthAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(T));
            if (maxLengthAttr != null)
            {
                value = (int?)maxLengthAttr.ConstructorArguments[0].Value;
                return true;
            }

            value = null;
            return false;
        }

        private static bool IsRequired(IEnumerable<CustomAttributeData> attributes)
        {
            var requiredAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(RequiredAttribute));
            return requiredAttr != null;
        }

        private static bool TryGetRegularExpression(IEnumerable<CustomAttributeData> attributes, out string pattern)
        {
            var regexAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(RegularExpressionAttribute));
            if (regexAttr == null)
            {
                pattern = null!;
                return false;
            }

            pattern = (string)regexAttr.ConstructorArguments[0].Value!;
            return !string.IsNullOrEmpty(pattern);
        }
    }
}