using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PrbCartao.Integracao.Comandos;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Models.Respostas;
using PrbCartao.Integracao.Operacoes;
using PrbCartao.Webapi.Custom.Attributes;
using Swashbuckle.AspNetCore.Annotations;

namespace Integracao.Operacoes.Controllers
{
    /// <summary>
    /// Saques
    /// </summary>
    [ApiController]
    public sealed class SaquesController : ControllerBase
    {
        /// <summary>
        /// Realiza a consulta de um saque.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="transacao">Identificador único da transação.</param>
        /// <param name="token">Token informado originalmente no momento do aceite da transação para processamento.</param>
        /// <response code="204">Quando a transação não foi localizada.</response>
        [HttpGet]
        [Route("/integracao/operacoes/v1/saques/{transacao}/{token}")]
        [ValidateModelState]
        [SwaggerOperation("RecuperaSaque")]
        [ProducesResponseType(statusCode: 200, type: typeof(Saque))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [Produces("application/json")]
        public IActionResult RecuperaSaque([FromRoute] Guid transacao, Guid token)
        {
            return Ok(new Saque());
        }

        /// <summary>
        /// Realiza a consulta de status um saque.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="transacao">Identificador único da transação.</param>
        /// <param name="token">Token informado originalmente no momento do aceite da transação para processamento.</param>
        /// <response code="204">Quando a transação não foi localizada.</response>
        [HttpGet]
        [Route("/integracao/operacoes/v1/saques/{transacao}/{token}/status")]
        [ValidateModelState]
        [SwaggerOperation("RecuperaStatusSaque")]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(SituacaoSaque))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [Produces("application/json")]
        public IActionResult RecuperaStatusSaque([FromRoute] Guid transacao, Guid token)
        {
            return Ok(new SituacaoSaque());
        }

        /// <summary>
        /// Consome o saldo de uma conta de acordo com o valor total informado.
        /// Para um saque ser aceito é necessário que a conta e o cartão tenham
        /// sido criados anteriormente e estejam ativos.
        /// </summary>
        /// <remarks>Cria um novo registro de saque, que pode ter sido reprovado
        /// ou aprovado, nesse caso consumindo o saldo de acordo com o valor
        /// total informado, o qual considera o valor original e as taxas
        /// associadas à transação.</remarks>
        /// <param name="body">Informações do saque.</param>
        /// <response code="202">Saque aceito com sucesso.</response>
        /// <response code="204">Conta não encontrada ou cartão inexistente.</response>
        /// <response code="400">Dados informados são inválidos. O detalhe do problema está no payload de retorno.</response>
        /// <response code="409">Validações de negócio impedem o aceite da Transação, como saldo insuficiente, transação já foi cancelada, operação não permitida, etc. O detalhe está no payload de resposta.</response>
        [HttpPost]
        [Route("/integracao/operacoes/v1/saques")]
        [ValidateModelState]
        [SwaggerOperation("CriarSaque")]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [Produces("application/json")]
        public IActionResult CriarSaque([FromBody] Saque body)
        {
            return Ok();
        }

        /// <summary>
        /// Cancelamento de saque.
        /// </summary>
        /// <remarks>
        /// A operação de cancelamento desfaz um saque, devolvendo o saldo
        /// consumido caso ele tivesse sido aprovado.
        /// Normalmente o cancelamento é disparado automaticamente a partir de
        /// um sistema backend caso uma transação não tenha sido completada com
        /// sucesso.
        /// </remarks>
        /// <param name="body">Informações do cancelamento.</param>
        /// <response code="202">Cancelamento de Saque aceito com sucesso.</response>
        /// <response code="204">Transação não encontrada para cancelamento.</response>
        /// <response code="400">Dados informados são inválidos. O detalhe do problema está no payload de retorno.</response>
        /// <response code="409">Validações de negócio impedem o aceite da requisição. O detalhe do problema está no payload de resposta.</response>
        [HttpPost]
        [Route("/integracao/operacoes/v1/saques/cancelamento")]
        [ValidateModelState]
        [SwaggerOperation("CriarCancelamentoSaque")]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [Produces("application/json")]
        public IActionResult CriarCancelamentoSaque([FromBody] CancelarSaque body)
        {
            return Ok();
        }

        /// <summary>
        /// Estorno de Saque.
        /// </summary>
        /// <remarks>A operação de estorno desfaz um saque, devolvendo o saldo
        /// consumido  caso ele tivesse sido aprovado.
        /// Transações de estorno são iniciadas por uma pessoa.
        /// Pode ser o próprio cliente que solicitou ou, por exemplo, alguém da
        /// Contabilidade.
        /// </remarks>
        /// <param name="body">Dados do estorno.</param>
        /// <response code="202">Estorno de Saque aceito com sucesso.</response>
        /// <response code="204">Transação não encontrada para cancelamento.</response>
        /// <response code="400">Dados informados são inválidos. O detalhe do problema está no payload de retorno.</response>
        /// <response code="409">Validações de negócio impedem o aceite da requisição. O detalhe do problema está no payload de resposta.</response>
        [HttpPost]
        [Route("/integracao/operacoes/v1/saques/estorno")]
        [ValidateModelState]
        [SwaggerOperation("CriarEstornoSaque")]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [Produces("application/json")]
        public IActionResult CriarEstornoSaque([FromBody] CancelarSaque body)
        {
            return Ok();
        }
    }
}