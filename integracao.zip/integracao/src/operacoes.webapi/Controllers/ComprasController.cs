using PrbCartao.Webapi.Custom.Attributes;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PrbCartao.Integracao.Comandos;
using PrbCartao.Integracao.Models.Entidades;
using PrbCartao.Integracao.Operacoes;
using Swashbuckle.AspNetCore.Annotations;
using PrbCartao.Integracao.Models;
using System;
using PrbCartao.Integracao.Models.Respostas;

namespace Integracao.Operacoes.Controllers
{
    /// <summary>
    /// Compras
    /// </summary>
    [ApiController]
    public sealed class ComprasController : ControllerBase
    {
        /// <summary>
        /// Realiza a consulta de uma compra.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="transacao">Identificador único da transação.</param>
        /// <param name="token">Token informado originalmente no momento do aceite da transação para processamento.</param>
        /// <response code="200">Dados da transação solicitada.</response>
        /// <response code="204">Transação não foi localizada.</response>
        /// <response code="500">Falha indesperada.</response>
        /// <response code="503">Serviço indisponível.</response>
        [HttpGet]
        [Route("/integracao/operacoes/v1/compras/{transacao}/{token}")]
        [ValidateModelState]
        [SwaggerOperation("RecuperaCompra")]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(Compra))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(statusCode: StatusCodes.Status503ServiceUnavailable)]
        [Produces("application/json")]
        public IActionResult RecuperaSaque([FromRoute] Guid transacao, Guid token)
        {
            return Ok(new Compra());
        }

        /// <summary>
        /// Realiza a consulta de status uma compra.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="transacao">Identificador único da transação.</param>
        /// <param name="token">Token informado originalmente no momento do aceite da transação para processamento.</param>
        /// <response code="200">Status da transação solicitada.</response>
        /// <response code="204">Transação não foi localizada.</response>
        /// <response code="500">Falha indesperada.</response>
        /// <response code="503">Serviço indisponível.</response>
        [HttpGet]
        [Route("/integracao/operacoes/v1/compras/{transacao}/{token}/status")]
        [ValidateModelState]
        [SwaggerOperation("RecuperaStatusCompra")]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(SituacaoCompra))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(statusCode: StatusCodes.Status503ServiceUnavailable)]
        [Produces("application/json")]
        public IActionResult RecuperaStatusCompra([FromRoute] Guid transacao, Guid token)
        {
            return Ok(new SituacaoCompra());
        }

        /// <summary>
        /// Consome o saldo de uma conta de acordo com o valor total informado.
        /// Para uma compra seja aceita é necessário que a conta e o cartão tenham
        /// sido criados anteriormente e estejam ativos.
        /// </summary>
        /// <remarks>
        /// Cria um novo registro de compra. o registro pode ser de uma compra
        /// negada (apenas informativo) ou de uma conta aprovada, consumindo o
        /// saldo de acordo com o valor total informado, o qual considera o
        /// valor original e as taxas associadas à transação.
        /// </remarks>
        /// <param name="body">Objeto de compra será criado caso haja saldo na conta.</param>
        /// <response code="202">Transação aceita com sucesso.</response>
        /// <response code="204">Conta não encontrada ou cartão inexistente.</response>
        /// <response code="400">Dados informados são inválidos. O detalhe do problema está no payload de retorno.</response>
        [HttpPost]
        [Route("/integracao/operacoes/v1/compras")]
        [ValidateModelState]
        [SwaggerOperation("CriarCompra")]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [Produces("application/json")]
        public IActionResult CriarCompra([FromBody] Compra body)
        {
            return Ok();
        }

        /// <summary>
        /// Cancelamento de compra.
        /// </summary>
        /// <remarks>
        /// A operação de cancelamento desfaz uma compra, devolvendo o saldo
        /// consumido se aquela compra tinha sido aprovada.
        /// Normalmente o cancelamento é disparado automaticamente a partir de
        /// um sistema backend caso uma transação não tenha sido completada com
        /// sucesso.
        /// </remarks>
        /// <param name="body">Dados do cancelamento, desfazendo uma compra previamente realizada.</param>
        /// <response code="202">Transação cancelada com sucesso.</response>
        /// <response code="204">Transação não encontrada.</response>
        /// <response code="400">Dados informados são inválidos. O detalhe do problema está no payload de retorno.</response>
        [HttpPost]
        [Route("/integracao/operacoes/v1/compras/cancelamento")]
        [ValidateModelState]
        [SwaggerOperation("CriarCancelamentoCompra")]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [Produces("application/json")]
        public IActionResult CriarCancelamentoCompra([FromBody] CancelarCompra body)
        {
            return Ok();
        }

        /// <summary>
        /// Estorno de compra.
        /// Transações de estorno são iniciadas por uma pessoa.
        /// Pode ser o próprio cliente que solicitou ou, por exemplo, alguém da
        /// Contabilidade.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="body">Dados do estorno, desfazendo uma compra previamente realizada.</param>
        /// <response code="200">Transação estornada com sucesso.</response>
        /// <response code="204">Transação não encontrada.</response>
        /// <response code="400">Dados informados são inválidos. O detalhe do problema está no payload de retorno.</response>
        [HttpPost]
        [Route("/integracao/operacoes/v1/compras/estorno")]
        [ValidateModelState]
        [SwaggerOperation("CriarEstornoCompra")]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [Produces("application/json")]
        public IActionResult CriarCancelamentoCompra([FromBody] EstornarCompra body)
        {
            return Ok();
        }
    }
}