API de integração Paraná Banco com Processadora contém funções que compreendem
desde a
solicitação de inclusão de novas contas e cartões,
pedidos de crédito,
funções de atendimento e intercâmbio,
associação de CPF à conta e cartão,
bloqueio e desbloqueio de cartões
até o envio de extrato mensal.

