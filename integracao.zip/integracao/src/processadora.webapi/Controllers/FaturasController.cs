using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Faturas.
    /// </summary>
    [ApiController]
    public class FaturasController : ControllerBase
    {
        /// <summary>
        /// Recupera informações sobre todas as faturas que fecharam em um dia específico.
        /// </summary>
        /// <remarks>Retorna todos os dados das faturas que que fecharam em um dia específico, passado como parâmetro.</remarks>
        /// <param name="closingDateQuery">Data indicando que só faturas que fecharam nessa data devem ser retornadas. No formato dd/MM/yyyy.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <response code="200">Fatura recuperada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/vi/contas/statements/closed")]
        [ValidateModelState]
        [SwaggerOperation("GetAccountStatementsClosed")]
        public virtual IActionResult GetAccountStatementsClosed([FromQuery] string closingDateQuery, [FromQuery] string startingAfter)
        {
            return Ok();
        }
    }
}
