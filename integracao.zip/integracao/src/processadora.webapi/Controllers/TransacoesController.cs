using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using PrbCartao.Integracao.Models.Enumeradores;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Transações.
    /// </summary>
    [ApiController]
    public class TransacoesController : ControllerBase
    {
        /// <summary>
        /// Registra uma nova carga de créditos com data de efetivação.
        /// </summary>
        /// <remarks>Solicita registro de uma nova carga de créditos para a conta com identificador {accountId}.</remarks>
        /// <param name="body">Informações relacionadas à carga de créditos para inclusão na processadora integracao.</param>
        /// <param name="accountId">Identificador da conta.</param>
        /// <response code="200">Transação registrada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/transacoes/{accountId}/credits")]
        [ValidateModelState]
        [SwaggerOperation("AddCreditTransaction")]
        public virtual IActionResult AddCredit([FromBody] NewCreditRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Registra um novo débito.
        /// </summary>
        /// <remarks>Solicita registro de um novo débito para a conta com identificador {accountId}.</remarks>
        /// <param name="body">Informações relacionadas ao débito para inclusão na processadora integracao.</param>
        /// <param name="accountId">Identificador da conta.</param>
        /// <response code="200">Transação registrada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/transacoes/{accountId}/debits")]

        [ValidateModelState]
        [SwaggerOperation("AddDebit")]
        public virtual IActionResult AddDebit([FromBody] NewDebitRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Recebe um callback sobre uma transação de QR Code Elo
        /// </summary>
        /// <remarks>Recebe um callback sobre uma transação de QR Code Elo</remarks>
        /// <param name="body">Informações relacionadas à carga de créditos para inclusão na processadora integracao.</param>
        /// <param name="transactionId">Identificador da transação.</param>
        /// <response code="200">Transação criada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/callbacks/transactions/{transactionId}")]
        [ValidateModelState]
        [SwaggerOperation("CallbackTransaction")]
        public virtual IActionResult CallbackTransaction([FromBody] NewCreditRequest body, [FromRoute][Required] string transactionId)
        {
            return Ok();
        }

        /// <summary>
        /// Lista cargas de créditos agendadas mas ainda não executadas.
        /// </summary>
        /// <param name="accountId">Identificador da conta.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <response code="200">Lista de créditos sações retornada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/transacoes/{accountId}/credits")]
        [ValidateModelState]
        [SwaggerOperation("FindCreditTransactionsByAccount")]
        public virtual IActionResult FindCreditsByAccount([FromRoute][Required] string accountId, [FromQuery][Range(1, 100)] int? limit, [FromQuery] string startingAfter, [FromQuery] string endingBefore)
        {
            return Ok();
        }

        /// <summary>
        /// Lista transações a partir de filtros especificados.
        /// </summary>
        /// <param name="beginningDate">Data indicando o primeiro dia cujos dados devem ser retornados.</param>
        /// <param name="endingDate">Data indicando o último dia cujos dados devem ser retornados.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <param name="transactionType">Tipo das transações a serem retornadas.</param>
        /// <param name="transactionStatus">Status das transações a serem retornadas.</param>
        /// <param name="transactionApproved">Se a transação foi aprovada pelo autorizador.</param>
        /// <param name="transactionDenialCode">Transações negadas no autorizador com um código específico.</param>
        /// <param name="minimumAmount">Valor mínimo, omitindo a vírgula. Por exemplo, R$ 1,23 ficaria \&quot;amount\&quot;:123</param>
        /// <param name="maxAmount">Valor máximo, omitindo a vírgula. Por exemplo, R$ 1,23 ficaria \&quot;amount\&quot;:123</param>
        /// <param name="transactionMode">Modo da transação.</param>
        /// <response code="200">Lista de transações retornada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/transacoes")]
        [ValidateModelState]
        [SwaggerOperation("FindTransactions")]
        [ProducesResponseType(statusCode: 200, type: typeof(TransactionListResult))]
        public virtual IActionResult FindTransactions(
            [FromQuery][Required()] string beginningDate,
            [FromQuery][Required()] string endingDate,
            [FromQuery][Range(1, 100)] int? limit,
            [FromQuery] string startingAfter,
            [FromQuery] string endingBefore,
            [FromQuery] TipoTransacao transactionType,
            [FromQuery] SituacaoTransacao transactionStatus,
            [FromQuery] bool? transactionApproved,
            [FromQuery] string transactionDenialCode,
            [FromQuery] long? minimumAmount,
            [FromQuery] long? maxAmount,
            [FromQuery] ModoEntradaPan transactionMode)
        {
            return Ok();
        }

        /// <summary>
        /// Lista transações a partir de filtros especificados.
        /// </summary>
        /// <param name="accountId">Identificador da conta.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <param name="beginningDateTime">Data e hora para iniciar procura.</param>
        /// <param name="endingDateTime">Data e hora para parar procura.</param>
        /// <param name="transactionType">Tipo das transações a serem retornadas.</param>
        /// <param name="transactionStatus">Status das transações a serem retornadas.</param>
        /// <param name="transactionApproved">Se a transação foi aprovada pelo autorizador.</param>
        /// <param name="transactionDenialCode">Transações negadas no autorizador com um código específico.</param>
        /// <param name="minimumAmount">Valor mínimo, omitindo a vírgula. Por exemplo, R$ 1,23 ficaria \&quot;amount\&quot;:123</param>
        /// <param name="maxAmount">Valor máximo, omitindo a vírgula. Por exemplo, R$ 1,23 ficaria \&quot;amount\&quot;:123</param>
        /// <param name="transactionMode">Modo da transação.</param>
        /// <response code="200">Lista de transações retornada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/transacoes/{accountId}")]

        [ValidateModelState]
        [SwaggerOperation("FindTransactionsByAccount")]
        [ProducesResponseType(statusCode: 200, type: typeof(TransactionListResult))]
        public virtual IActionResult FindTransactionsByAccount(
            [FromRoute][Required] string accountId,
            [FromQuery][Range(1, 100)] int? limit,
            [FromQuery] string startingAfter,
            [FromQuery] string endingBefore,
            [FromQuery] DateTime? beginningDateTime,
            [FromQuery] DateTime? endingDateTime,
            [FromQuery] TipoTransacao transactionType,
            [FromQuery] SituacaoTransacao transactionStatus,
            [FromQuery] bool? transactionApproved,
            [FromQuery] string transactionDenialCode,
            [FromQuery] long? minimumAmount,
            [FromQuery] long? maxAmount,
            [FromQuery] ModoEntradaPan transactionMode)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre uma transação.
        /// </summary>
        /// <remarks>Em uma operação de atendimento ao portador, essa função pode ser utilizada para retornar detalhes da transação.</remarks>
        /// <param name="transactionId">Identificador da transação.</param>
        /// <response code="200">Transação recuperada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/transacoes/{transactionId}")]
        [ValidateModelState]
        [SwaggerOperation("GetTransaction")]
        [ProducesResponseType(statusCode: 200, type: typeof(Transaction))]
        public virtual IActionResult GetTransaction([FromRoute][Required] string transactionId)
        {
            return Ok();
        }
    }
}
