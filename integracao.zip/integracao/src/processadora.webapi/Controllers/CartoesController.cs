using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Cartões.
    /// </summary>
    [ApiController]
    public class CartoesController : ControllerBase
    {
        /// <summary>
        /// Associa um cartão não identificado a uma portador.
        /// </summary>
        /// <remarks>Quando emite cartões \&quot;não identificados\&quot;, o emissor pode relacionar um cartão previamente emitido com um portador por meio desta chamada.</remarks>
        /// <param name="body">Dados de associação do cartão ao portador. Passar o conjunto de dados de embossing do cartão (PAN + CVV + data de exp)</param>
        /// <response code="200">Cartão associado à conta com sucesso!</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/bindAnonymousCardRequest")]
        [ValidateModelState]
        [SwaggerOperation("BindCardToCardholder")]
        public virtual IActionResult BindCardToCardholder([FromBody] AssociateAnonymousCardRequest body)
        {
            return Ok();
        }

        /// <summary>
        /// Bloqueia o cartão {cardId} e emite um novo cartão para o cliente.
        /// </summary>
        /// <remarks>Atualiza a situação do cartão para bloqueado e inicia o processo de emissão de novo cartão para o cliente.</remarks>
        /// <param name="body">Informações para o bloqueio e reemissão.</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Dados atualizados do cartão com {cardId}</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/blockAndReissueCardRequest")]
        [ValidateModelState]
        [SwaggerOperation("BlockAndReissueCard")]
        public virtual IActionResult BlockAndReissueCard([FromBody] CardBlockAndReissueRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Bloqueia o cartão {cardId}. Não emite outro cartão.
        /// </summary>
        /// <remarks>Atualiza a situação do cartão para bloqueado.</remarks>
        /// <param name="body">Informações para o bloqueio.</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Dados atualizados do cartão com {cardId}</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/blockCardRequest")]
        [ValidateModelState]
        [SwaggerOperation("BlockCard")]
        public virtual IActionResult BlockCard([FromBody] CardBlockRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Requisita uma mudança do PIN do cartão {cardId}.
        /// </summary>
        /// <remarks>Requisita a mudaça do PIN de um cartão. Mudanças do PIN offline vão ser aplicadas na próxima transação realizada que for online e na qual o cartão puder receber um script de troca de PIN na resposta.</remarks>
        /// <param name="body">Informações para a mudança do PIN.</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Requisição de mudança de PIN feita com sucesso.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/changePin")]
        [ValidateModelState]
        [SwaggerOperation("ChangePin")]
        public virtual IActionResult ChangePin([FromBody] PinChangeRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Cria um novo cartão virtual.
        /// </summary>
        /// <param name="body">Especificações do cartão virtual solicitado.</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Dados do cartão virtual criado</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/virtualcards")]
        [ValidateModelState]
        [SwaggerOperation("CreateVirtualCard")]
        public virtual IActionResult CreateVirtualCard([FromBody] CreateVirtualCardRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera uma lista de cartões do emissor de acordo com os filtros definidos.
        /// </summary>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <param name="issuerId">Identificador do cartão fornecido pelo emissor na sua criação.</param>
        /// <param name="identityDocumentNumber">No Brasil, usar CPF ou CNPJ.</param>
        /// <param name="panLast4Digits">Últimos 4 dígitos do cartão.</param>
        /// <param name="issuedOnOrAfterDate">Data indicando que só cartões emitidos depois dessa data vão ser retornados</param>
        /// <response code="200">Lista de cartões retornada com sucesso.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/cartoes")]
        [ValidateModelState]
        [SwaggerOperation("FindCards")]
        [ProducesResponseType(statusCode: 200, type: typeof(List<Card>))]
        public virtual IActionResult FindCards(
            [FromQuery][Range(1, 100)] int? limit,
            [FromQuery] string startingAfter,
            [FromQuery] string endingBefore,
            [FromQuery] string issuerId,
            [FromQuery] string identityDocumentNumber,
            [FromQuery] string panLast4Digits,
            [FromQuery] string issuedOnOrAfterDate)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações de um cartão.
        /// </summary>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Dados do cartão com {cardId}</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/cartoes/{cardId}")]
        [ValidateModelState]
        [SwaggerOperation("GetCard")]
        [ProducesResponseType(statusCode: 200, type: typeof(Card))]
        public virtual IActionResult GetCard([FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Retorna as informações de status das funcionalidades dos cartões.
        /// </summary>
        /// <remarks>Retorna uma lista de funcionalidades de cartões e o estado de cada funcionalidade</remarks>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Funcionalidades do cartão obtidas com sucesso!</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/cardFunctions")]
        [ValidateModelState]
        [SwaggerOperation("GetCardFunctions")]
        public virtual IActionResult GetCardFunctions([FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Lista todos os cartões virtuais para um determinado cartão real
        /// </summary>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Dados do cartão virtual criado</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/virtualcards/list")]
        [ValidateModelState]
        [SwaggerOperation("ListVirtualCards")]
        public virtual IActionResult ListVirtualCards([FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Gera nova via do cartão para o cliente.
        /// </summary>
        /// <remarks>Inicia o processo de emissão de nova via do cartão para o cliente.</remarks>
        /// <param name="body">Informações para a emissão da nova via.</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Dados atualizados do cartão com {cardId}</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/reissueCardRequest")]
        [ValidateModelState]
        [SwaggerOperation("ReissueCard")]
        public virtual IActionResult ReissueCard([FromBody] CardReissueRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Requisita um novo cartão "não identificado" que será associado a um usuário em um ponto futuro.
        /// </summary>
        /// <remarks>Passa os dados necessários para o requerimento de um novo cartão que não vai estar atualmente associado a um usuário.</remarks>
        /// <param name="body">Dados para a requisição de novo cartão, sem dados de portador.</param>
        /// <response code="200">Cartão requisitado com sucesso!</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/newAnonymousCardRequest")]
        [ValidateModelState]
        [SwaggerOperation("RequestNewAnonymousCard")]
        public virtual IActionResult RequestNewAnonymousCard([FromBody] NewAnonymousCardRequest body)
        {
            return Ok();
        }

        /// <summary>
        /// Reseta informações de ativação das funcionalides dos cartões para o padrão do emissor.
        /// </summary>
        /// <remarks>Ativa ou desativa funcionalidades de um cartão.</remarks>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Funcionalidades de cartões resetadas com sucesso!</response>
        [HttpPatch]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/resetCardFunctions")]
        [ValidateModelState]
        [SwaggerOperation("ResetCardFunctions")]
        public virtual IActionResult ResetCardFunctions([FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Desbloqueia o cartão {cardId}.
        /// </summary>
        /// <remarks>Atualiza a situação do cartão para desbloqueado.</remarks>
        /// <param name="body">Informações para o desbloqueio.</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Dados atualizados do cartão com {cardId}</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/unblockCardRequest")]
        [ValidateModelState]
        [SwaggerOperation("UnblockCard")]
        public virtual IActionResult UnblockCard([FromBody] CardUnblockRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Atualiza informações do cartão, permitindo vincular um portador uma única vez.
        /// </summary>
        /// <param name="body">Informações relacionadas ao portador para atualização na processadora integracao. Obs.: Quando se tratar de um cartão anônimo, todos os campos devem ser enviados, porém, quando se tratar de cartões que já estão atrelados à uma conta, os campos a seguir não devem ser enviados: &lt;br&gt; &lt;ul&gt;&lt;li&gt;identityDocumentNumber&lt;/li&gt; &lt;li&gt;identityDocumentNumber&lt;/li&gt; &lt;li&gt;cardData&lt;/li&gt; &lt;li&gt;otherIdentityDocumentNumber&lt;/li&gt; &lt;/ul&gt;</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Conta atualizada com sucesso!</response>
        [HttpPut]
        [Route("/integracao/processadora/v1/cartoes/{cardId}")]
        [ValidateModelState]
        [SwaggerOperation("UpdateCard")]
        public virtual IActionResult UpdateCard([FromBody] UpdateCardRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Atualiza informações de ativação das funcionalides dos cartões.
        /// </summary>
        /// <remarks>Ativa ou desativa funcionalidades de um cartão.</remarks>
        /// <param name="body">Informações relacionadas a ativação de funcionalidades dos cartões</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Funcionalidades de cartões atualizadas com sucesso!</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/cardFunctions")]
        [ValidateModelState]
        [SwaggerOperation("UpdateCardFunctions")]
        public virtual IActionResult UpdateCardFunctions([FromBody] UpdateFunctionBlockingRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }

        /// <summary>
        /// Requisita a validação do PIN do cartão {cardId}.
        /// </summary>
        /// <remarks>Requisita a validação do PIN de um cartão.</remarks>
        /// <param name="body">Informações para a validação do PIN.</param>
        /// <param name="cardId">Identificador do cartão.</param>
        /// <response code="200">Requisição de validação de PIN feita com sucesso.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoes/{cardId}/validatePin")]
        [ValidateModelState]
        [SwaggerOperation("ValidatePin")]
        public virtual IActionResult ValidatePin([FromBody] PinValidateRequest body, [FromRoute][Required] string cardId)
        {
            return Ok();
        }
    }
}
