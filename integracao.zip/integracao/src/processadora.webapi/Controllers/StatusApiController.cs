using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Microsoft.AspNetCore.Http;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Sondas Liveness e Readiness.
    /// </summary>
    [ApiController]
    public sealed class StatusApiController : ControllerBase
    {
        /// <summary>
        /// Liveness permite saber se a API está viva ou morta.
        /// Caso esteja viva então Readiness será testada.
        /// Caso esteja morta as aplicações que dependem desta API irão
        /// alterar seus comportamentos de acordo com a resiliência por elas
        /// implementadas. Como por exemplo, alterar seus respectivos status
        /// para Indisponível.
        /// </summary>
        /// <remarks>
        /// Indica se o sistema está vivo, executando, não
        /// necessariamente pronto para receber operações.
        /// </remarks>
        /// <response code="200">Sistema OK, ou operando degradado (detalhe no payload).</response>
        /// <response code="503">Sistema Indisponível</response>
        /// <response code="500">Falha inesperada.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/status/liveness")]
        [SwaggerOperation("GetLiveness")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public IActionResult GetLiveness()
        {
            return Ok();
        }

        /// <summary>
        /// Readiness permitem saber se a API está pronta para receber
        /// requisições. Caso não esteja pronta ainda as aplicações que
        /// dependem desta API irão alterar seus comportamentos de acordo com
        /// a resiliência por elas implementadas. Como por exemplo, aguardar
        /// alguns segundos antes de tentar novamente.
        /// </summary>
        /// <remarks>
        /// Indica se o sistema está disponível para receber
        /// requisições ou se está enfrentando problemas de estabilidade e
        /// saúde.
        /// </remarks>
        /// <response code="200">Sistema OK, ou operando degradado (detalhe no payload).</response>
        /// <response code="503">Sistema Indisponível</response>
        /// <response code="500">Falha inesperada.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/status/readiness")]
        [SwaggerOperation("GetReadiness")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public IActionResult GetStatus()
        {
            return Ok();
        }
    }
}