using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using PrbCartao.Integracao.Models;
using PrbCartao.Integracao.Models.Respostas;
using PrbCartao.Webapi.Custom.Attributes;
using Swashbuckle.AspNetCore.Annotations;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Provisionamentos.
    /// </summary>
    [ApiController]
    public class ProvisionamentosController : ControllerBase
    {
        /// <summary>
        /// Solicita informação de saldo na conta colchão.
        /// </summary>
        /// <response code="200">Saldo de provisionamento.</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/provisionamento/saldo")]
        [ValidateModelState]
        [SwaggerOperation("GetBalance")]
        [ProducesResponseType(statusCode: 200, type: typeof(SaldoProvisionamento))]
        public virtual IActionResult GetBalance([FromHeader][Required()] string aPIKey)
        {
            return Ok();
        }

        /// <summary>
        /// Obtém uma lista de aportes realizados nos dias especificados.
        /// </summary>
        /// <param name="beginningDate">Data indicando o primeiro dia cujos dados devem ser retornados.</param>
        /// <param name="endDate">Data indicando o último dia cujos dados devem ser retornados.</param>
        /// <response code="200">Balanço obtido com sucess!</response>
        /// <response code="400">Erro na execução da operação</response>
        /// <response code="500">Erro no servidor</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/provisionamento/saldo/creditos")]
        [ValidateModelState]
        [SwaggerOperation("GetCredits")]
        [ProducesResponseType(statusCode: 200, type: typeof(CreditListMattress))]
        public virtual IActionResult GetCredits([FromQuery][Required()] string beginningDate, [FromQuery][Required()] string endDate)
        {
            return Ok();
        }
    }
}
