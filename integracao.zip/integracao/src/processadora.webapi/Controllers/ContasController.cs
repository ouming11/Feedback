using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using PrbCartao.Integracao.Models.Enumeradores;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using PrbCartao.Integracao.Entidades;
using PrbCartao.Integracao.Models.Comandos;
using Microsoft.AspNetCore.Http;
using PrbCartao.Integracao.Operacoes;
using PrbCartao.Integracao.Models.Respostas;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Contas.
    /// </summary>
    [ApiController]
    public class ContasController : ControllerBase
    {
        /// <summary>
        /// Solicita criação de uma nova conta.
        /// </summary>
        /// <param name="body">Informações relacionadas à conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("AddAccount")]
        public virtual IActionResult AddAccount([FromBody] CriarConta body)
        {
            return Ok();
        }

        /// <summary>
        /// Registra um novo lançamento de crédito.
        /// </summary>
        /// <remarks>Solicita registro de uma nova carga de créditos para a conta com identificador {accountId}.</remarks>
        /// <param name="body">Informações relacionadas à carga de créditos para inclusão na processadora integracao.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/transactions/credits")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("AddCredit")]
        public virtual IActionResult AddCredit([FromBody] NewCreditRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Registra um novo lançamento de débito.
        /// </summary>
        /// <remarks>Solicita registro de um novo débito para a conta com identificador {accountId}.</remarks>
        /// <param name="body">Informações relacionadas ao débito para inclusão na processadora integracao.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/transactions/debits")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("AddDebit")]
        public virtual IActionResult AddDebit([FromBody] NewDebitRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Pedido de liquidação antecipada de parcelas futuras.
        /// </summary>
        /// <remarks>Cria um pedido de liquidação antecipada de um número de parcelas futuras de uma determinada compra.</remarks>
        /// <param name="body">Dados para a liquidação antecipada, incluindo a compra e quantidade de faturas.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/installments/advancePaymentRequest")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("AdvancePayment")]
        public virtual IActionResult AdvancePayment([FromBody] AdvancePaymentRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Bloqueia uma conta.
        /// </summary>
        /// <remarks>Solicitação de bloqueio de conta.</remarks>
        /// <param name="body">Informações relacionadas ao bloqueio da conta.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/blockAccount")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("BlockAccount")]
        public virtual IActionResult BlockAccount([FromBody] BlockAccountRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Cancela uma conta e cartão(ões) associado(s).
        /// </summary>
        /// <remarks>Solicitação de cancelamento de conta e cartão. Encerra a conta e os cartões vinculados à conta SEM EMISSÃO DE NOVA VIA DE CARTÃO.</remarks>
        /// <param name="body">Informações relacionadas ao cancelamento da conta.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/cancelAccount")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("CancelAccount")]
        public virtual IActionResult CancelAccount([FromBody] CancelAccountRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Cria um novo cartão virtual.
        /// </summary>
        /// <remarks>Cria um novo cartão virtual.</remarks>
        /// <param name="body">Especificações do cartão virtual solicitado.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/virtualcards")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("CreateTokenAccount")]
        public virtual IActionResult CreateTokenAccount([FromBody] CreateAccountVirtualCardRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Lista todas as contas de um emissor de acordo com filtros estabelecidos.
        /// </summary>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <param name="identityDocumentNumber">No Brasil, usar CPF ou CNPJ.</param>
        /// <param name="fullName">Nome completo do titular.</param>
        /// <param name="psProductCode">Código do produto fornecido pela integracao.</param>
        /// <param name="accountStatus">Status da conta.</param>
        /// <param name="issuerId">Identificador da conta fornecido pelo emissor na sua criação.</param>
        /// <param name="includedSince">Procura contas incluídas depois dessa data.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<Conta>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("FindAccounts")]
        public virtual IActionResult FindAccounts(
            [FromQuery][Range(1, 100)] int? limit,
            [FromQuery] string startingAfter,
            [FromQuery] string endingBefore,
            [FromQuery] string identityDocumentNumber,
            [FromQuery] string fullName,
            [FromQuery] string psProductCode,
            [FromQuery] SituacaoConta accountStatus,
            [FromQuery] string issuerId,
            [FromQuery] DateTime? includedSince)
        {
            return Ok();
        }

        /// <summary>
        /// Lista cargas de créditos agendadas mas ainda não executadas.
        /// </summary>
        /// <param name="accountId">Identificador da conta.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/transactions/credits")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<Credit>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("FindCreditsByAccount")]
        public virtual IActionResult FindCreditsByAccount(
            [FromRoute][Required] string accountId,
            [FromQuery][Range(1, 100)] int? limit,
            [FromQuery] string startingAfter,
            [FromQuery] string endingBefore)
        {
            return Ok();
        }

        /// <summary>
        /// Lista transações a partir de filtros especificados.
        /// </summary>
        /// <param name="accountId">Identificador da conta.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <param name="beginningDateTime">Data e hora para iniciar procura.</param>
        /// <param name="endingDateTime">Data e hora para parar procura.</param>
        /// <param name="transactionType">Tipo das transações a serem retornadas.</param>
        /// <param name="transactionStatus">Status das transações a serem retornadas.</param>
        /// <param name="transactionApproved">Se a transação foi aprovada pelo autorizador.</param>
        /// <param name="transactionDenialCode">Transações negadas no autorizador com um código específico.</param>
        /// <param name="minimumAmount">Valor mínimo, omitindo a vírgula. Por exemplo, R$ 1,23 ficaria \&quot;amount\&quot;:123</param>
        /// <param name="maxAmount">Valor máximo, omitindo a vírgula. Por exemplo, R$ 1,23 ficaria \&quot;amount\&quot;:123</param>
        /// <param name="transactionMode">Modo da transação.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/transactions")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<Transacao>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("FindTransactionsByAccount")]
        public virtual IActionResult FindTransactionsByAccount(
            [FromRoute][Required] string accountId,
            [FromQuery][Range(1, 100)] int? limit,
            [FromQuery] string startingAfter,
            [FromQuery] string endingBefore,
            [FromQuery] DateTime? beginningDateTime,
            [FromQuery] DateTime? endingDateTime,
            [FromQuery] TipoTransacao transactionType,
            [FromQuery] SituacaoTransacao transactionStatus,
            [FromQuery] bool? transactionApproved,
            [FromQuery] string transactionDenialCode,
            [FromQuery] long? minimumAmount,
            [FromQuery] long? maxAmount,
            [FromQuery] ModoEntradaPan transactionMode)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre uma conta.
        /// </summary>
        /// <remarks>Em uma operação de atendimento ao portador, essa função pode ser utilizada para retornar detalhes da conta, a situação da conta e sua lista de cartões.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(Conta))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetAccount")]
        public virtual IActionResult GetAccount([FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre o saldo e limites de uma conta. Funciona apenas para o produto pós pago.
        /// </summary>
        /// <remarks>Retorna dados de saldo e limite da conta. Importante para mostar essas informações par o titular.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/balance")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(SaldoConta))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetAccountBalance")]
        public virtual IActionResult GetAccountBalance([FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Lista os cartões de uma conta, ativados ou não.
        /// </summary>
        /// <param name="accountId">Identificador da conta.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="first">Primeiro item a ser retornado na paginação. Obs: Índice começa no 0.</param>
        /// <param name="status">Status dos cartões a serem consultados. Pode assumir os valores issued ou requested, sendo issued o padrão</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/cards")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<Card>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetAccountCards")]
        public virtual IActionResult GetAccountCards(
            [FromRoute][Required] string accountId,
            [FromQuery][Range(1, 100)] int? limit,
            [FromQuery] int? first,
            [FromQuery] string status)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre a fatura fechada mais recente para essa conta.
        /// </summary>
        /// <remarks>Retorna todos os dados da fatura fechada mais recente. Uma vez que a fatura seja fechada os dados dela não mudam mais.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/statements/closed")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(Statement))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetAccountStatementClosed")]
        public virtual IActionResult GetAccountStatementClosed([FromRoute] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre a fatura atualmente aberta para essa conta.
        /// </summary>
        /// <remarks>Retorna dados da fatura atualmente aberta. Até o fechamento dessa fatura ela pode continuar sendo atualizada.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/statements/open")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(Statement))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetAccountStatementOpen")]
        public virtual IActionResult GetAccountStatementOpen([FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre as faturas fechadas de um mês em particular. Pode ser usado para pesquisar faturas fechadas.
        /// </summary>
        /// <remarks>Retorna todos os dados das faturas fechadas de um mês em particular. Pode ser usado para pesquisar faturas fechadas. Para acessar a fatura aberta atual, ou para verificar lançamentos em faturas futuras, é preciso usar os métodos específicos para essas faturas.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        /// <param name="mes">Mês, de 1 a 12.</param>
        /// <param name="ano">Ano (com quatro dígitos).</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/statements")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<Statement>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetAccountStatements")]
        public virtual IActionResult GetAccountStatements(
            [FromRoute] string accountId,
            [FromQuery][Required()][Range(1, 12)] int mes,
            [FromQuery][Required][Range(1, 9999)] int ano)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre todas as faturas futuras que já tenham algum lançamento agendado para essa conta.
        /// </summary>
        /// <remarks>Retorna todos os dados das faturas futuras (faturas com vencimento posterior ao da fatura atualmente aberta) que tenham algum lançamento já agendado (parcelas de compras parceladas).</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/statements/future")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<Statement>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetAccountStatementsFuture")]
        public virtual IActionResult GetAccountStatementsFuture([FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre compras parceladas que ainda tem parcelas no futuro.
        /// </summary>
        /// <remarks>Retorna todos os dados de compras parceladas que ainda tenham parcelas que irão vencer no futuro.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/installments/future")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<Installment>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetFutureInstallments")]
        public virtual IActionResult GetFutureInstallments([FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Pedido de parcelamento de saldo devedor.
        /// </summary>
        /// <remarks>Cria um pedido de parcelamento do saldo devedor, de acordo com uma das opções préviamente definidas.</remarks>
        /// <param name="body">Dados da opção de parcelamento sendo requisitada.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/statements/closed/installmentsRequest")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("InstallmentRequest")]
        public virtual IActionResult InstallmentRequest([FromBody] InstallmentRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Lista todos cartões virtuais para um determinado cartão real.
        /// </summary>
        /// <remarks>Lista todos cartões virtuais para um determinado cartão real.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpGet]
        [Route("/integracao/processadora/v1/contas/{accountId}/virtualcards/list")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(List<VirtualCardDescriptor>))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("ListTokenAccount")]
        public virtual IActionResult ListTokenAccount([FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Requisita um novo cartão associado a conta.
        /// </summary>
        /// <remarks>Passa os dados necessários para o requerimento de um novo cartão associado a essa conta. O cartão pode ser para o titular ou um cartão adicional.</remarks>
        /// <param name="body">Dados para a requisição de novo cartão, incluindo todos os dados do portador.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/newCardRequest")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("RequestNewCard")]
        public virtual IActionResult RequestNewCard([FromBody] NewCardRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Desbloqueia uma conta.
        /// </summary>
        /// <remarks>Solicitação de desbloqueio de conta.</remarks>
        /// <param name="body">Informações relacionadas ao desbloqueio da conta.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/contas/{accountId}/unblockAccount")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("UnblockAccount")]
        public virtual IActionResult UnblockAccount([FromBody] UnblockAccountRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Atualiza informações de conta.
        /// </summary>
        /// <remarks>implementar</remarks>
        /// <param name="body">Informações relacionadas à conta e produto para atualização na processadora integracao.</param>
        /// <param name="accountId">Identificador da conta.</param>
        [HttpPut]
        [Route("/integracao/processadora/v1/contas/{accountId}")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status202Accepted, type: typeof(Http202Accepted))]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [ProducesResponseType(statusCode: StatusCodes.Status409Conflict, type: typeof(Http409Conflict))]
        [SwaggerOperation("UpdateAccount")]
        public virtual IActionResult UpdateAccount([FromBody] UpdateAccountRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }
    }
}
