using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Microsoft.AspNetCore.Http;
using PrbCartao.Integracao.Models.Respostas;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Cartões Virtuais.
    /// </summary>
    [ApiController]
    public class CartoesVirtuaisController : ControllerBase
    {
        /// <summary>
        /// Cancela um cartão virtual.
        /// </summary>
        /// <param name="body">Informações de cancelamento do CV.</param>
        /// <param name="vCardId">Identificador do cartão virtual.</param>
        /// <response code="200">Dados do cartão virtual criado</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/cartoesvirtuais/{vCardId}/cancel")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest, type: typeof(Http400BadRequest))]
        [SwaggerOperation("CancelVirtualCard")]
        public virtual IActionResult CancelVirtualCard([FromBody] CancelVirtualCardRequest body, [FromRoute][Required] string vCardId)
        {
            return Ok();
        }

        /// <summary>
        /// Lista todos os cartões virtuais para um determinado cartão real
        /// </summary>
        /// <param name="vCardId">Identificador do cartão virtual.</param>
        /// <response code="200">Dados do cartão virtual solicitado</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/cartoesvirtuais/{vCardId}")]
        [ValidateModelState]
        [ProducesResponseType(statusCode: StatusCodes.Status204NoContent)]
        [SwaggerOperation("GetVirtualCard")]
        public virtual IActionResult GetVirtualCard([FromRoute][Required] string vCardId)
        {
            return Ok();
        }
    }
}
