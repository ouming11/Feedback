using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Parcelamentos.
    /// </summary>
    [ApiController]
    public class ParcelamentosController : ControllerBase
    {
        /// <summary>
        /// Pedido de liquidação antecipada de parcelas futuras.
        /// </summary>
        /// <remarks>Cria um pedido de liquidação antecipada de um número de parcelas futuras de uma determinada compra.</remarks>
        /// <param name="body">Dados para a liquidação antecipada, incluindo a compra e quantidade de faturas.</param>
        /// <param name="accountId">Identificador da conta.</param>
        /// <response code="200">Pedido enviado com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="404">Transação ou conta não encontrada.</response>
        /// <response code="412">Transação não tem o número de parcelas futuras necessárias para o pedido.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/parcelamentos/{accountId}/advancePaymentRequest")]
        [ValidateModelState]
        [SwaggerOperation("AdvancePayment")]
        public virtual IActionResult AdvancePayment([FromBody] AdvancePaymentRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações sobre compras parceladas que ainda tem parcelas no futuro.
        /// </summary>
        /// <remarks>Retorna todos os dados de compras parceladas que ainda tenham parcelas que irão vencer no futuro.</remarks>
        /// <param name="accountId">Identificador da conta.</param>
        /// <response code="200">Parcelamentos recuperados com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/parcelamentos/{accountId}/future")]
        [ValidateModelState]
        [SwaggerOperation("GetFutureInstallments")]
        [ProducesResponseType(statusCode: 200, type: typeof(List<InstallmentPurchase>))]
        public virtual IActionResult GetFutureInstallments([FromRoute][Required] string accountId)
        {
            return Ok();
        }

        /// <summary>
        /// Pedido de parcelamento de saldo devedor.
        /// </summary>
        /// <remarks>Cria um pedido de parcelamento do saldo devedor, de acordo com uma das opções préviamente definidas.</remarks>
        /// <param name="body">Dados da opção de parcelamento sendo requisitada.</param>
        /// <param name="accountId">Identificador da conta.</param>
        /// <response code="200">Pedido enviado com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="404">Conta não encontrada.</response>
        /// <response code="412">Parcelamento pedido não é uma das opções de parcelamento disponíveis.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/parcelamentos/{accountId}/statements/closed/installmentsRequest")]
        [ValidateModelState]
        [SwaggerOperation("InstallmentRequest")]
        public virtual IActionResult InstallmentRequest([FromBody] InstallmentRequest body, [FromRoute][Required] string accountId)
        {
            return Ok();
        }
    }
}
