using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// QR Codes.
    /// </summary>
    [ApiController]
    public class QrcodeController : ControllerBase
    {
        /// <summary>
        /// Obtêm uma nova chave pública para cifrar os dados do cartão antes de enviar uma nova transação de QR Code.
        /// </summary>
        /// <remarks>Chave pública para criptografar os dados do cartão  (&#x27;cardData&#x27;: {\&quot;cardHolder\&quot;:{\&quot;card\&quot;:{\&quot;pan\&quot;:\&quot;6550001020301234\&quot;,\&quot;expiry\&quot;:{\&quot;month\&quot;:\&quot;01\&quot;,\&quot;year\&quot;:\&quot;2021\&quot;},\&quot;name\&quot;:\&quot;JOAO SILVA\&quot;,\&quot;csc\&quot;:\&quot;123\&quot;},\&quot;cpf\&quot;:\&quot;18535908005\&quot;}}) a serem enviados no pedido de pagamento. A chave é retornada junto com o tempo até a sua expiração, e pode ser utilizada mais de uma vez. É recomendado que a chave seja armazenada em back-end e sua validade seja controlada. A cifra utilizada é RSA/ECB/PKCS1Padding. A chave retornada é X509 SubjectKeyInfo no formato DER codificado em Base64.</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Bad request</response>
        /// <response code="401">Unathorized</response>
        /// <response code="403">Forbidden</response>
        /// <response code="422">Unprocessable Entity</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/qrcode/publicKey")]
        [ValidateModelState]
        [SwaggerOperation("GetPubKey")]
        [ProducesResponseType(statusCode: 200, type: typeof(PublicKey))]
        public virtual IActionResult GetPubKey([FromHeader][Required()] string aPIKey)
        {
            return Ok();
        }

        /// <summary>
        /// Realiza o parse do QrCode
        /// </summary>
        /// <remarks>Realiza o parse do QrCode</remarks>
        /// <param name="body">Informações para o parse do QrCode</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Bad Request</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/qrcode/parse")]

        [ValidateModelState]
        [SwaggerOperation("ParseQrcode")]
        [ProducesResponseType(statusCode: 200, type: typeof(ParseQrCodeSuccess))]
        public virtual IActionResult ParseQrcode([FromBody] ParseQrCodeParams body)
        {
            return Ok();
        }

        /// <summary>
        /// Faz um pagamento
        /// </summary>
        /// <remarks>Solicitação de pagamento com o cartão</remarks>
        /// <param name="body">Informações para o pagamento</param>
        /// <response code="200">successful operation</response>
        /// <response code="202">Accepted. Respondido quando o resultado da transação vai ser retornado via callback.</response>
        /// <response code="400">Bad Request</response>
        /// <response code="401">Unathorized</response>
        /// <response code="403">Forbidden</response>
        /// <response code="412">Precondition failed</response>
        /// <response code="422">Unprocessable Entity</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/qrcode/payment")]
        [ValidateModelState]
        [SwaggerOperation("QrcodePayment")]
        [ProducesResponseType(statusCode: 200, type: typeof(PaymentCard))]
        public virtual IActionResult QrcodePayment([FromBody] PaymentCardParams body)
        {
            return Ok();
        }

        /// <summary>
        /// Faz um pagamento con informações mínimas, sem necessidade de criptografia do lado do emissor
        /// </summary>
        /// <remarks>Solicitação de pagamento com o cartão</remarks>
        /// <param name="body">Informações para o pagamento</param>
        /// <response code="200">successful operation</response>
        /// <response code="202">Accepted. Respondido quando o resultado da transação vai ser retornado via callback.</response>
        /// <response code="400">Bad Request</response>
        /// <response code="401">Unathorized</response>
        /// <response code="403">Forbidden</response>
        /// <response code="412">Precondition failed</response>
        /// <response code="422">Unprocessable Entity</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/qrcode/simplePayment")]
        [ValidateModelState]
        [SwaggerOperation("SimpleQrcodePayment")]
        [ProducesResponseType(statusCode: 200, type: typeof(PaymentCard))]
        public virtual IActionResult SimpleQrcodePayment([FromBody] SimplePaymentCardParams body)
        {
            return Ok();
        }
    }
}
