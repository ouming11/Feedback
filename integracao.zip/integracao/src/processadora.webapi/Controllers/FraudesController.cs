using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Fraudes.
    /// </summary>
    [ApiController]
    public class FraudesController : ControllerBase
    {
        /// <summary>
        /// Registra uma notificação de fraude (não associada a uma disputa).
        /// </summary>
        /// <param name="body">Dados do registro de disputa.</param>
        /// <response code="200">Disputa registrada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/fraudes/notification")]
        [ValidateModelState]
        [SwaggerOperation("AddFraud")]
        public virtual IActionResult AddFraud([FromBody] FraudNotificationRequest body)
        {
            return Ok();
        }

        /// <summary>
        /// Registra uma notificação de fraude (não associada a uma disputa).
        /// </summary>
        /// <param name="body">Dados do registro de disputa.</param>
        /// <response code="200">Disputa registrada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/fraudes/notification/undo")]
        [ValidateModelState]
        [SwaggerOperation("AddFraudUndo")]
        public virtual IActionResult AddFraudUndo([FromBody] FraudNotificationUndoRequest body)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera uma lista de notificações de fraude.
        /// </summary>
        /// <param name="beginningDate">Data indicando o primeiro dia cujos dados devem ser retornados.</param>
        /// <param name="endingDate">Data indicando o último dia cujos dados devem ser retornados.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <response code="200">Lista de disputas retornada com sucesso.</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/fraudes/notification")]
        [ValidateModelState]
        [SwaggerOperation("FindFrauds")]
        public virtual IActionResult FindFrauds([FromQuery][Required()] string beginningDate, [FromQuery][Required()] string endingDate, [FromQuery][Range(1, 100)] int? limit, [FromQuery] string startingAfter, [FromQuery] string endingBefore)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações de uma notificação de fraude.
        /// </summary>
        /// <param name="accountId">Identificador da conta.</param>
        /// <param name="transactionId">Identificador da transação.</param>
        /// <response code="200">Dados da notificação de fraude com {accountId} e {transactionId}</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/fraudes/notification/{accountId}/{transactionId}")]
        [ValidateModelState]
        [SwaggerOperation("GetFraudNotification")]
        [ProducesResponseType(statusCode: 200, type: typeof(FraudNotification))]
        public virtual IActionResult GetFraudNotification([FromRoute][Required] string accountId, [FromRoute][Required] string transactionId)
        {
            return Ok();
        }
    }
}
