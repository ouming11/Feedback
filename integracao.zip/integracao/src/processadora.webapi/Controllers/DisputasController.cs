using System;
using System.ComponentModel.DataAnnotations;
using PrbCartao.Webapi.Custom.Attributes;
using PrbCartao.Integracao.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using PrbCartao.Integracao.Models.Enumeradores;
using PrbCartao.Integracao.Entidades;

namespace PrbCartao.Integracao.Controllers
{
    /// <summary>
    /// Disputas.
    /// </summary>
    [ApiController]
    public class DisputasController : ControllerBase
    {
        /// <summary>
        /// Registra uma disputa para questionar a validade de uma transação.
        /// </summary>
        /// <param name="body">Dados do registro de disputa.</param>
        [HttpPost]
        [Route("/integracao/processadora/v1/disputas")]
        [ValidateModelState]
        [SwaggerOperation("AddDispute")]
        public virtual IActionResult AddDispute([FromBody] DisputeRequest body)
        {
            return Ok();
        }

        /// <summary>
        /// Associa um documento a uma disputa previamente criada.
        /// </summary>
        /// <remarks>Associa um documento a uma disputa previamente criada.</remarks>
        /// <param name="disputeId">Identificador da disputa.</param>
        /// <response code="200">Documento adicionado com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/disputas/{disputeId}/documents")]
        [ValidateModelState]
        [SwaggerOperation("DocumentsDisputes")]
        [ProducesResponseType(statusCode: 200, type: typeof(Conta))]
        public virtual IActionResult DocumentsDisputes([FromRoute][Required] string disputeId)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera uma lista de disputas do emissor de acordo com os filtros definidos.
        /// </summary>
        /// <param name="beginningDate">Data indicando o primeiro dia cujos dados devem ser retornados.</param>
        /// <param name="endingDate">Data indicando o último dia cujos dados devem ser retornados.</param>
        /// <param name="limit">Número limite de objetos retornados. O valor deve ser entre 1 e 100.</param>
        /// <param name="startingAfter">Um cursor para uso em paginação. {starting_after} é o identificador único do objeto a partir do qual se quer listar. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o último possui identificador \&quot;obj1234\&quot;, para se obter a página use \&quot;starting_after&#x3D;obj1234\&quot;.</param>
        /// <param name="endingBefore">Um cursor para uso em paginação. {ending_before} é o identificador único do objeto a partir do qual se quer listar os anteriores. Por exemplo, se houve um retorno de uma lista de 100 objetos para esta chamada sendo que o primeiro possui identificador \&quot;obj1234\&quot;, para se obter a página anterior use \&quot;ending_before&#x3D;obj1234\&quot;.</param>
        /// <param name="disputeReason">Código do motivo das disputas a serem retornadas.</param>
        /// <param name="disputeStatus">Status das disputas a serem retornadas.</param>
        /// <response code="200">Lista de disputas retornada com sucesso.</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/disputas")]
        [ValidateModelState]
        [SwaggerOperation("FindDisputes")]
        public virtual IActionResult FindDisputes([FromQuery][Required()] string beginningDate, [FromQuery][Required()] string endingDate, [FromQuery][Range(1, 100)] int? limit, [FromQuery] string startingAfter, [FromQuery] string endingBefore, [FromQuery] string disputeReason, [FromQuery] SituacaoDisputa disputeStatus)
        {
            return Ok();
        }

        /// <summary>
        /// Recupera informações de uma disputa.
        /// </summary>
        /// <param name="disputeId">Identificador da disputa.</param>
        /// <response code="200">Dados da disputa com {disputeId}</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpGet]
        [Route("/integracao/processadora/v1/disputas/{disputeId}")]
        [ValidateModelState]
        [SwaggerOperation("GetDispute")]
        [ProducesResponseType(statusCode: 200, type: typeof(Dispute))]
        public virtual IActionResult GetDispute([FromRoute][Required] string disputeId)
        {
            return Ok();
        }

        /// <summary>
        /// Responde a um parecer negativo da bandeira/credenciador. A resposta pode aceitar o parcer e desistir da disputa ou pode discordar e passar a disputa para a próxima fase.
        /// </summary>
        /// <param name="body">Uma resposta a uma negativa por parte do credenciador, indicado aceitação ou continuação do processo de disputa e incluidno motivos no caso de continuação.</param>
        /// <param name="disputeId">Identificador da disputa.</param>
        /// <response code="200">Resposta registrada com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/disputas/{disputeId}/response")]
        [ValidateModelState]
        [SwaggerOperation("RepondDispute")]
        public virtual IActionResult RepondDispute([FromBody] DisputeResponseRequest body, [FromRoute][Required] string disputeId)
        {
            return Ok();
        }

        /// <summary>
        /// Desiste de uma disputa e envia uma reversão dela.
        /// </summary>
        /// <param name="body">Dados para reversão do pedido de disputa.</param>
        /// <param name="disputeId">Identificador da disputa.</param>
        /// <response code="200">Pedido de reversão criado com sucesso!</response>
        /// <response code="400">Erro na execução da operação.</response>
        /// <response code="500">Erro no servidor.</response>
        [HttpPost]
        [Route("/integracao/processadora/v1/disputas/{disputeId}/undo")]
        [ValidateModelState]
        [SwaggerOperation("UndoDispute")]
        public virtual IActionResult UndoDispute([FromBody] DisputeReversalRequest body, [FromRoute][Required] string disputeId)
        {
            return Ok();
        }
    }
}
